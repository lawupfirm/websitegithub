# Payment System - Visual Architecture & Flow

## Complete System Overview

\`\`\`
┌─────────────────────────────────────────────────────────────────────┐
│                         LAWUP PAYMENT SYSTEM                         │
│                        January 27, 2026 - LIVE                      │
└─────────────────────────────────────────────────────────────────────┘

                              USER INTERFACE
                              
    ┌──────────────────────────────────────────────────────┐
    │  Contact Form              Floating Widget    Footer  │
    │  ┌──────────────────┐      ┌─────────────┐  ┌──────┐ │
    │  │ Fill Form        │      │ Pay Fee     │  │ Pay  │ │
    │  │ Verify Email OTP │  OR  │ (Purple)    │  │ Now  │ │
    │  │ [💳 Pay]        │      └─────────────┘  └──────┘ │
    │  └──────────────────┘                                 │
    └──────────────────────────────────────────────────────┘
                    │
                    │ Opens
                    ▼
    ┌──────────────────────────────────────────────────────┐
    │          PAYMENT MODAL COMPONENT                     │
    │                                                       │
    │  ┌─ Mode Selection ─────────────────────────────┐   │
    │  │ [Service Wise]  vs  [Custom Amount]        │   │
    │  └────────────────────────────────────────────┘   │
    │                                                       │
    │  Service Option:          Custom Option:            │
    │  ┌────────────────────┐  ┌──────────────────┐       │
    │  │ Select Service     │  │ Enter Amount     │       │
    │  │ • Consultation     │  │ (Min ₹100)       │       │
    │  │ • Drafting         │  │ ₹ [_______]      │       │
    │  │ • Representation   │  └──────────────────┘       │
    │  │ • Corporate        │                             │
    │  └────────────────────┘                             │
    │                                                       │
    │  Amount Summary:                                    │
    │  ┌────────────────────────────────────────────┐   │
    │  │ Total: ₹[AMOUNT] (Real-time display)       │   │
    │  └────────────────────────────────────────────┘   │
    │                                                       │
    │  [Cancel]  [Pay ₹AMOUNT]                           │
    └──────────────────────────────────────────────────────┘
                    │
                    │ Click "Pay"
                    ▼
    ┌──────────────────────────────────────────────────────┐
    │          RAZORPAY PAYMENT GATEWAY                    │
    │                                                       │
    │  Razorpay Checkout:                                 │
    │  ┌────────────────────────────────────────────┐    │
    │  │ Amount: ₹XXXX                              │    │
    │  │ Service: [Service Name]                    │    │
    │  │ Customer: [Name]                           │    │
    │  │                                             │    │
    │  │ Payment Methods:                           │    │
    │  │ [💳 Card] [📱 UPI] [💰 Wallet]            │    │
    │  │                                             │    │
    │  │ [Complete Payment]                         │    │
    │  └────────────────────────────────────────────┘    │
    └──────────────────────────────────────────────────────┘
                    │
         ┌──────────┴──────────┐
         │                     │
         ▼ (Success)          ▼ (Failure)
    ┌─────────────────┐  ┌──────────────────┐
    │ SIGNATURE VERIFY│  │ ERROR MESSAGE    │
    └─────────────────┘  └──────────────────┘
         │                    │
         │ ✓ Valid           │ Retry
         ▼                    │
    ┌─────────────────────────▼──────────────┐
    │     DATABASE: SAVE PAYMENT RECORD      │
    │  order_id, payment_id, status, user    │
    │  amount, service, signature            │
    └─────────────────────────────────────────┘
         │
         ▼
    ┌──────────────────────────────────────────────────────┐
    │       SEND EMAIL RECEIPT (via Resend API)            │
    │                                                       │
    │  To: customer@email.com                              │
    │  From: noreply@lawup.in                              │
    │  Subject: Payment Receipt - ₹XXXX                    │
    │                                                       │
    │  Body (HTML):                                        │
    │  ┌────────────────────────────────────────────┐    │
    │  │ ✓ PAYMENT RECEIVED SUCCESSFULLY            │    │
    │  │                                             │    │
    │  │ Receipt #: LWP000123                       │    │
    │  │ Amount: ₹XXXX                              │    │
    │  │ Service: [Service Name]                    │    │
    │  │ Date: Jan 27, 2026                         │    │
    │  │                                             │    │
    │  │ 💼 OUR TEAM WILL GET IN TOUCH              │    │
    │  │ within 24 business hours                   │    │
    │  │                                             │    │
    │  │ LawUp Consulting                           │    │
    │  │ Chamber: Ground B188a, Jamunapuri         │    │
    │  │ Jaipur, Rajasthan - 302039                │    │
    │  │ Ph: +91-9716968000                        │    │
    │  └────────────────────────────────────────────┘    │
    └──────────────────────────────────────────────────────┘
         │
         ▼
    ┌──────────────────────────────────────────────────────┐
    │     MODAL: SHOW SUCCESS MESSAGE                      │
    │                                                       │
    │  ✓ Payment Successful!                              │
    │  Receipt sent to your email.                         │
    │  We will get in touch soon.                         │
    │                                                       │
    │  [Close]                                             │
    │                                                       │
    │  (Auto-close in 2 seconds)                          │
    └──────────────────────────────────────────────────────┘
\`\`\`

---

## Backend API Flow

\`\`\`
CLIENT SIDE                          SERVER SIDE

[User Click]
    │
    ├──────────────────────────────────────────────┐
    │                                               │
    ▼                                          ┌────▼─────────────────────┐
[Create Order Request]                         │ /api/razorpay/create-order│
    │                                          │ - Validate amount          │
    │     JSON: {                              │ - Create Razorpay order    │
    │       amount,                            │ - Save to DB (pending)     │
    │       email,                             │ - Return order ID & key    │
    │       service                            └────┬────────────────────┘
    │     }                                         │
    │                                               │
    ├───────────────────────────────────────────────┤
    │                                               │
    ▼                                          ┌────▼──────────────────────┐
[Razorpay Checkout Modal]                      │ Razorpay API (External)    │
    │                                          │ - Process payment          │
    │ (User enters card/UPI)                  │ - Return payment_id        │
    │                                          └────┬──────────────────────┘
    ├──────────────────────────────────────────────┤
    │                                               │
    ▼                                               │
[Payment Handler Callback]                         │
    │                                               │
    ├──────────────────────────────────────────────┤
    │                                               │
    ▼                                          ┌────▼──────────────────────┐
[Verify Payment]                               │ /api/razorpay/verify-payment│
    │                                          │ - Verify signature (crypto) │
    │     JSON: {                              │ - Update DB (completed)     │
    │       razorpay_order_id,                 │ - Return success/error      │
    │       razorpay_payment_id,               └────┬──────────────────────┘
    │       razorpay_signature                      │
    │     }                                         │
    │                                               │
    ├───────────────────────────────────────────────┤
    │                                               │
    ▼ (if verified)                            ┌────▼─────────────────────┐
[Send Receipt Email]                           │ /api/send-payment-receipt │
    │                                          │ - Build HTML template      │
    │     JSON: {                              │ - Send via Resend API      │
    │       email,                             │ - Log in database          │
    │       amount,                            └────┬────────────────────┘
    │       service,                               │
    │       payment_id                             │
    │     }                                        │
    │                                              │
    ├──────────────────────────────────────────────┤
    │                                              │
    ▼                                          ┌───▼─────────────────────┐
[Show Success Modal]                           │ Email Sent to Customer  │
    │                                          │ ✓ Receipt in inbox      │
    │ ✓ Payment Successful!                    └─────────────────────────┘
    │ Receipt sent to email
    │
    └──────> [Auto-close in 2s]
\`\`\`

---

## Database Schema

\`\`\`
TABLE: payments

┌─────────────────────────────────────────────────────────┐
│ Columns:                                                │
├─────────────────────────────────────────────────────────┤
│ id                    UUID (primary key)                │
│ order_id             String (unique) - Razorpay order  │
│ payment_id           String - Razorpay payment ID      │
│ amount               Decimal - Amount in INR           │
│ currency             String - Always "INR"             │
│ status               String - pending|completed|failed │
│ email                String - Customer email           │
│ phone                String - Customer phone           │
│ name                 String - Customer name            │
│ service              String - Service selected         │
│ signature            String - Payment signature       │
│ receipt_data         JSONB - Additional data          │
│ created_at           Timestamp - Payment created      │
│ updated_at           Timestamp - Last update          │
└─────────────────────────────────────────────────────────┘

SAMPLE RECORD:

{
  "id": "550e8400-e29b-41d4-a716-446655440000",
  "order_id": "order_SXd6qP3K9KXo0U",
  "payment_id": "pay_SXd6sTfW0Z09sS",
  "amount": 5000.00,
  "currency": "INR",
  "status": "completed",
  "email": "customer@example.com",
  "phone": "+919999999999",
  "name": "John Doe",
  "service": "Divorce & Separation Consulting",
  "signature": "9ef4dffbfd84f1318f6739a3ce19f9d85851857ae648f114332d8401e0949a",
  "receipt_data": {
    "order_id": "ORDER_1706337600000"
  },
  "created_at": "2026-01-27T10:30:00Z",
  "updated_at": "2026-01-27T10:31:00Z"
}
\`\`\`

---

## File Structure

\`\`\`
lawup/
├── app/
│   ├── api/
│   │   ├── razorpay/
│   │   │   ├── create-order/
│   │   │   │   └── route.ts ✓ NEW
│   │   │   ├── verify-payment/
│   │   │   │   └── route.ts ✓ NEW
│   │   │   └── webhook/
│   │   │       └── route.ts ✓ NEW
│   │   └── send-payment-receipt/
│   │       └── route.ts ✓ NEW
│   ├── contact/
│   │   └── ContactPageClient.tsx ✓ UPDATED
│   └── practice-areas/
│       └── page.tsx ✓ UPDATED
│
├── components/
│   ├── payment-modal.tsx ✓ NEW
│   ├── floating-contact-widget.tsx ✓ UPDATED
│   ├── footer.tsx ✓ ALREADY HAS PAY NOW
│   └── fee-structure-section.tsx ✓ NEW
│
├── data/
│   ├── services.ts ✓ NEW (25+ services)
│   └── blog-posts.tsx ✓ UPDATED (5 new 2026 blogs)
│
├── scripts/
│   └── create-payments-table.sql ✓ EXECUTED
│
└── Documentation/
    ├── COMPLETE_IMPLEMENTATION_SUMMARY.md ✓ NEW
    ├── RAZORPAY_INTEGRATION_COMPLETE.md ✓ NEW
    ├── RAZORPAY_SETUP_GUIDE.md ✓ NEW
    ├── FEE_STRUCTURE_GUIDE.md ✓ NEW
    └── PAYMENT_SYSTEM_ARCHITECTURE.md ✓ (THIS FILE)
\`\`\`

---

## Environment Variables Required

\`\`\`
RAZORPAY_KEY_ID=rzp_live_S8vENUyAOwaGhw ✓ ALREADY SET
RAZORPAY_KEY_SECRET=<ADD FROM RAZORPAY DASHBOARD>
RAZORPAY_WEBHOOK_SECRET=<OPTIONAL - FOR WEBHOOKS>
RESEND_API_KEY=<ALREADY CONFIGURED>
NEXT_PUBLIC_SUPABASE_URL=<ALREADY CONFIGURED>
SUPABASE_SERVICE_ROLE_KEY=<ALREADY CONFIGURED>
\`\`\`

---

## Key Features Summary

\`\`\`
✅ Two Payment Modes
   ├─ Service Wise (25+ predefined services)
   └─ Custom Amount (any amount ≥ ₹100)

✅ Multiple Access Points
   ├─ Contact Form (after email verification)
   ├─ Floating Widget ("Pay Fee" button)
   └─ Footer ("Pay Now" link)

✅ Payment Processing
   ├─ Razorpay API integration (live keys)
   ├─ Signature verification (crypto)
   ├─ Database transaction tracking
   └─ Webhook support (optional)

✅ Email Receipts
   ├─ Automatic sending (Resend API)
   ├─ Professional HTML template
   ├─ Payment details included
   └─ Follow-up message included

✅ Database Integration
   ├─ Supabase payments table
   ├─ Payment history tracking
   ├─ User information storage
   └─ Reporting capabilities

✅ Security
   ├─ Signature verification
   ├─ Minimum amount validation
   ├─ Environment variable protection
   └─ Error handling (safe messages)
\`\`\`

---

**System Status**: 🟢 PRODUCTION READY

**Next Step**: Add RAZORPAY_KEY_SECRET to environment variables and deploy!
