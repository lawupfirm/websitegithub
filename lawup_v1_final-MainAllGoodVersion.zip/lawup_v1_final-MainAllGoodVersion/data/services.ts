export interface ServiceFee {
  id: string
  name: string
  category: string
  minFee: number
  maxFee?: number
  description: string
}

export const serviceFees: ServiceFee[] = [
  // Consultation & Advisory Services
  {
    id: "initial-consultation",
    name: "Initial Legal Consultation (30-60 minutes)",
    category: "Consultation & Advisory",
    minFee: 4000,
    description: "Initial consultation to understand your legal needs",
  },
  {
    id: "follow-up-consultation",
    name: "Follow-up Consultation",
    category: "Consultation & Advisory",
    minFee: 2500,
    description: "Subsequent consultations for case progression",
  },
  {
    id: "monthly-retainer",
    name: "Monthly Retainer (General Legal Advisory)",
    category: "Consultation & Advisory",
    minFee: 20000,
    description: "Ongoing monthly legal advisory services",
  },
  {
    id: "legal-opinion",
    name: "Opinion on Legal Matter (Written)",
    category: "Consultation & Advisory",
    minFee: 15000,
    description: "Detailed written legal opinion on specific matters",
  },

  // Drafting Services
  {
    id: "legal-notice-drafting",
    name: "Legal Notice Drafting",
    category: "Drafting Services",
    minFee: 4000,
    description: "Preparation of formal legal notice",
  },
  {
    id: "reply-to-notice",
    name: "Reply to Legal Notice",
    category: "Drafting Services",
    minFee: 5000,
    description: "Response to legal notice received",
  },
  {
    id: "vakalatnama-preparation",
    name: "Vakalatnama Preparation & Filing",
    category: "Drafting Services",
    minFee: 1500,
    description: "Preparation and filing of power of attorney for legal proceedings",
  },
  {
    id: "affidavit-drafting",
    name: "Affidavit Drafting",
    category: "Drafting Services",
    minFee: 2000,
    description: "Preparation of sworn affidavits",
  },
  {
    id: "plaint-written-statement",
    name: "Plaint / Written Statement Drafting",
    category: "Drafting Services",
    minFee: 35000,
    description: "Drafting of pleadings for civil litigation",
  },
  {
    id: "bail-application",
    name: "Bail Application Drafting",
    category: "Drafting Services",
    minFee: 12000,
    description: "Preparation of bail applications in criminal matters",
  },
  {
    id: "appeal-petition",
    name: "Appeal / Revision Petition Drafting",
    category: "Drafting Services",
    minFee: 50000,
    description: "Drafting of appeal and revision petitions",
  },
  {
    id: "writ-petition",
    name: "Writ Petition Drafting",
    category: "Drafting Services",
    minFee: 75000,
    description: "Preparation of writ petitions for High Court",
  },
  {
    id: "contract-drafting",
    name: "Contract / Agreement Drafting (Standard)",
    category: "Drafting Services",
    minFee: 18000,
    description: "Preparation of standard contracts and agreements",
  },
  {
    id: "complex-contract",
    name: "Complex Commercial Contract Drafting",
    category: "Drafting Services",
    minFee: 70000,
    description: "Drafting of complex commercial agreements",
  },
  {
    id: "will-drafting",
    name: "Will / Testament Drafting",
    category: "Drafting Services",
    minFee: 8000,
    description: "Preparation of wills and testaments",
  },
  {
    id: "power-of-attorney",
    name: "Power of Attorney Drafting",
    category: "Drafting Services",
    minFee: 4000,
    description: "Preparation of power of attorney documents",
  },

  // Court Appearance Fees
  {
    id: "district-court-appearance",
    name: "District Court / Trial Court Appearance",
    category: "Court Appearance",
    minFee: 5500,
    description: "Per hearing fee for district and trial courts",
  },
  {
    id: "high-court-appearance",
    name: "High Court Appearance",
    category: "Court Appearance",
    minFee: 15000,
    description: "Per hearing fee for High Court",
  },
  {
    id: "supreme-court-appearance",
    name: "Supreme Court of India Appearance",
    category: "Court Appearance",
    minFee: 30000,
    description: "Per hearing fee for Supreme Court",
  },

  // Comprehensive Case Handling
  {
    id: "criminal-case",
    name: "Criminal Case (Sessions Court)",
    category: "Comprehensive Case Handling",
    minFee: 350000,
    description: "Lump sum fee for complete criminal case handling",
  },
  {
    id: "bail-application-lump",
    name: "Bail Application (Regular/Anticipatory)",
    category: "Comprehensive Case Handling",
    minFee: 350000,
    description: "Complete bail application handling",
  },
  {
    id: "civil-suit",
    name: "Civil Suit (District Court)",
    category: "Comprehensive Case Handling",
    minFee: 250000,
    description: "Comprehensive civil suit handling",
  },
  {
    id: "property-dispute",
    name: "Property Dispute Litigation",
    category: "Comprehensive Case Handling",
    minFee: 350000,
    description: "Complete property dispute case handling",
  },
  {
    id: "cheque-bounce",
    name: "Cheque Bounce Case (NI Act Section 138)",
    category: "Comprehensive Case Handling",
    minFee: 25000,
    maxFee: 200000,
    description: "Cheque bounce case handling",
  },
  {
    id: "divorce-contested",
    name: "Divorce Case (Contested)",
    category: "Comprehensive Case Handling",
    minFee: 75000,
    maxFee: 300000,
    description: "Contested divorce case handling",
  },
  {
    id: "divorce-mutual",
    name: "Divorce Case (Mutual Consent)",
    category: "Comprehensive Case Handling",
    minFee: 20000,
    maxFee: 50000,
    description: "Mutual consent divorce handling",
  },
  {
    id: "consumer-complaint",
    name: "Consumer Complaint",
    category: "Comprehensive Case Handling",
    minFee: 15000,
    maxFee: 100000,
    description: "Consumer protection case handling",
  },
  {
    id: "arbitration",
    name: "Arbitration Proceedings",
    category: "Comprehensive Case Handling",
    minFee: 200000,
    maxFee: 2500000,
    description: "Arbitration case handling",
  },
  {
    id: "writ-petition-case",
    name: "Writ Petition (High Court)",
    category: "Comprehensive Case Handling",
    minFee: 100000,
    maxFee: 500000,
    description: "High Court writ petition handling",
  },
  {
    id: "corporate-litigation",
    name: "Corporate / Commercial Litigation",
    category: "Comprehensive Case Handling",
    minFee: 200000,
    maxFee: 5000000,
    description: "Corporate and commercial litigation handling",
  },

  // Specialized Services
  {
    id: "police-appearance",
    name: "Police Station Appearance",
    category: "Specialized Services",
    minFee: 12000,
    description: "Appearance at police station for client",
  },
  {
    id: "due-diligence",
    name: "Due Diligence (Property/Commercial)",
    category: "Specialized Services",
    minFee: 45000,
    description: "Comprehensive due diligence review",
  },
  {
    id: "document-verification",
    name: "Document Verification & Review",
    category: "Specialized Services",
    minFee: 9000,
    description: "Review and verification of documents",
  },
  {
    id: "property-search",
    name: "Property Title Search & Verification",
    category: "Specialized Services",
    minFee: 18000,
    description: "Property title verification and search",
  },
  {
    id: "registration-services",
    name: "Registration & Documentation Services",
    category: "Specialized Services",
    minFee: 35000,
    description: "Legal registration and documentation services",
  },
  {
    id: "legal-research",
    name: "Legal Research & Case Law Analysis",
    category: "Specialized Services",
    minFee: 20000,
    description: "Comprehensive legal research and analysis",
  },
  {
    id: "company-incorporation",
    name: "Company Incorporation & Compliance",
    category: "Specialized Services",
    minFee: 25000,
    description: "Company incorporation and compliance services",
  },
  {
    id: "trademark-copyright",
    name: "Trademark/Copyright Registration",
    category: "Specialized Services",
    minFee: 15000,
    description: "Intellectual property registration",
  },
  {
    id: "dsc-emudhra",
    name: "Digital Signature Certificate (DSC) - eMudhra",
    category: "Specialized Services",
    minFee: 2500,
    description: "Class 3 Digital Signature Certificate from eMudhra (1 year)",
  },
  {
    id: "dsc-speedsign",
    name: "Digital Signature Certificate (DSC) - SpeedSignCA",
    category: "Specialized Services",
    minFee: 849,
    description: "Class 3 Digital Signature Certificate from SpeedSignCA - ₹849 (1yr), ₹990 (2yr), ₹1500 (3yr) + GST",
  },
  {
    id: "dsc-renewal",
    name: "DSC Renewal & Token Management",
    category: "Specialized Services",
    minFee: 5000,
    description: "Digital Signature Certificate renewal and USB token management services",
  },
  {
    id: "mediation-settlement",
    name: "Mediation / Settlement Negotiation",
    category: "Specialized Services",
    minFee: 100000,
    description: "Mediation and settlement services",
  },
]

// Export as SERVICES for payment modal compatibility
export const SERVICES = serviceFees.map((service) => ({
  id: service.id,
  name: service.name,
  category: service.category,
  startingFee: service.minFee,
  description: service.description,
}))
