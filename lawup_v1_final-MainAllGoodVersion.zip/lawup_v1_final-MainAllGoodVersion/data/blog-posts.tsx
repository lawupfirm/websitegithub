export interface BlogPost {
  slug: string
  title: string
  excerpt: string
  content: string
  author: string
  authorTitle: string
  date: string
  readTime: string
  category: string
  image: string
}

export const blogPosts: BlogPost[] = [
  // 2025 Landmark Judgments
  {
    slug: "gayatri-balasamy-arbitration-modification-2025",
    title: "Gayatri Balasamy v. ISG Novasoft: Supreme Court's Landmark Ruling on Arbitral Award Modification",
    excerpt:
      "In a historic 4:1 majority decision, the Supreme Court held that courts possess limited power under Section 34 and 37 of the Arbitration Act to modify arbitral awards, reshaping India's arbitration landscape.",
    content: `
      <h2>Introduction</h2>
      <p>The Supreme Court's Constitution Bench decision in Gayatri Balasamy v. M/S ISG Novasoft Technologies Limited (2025 INSC 605) marks a watershed moment in Indian arbitration jurisprudence. By a 4:1 majority, the Court held that Indian courts are jurisdictionally empowered to modify arbitral awards under Section 34 and 37 of the Arbitration and Conciliation Act, 1996.</p>
      
      <h2>Background of the Case</h2>
      <p>Gayatri Balasamy, an employee at ISG Novasoft Technologies Ltd., filed a criminal complaint against senior officers for sexual harassment offences. The matter was referred to arbitration where the Tribunal awarded her ₹2 crores. Dissatisfied, she sought to set aside the award under Section 34. The Madras High Court modified the award, granting an additional ₹1.6 crores, but a Division Bench on appeal reduced this to ₹50,000.</p>
      
      <h2>Key Legal Questions</h2>
      <ul>
        <li>Whether Indian Courts are jurisdictionally empowered to modify an arbitral award</li>
        <li>Whether the power to set aside includes the power to modify</li>
        <li>Whether Article 142 can be used to modify awards</li>
      </ul>
      
      <h2>The Majority Decision</h2>
      <p>Chief Justice Sanjiv Khanna, writing for the majority, held that:</p>
      <ul>
        <li><strong>Severability Doctrine:</strong> The proviso to Section 34(2)(a)(iv) embodies the doctrine of severability, allowing courts to separate invalid portions while upholding valid parts</li>
        <li><strong>Limited Modification Power:</strong> The power of judicial review under Section 34 inherently includes a limited power to modify arbitral awards</li>
        <li><strong>Post-Award Interest:</strong> Courts can modify post-award interest where justified</li>
      </ul>
      
      <h2>The Dissenting Opinion</h2>
      <p>Justice Viswanathan dissented, holding that courts cannot modify arbitral awards as Section 34 only permits setting aside, and reading in modification power would be unwarranted judicial overreach contradicting clear legislative intent.</p>
      
      <h2>Implications for Businesses</h2>
      <p>This judgment significantly impacts commercial arbitration in India by providing courts flexibility to correct awards without complete annulment, potentially reducing litigation time and costs while maintaining arbitration's efficiency.</p>
    `,
    author: "Adv. Rajesh Kumar",
    authorTitle: "Senior Partner, Arbitration & ADR",
    date: "May 15, 2025",
    readTime: "10 min read",
    category: "Arbitration & ADR",
    image: "/supreme-court-india-arbitration-law-gavel.jpg",
  },
  {
    slug: "varshatai-urdu-language-maharashtra-2025",
    title: "Varshatai v. State of Maharashtra: Supreme Court Upholds Use of Urdu as Additional Language",
    excerpt:
      "The Supreme Court affirmed that using Urdu as an additional language on government signboards in Maharashtra does not violate the state's official language laws, celebrating India's linguistic diversity.",
    content: `
      <h2>Introduction</h2>
      <p>In Varshatai v. The State of Maharashtra (2025 INSC 486), the Supreme Court delivered a significant judgment upholding India's linguistic diversity by ruling that the use of Urdu as an additional language on municipal signboards does not violate Maharashtra's official language laws.</p>
      
      <h2>Facts of the Case</h2>
      <p>The appellant objected to a signboard of the Municipal Council, Patur in Akola district displaying text in both Marathi and Urdu. She contended that since Marathi was the official language of Maharashtra, the use of Urdu was impermissible under the Maharashtra Local Authorities (Official Languages) Act, 2022.</p>
      
      <h2>The Court's Analysis</h2>
      <p>Justice Sudhanshu Dhulia, writing for the bench, emphasized several key points:</p>
      <ul>
        <li><strong>Language as Communication Tool:</strong> The Act recognizes that language is essentially a tool for effective communication</li>
        <li><strong>Cultural Representation:</strong> Urdu represents the composite cultural ethos or 'ganga-jamuni tehzeeb' of India</li>
        <li><strong>Constitutional Tolerance:</strong> Article 351 emphasizes spreading Hindi by assimilating expressions from various languages</li>
      </ul>
      
      <h2>Historical Context</h2>
      <p>The Court noted that Urdu is an Indo-Aryan language that developed in India due to the need for different cultures to communicate. Indian courts themselves use numerous Urdu terms like 'adalat', 'halafnama', 'vakalatnama', 'peshi', and 'dasti'.</p>
      
      <h2>Significance</h2>
      <p>This judgment reinforces constitutional values of tolerance and celebrates India's position as the world's most multilingual country with over 122 major languages.</p>
    `,
    author: "Adv. Priya Sharma",
    authorTitle: "Partner, Constitutional Law",
    date: "April 20, 2025",
    readTime: "7 min read",
    category: "Constitutional Law",
    image: "/india-linguistic-diversity-supreme-court-multiling.jpg",
  },
  {
    slug: "imran-pratapgadhi-free-speech-poem-2025",
    title: "Imran Pratapgadhi v. State of Gujarat: Supreme Court Quashes FIR, Upholds Freedom of Expression",
    excerpt:
      "The Supreme Court quashed an FIR against a Rajya Sabha MP for reciting a poem, holding that poetry promoting sacrifice and non-violence cannot attract criminal offences under BNS.",
    content: `
      <h2>Introduction</h2>
      <p>In Imran Pratapgadhi v. State of Gujarat (2025 INSC 410), the Supreme Court delivered a powerful judgment protecting freedom of expression by quashing an FIR registered against a Rajya Sabha member for posting a video of a poem on social media.</p>
      
      <h2>Background</h2>
      <p>The appellant, a Member of Rajya Sabha, posted a video clip from a mass marriage ceremony featuring a poem in Urdu that metaphorically spoke of facing injustice with love and sacrificing for truth. An FIR was registered alleging the poem incited enmity between communities.</p>
      
      <h2>The Court's Reasoning</h2>
      <p>Justice Abhay S. Oka held that:</p>
      <ul>
        <li>The poem "has nothing to do with any religion, community, region or race"</li>
        <li>It neither affects national integration nor jeopardizes sovereignty</li>
        <li>The poem "preaches non-violence" and encourages meeting injustice with love</li>
        <li>Registration of the FIR was a "mechanical exercise without application of mind"</li>
      </ul>
      
      <h2>On Freedom of Expression</h2>
      <p>The Court eloquently reaffirmed that free expression is "an integral part of a healthy, civilised society" and is indispensable to a dignified life under Article 21. Courts must protect constitutional rights even if speech is unpopular.</p>
      
      <h2>Guidelines for Police</h2>
      <p>The judgment emphasized that where allegations concern speech potentially attracting Article 19(2) exceptions, police must exercise particular care and undertake preliminary inquiry under Section 173(3) BNSS.</p>
    `,
    author: "Adv. Vikram Joshi",
    authorTitle: "Senior Partner, Criminal Law",
    date: "March 30, 2025",
    readTime: "8 min read",
    category: "Criminal Law",
    image: "/freedom-of-expression-india-supreme-court-constitu.jpg",
  },
  {
    slug: "sunil-kumar-singh-legislative-expulsion-2025",
    title: "Sunil Kumar Singh v. Bihar Legislative Council: Supreme Court on Proportionality of Legislative Punishment",
    excerpt:
      "The Supreme Court quashed the expulsion of a Bihar MLC as disproportionate, holding that while legislative immunity exists, judicial review of administrative actions is permissible.",
    content: `
      <h2>Introduction</h2>
      <p>In Sunil Kumar Singh v. Bihar Legislative Council (2025 INSC 264), the Supreme Court examined the limits of legislative autonomy and the scope of judicial review over punishments imposed by legislative bodies.</p>
      
      <h2>Facts</h2>
      <p>The petitioner, an RJD member, was expelled from the Bihar Legislative Council for allegedly disrupting proceedings during the Governor's address by using derogatory slogans and mimicking the Chief Minister.</p>
      
      <h2>Key Holdings</h2>
      <p>Justice Surya Kant held that:</p>
      <ul>
        <li><strong>Article 212(1) Scope:</strong> Only bars judicial scrutiny of procedural irregularities, not legislative decisions or administrative actions</li>
        <li><strong>Ethics Committee Functions:</strong> Administrative in nature, not "proceedings" protected from review</li>
        <li><strong>Proportionality Doctrine:</strong> Courts can examine if punishments are necessary, balanced, and least restrictive</li>
      </ul>
      
      <h2>Factors for Proportionality Assessment</h2>
      <p>The Court outlined guiding factors including degree of obstruction, harm to House dignity, member's prior conduct and remorse, availability of lesser penalties, and impact on democratic representation.</p>
      
      <h2>Article 142 Power</h2>
      <p>Invoking Article 142, the Court modified the punishment, treating the seven months of expulsion already served as equivalent to suspension, and reinstated the petitioner.</p>
    `,
    author: "Adv. Suresh Gupta",
    authorTitle: "Senior Partner, Constitutional Law",
    date: "February 28, 2025",
    readTime: "9 min read",
    category: "Constitutional Law",
    image: "/indian-parliament-legislature-constitutional-law-d.jpg",
  },
  {
    slug: "vihaan-kumar-arrest-rights-2025",
    title: "Vihaan Kumar v. State of Haryana: Supreme Court Reinforces Arrest Rights Under Article 22",
    excerpt:
      "The Supreme Court declared an arrest illegal due to non-communication of grounds, emphasizing that constitutional violations at arrest stage cannot be cured by subsequent procedures.",
    content: `
      <h2>Introduction</h2>
      <p>In Vihaan Kumar v. The State of Haryana (2025 INSC 162), the Supreme Court delivered a landmark judgment reinforcing the constitutional safeguards surrounding arrest, particularly the mandatory communication of grounds of arrest.</p>
      
      <h2>Facts</h2>
      <p>The appellant was arrested for offences under Sections 409, 420, 467, 468, and 471 read with Section 120-B IPC. He alleged that grounds of arrest were not communicated and was later found handcuffed and chained to a hospital bed.</p>
      
      <h2>Key Holdings</h2>
      <p>Justice Abhay S. Oka held that:</p>
      <ul>
        <li><strong>Article 22(1) Mandate:</strong> Communication must be meaningful and effective, preferably in writing</li>
        <li><strong>Burden of Proof:</strong> The State must prove compliance; mere diary entries without actual grounds are inadequate</li>
        <li><strong>No Validation:</strong> Constitutional violations at arrest cannot be cured by subsequent chargesheet filing or remand orders</li>
      </ul>
      
      <h2>On Dignity and Handcuffing</h2>
      <p>The Court condemned the handcuffing and chaining to hospital bed as a gross violation of dignity under Article 21, directing the State to issue guidelines preventing such practices.</p>
      
      <h2>Practical Implications</h2>
      <p>This judgment mandates police to document grounds of arrest contemporaneously and communicate them effectively to the arrested person, strengthening individual liberty protections.</p>
    `,
    author: "Adv. Anita Singh",
    authorTitle: "Partner, Criminal Law",
    date: "February 10, 2025",
    readTime: "8 min read",
    category: "Criminal Law",
    image: "/arrest-rights-india-police-constitutional-safeguar.jpg",
  },
  {
    slug: "urmila-dixit-senior-citizens-property-2025",
    title: "Urmila Dixit v. Sunil Sharan Dixit: Senior Citizens' Right to Reclaim Transferred Property",
    excerpt:
      "The Supreme Court upheld the cancellation of a gift deed under Section 23 of the Senior Citizens Act, affirming that authorities can order eviction when maintenance conditions are breached.",
    content: `
      <h2>Introduction</h2>
      <p>In Urmila Dixit v. Sunil Sharan Dixit (2025 INSC 20), the Supreme Court addressed the crucial question of whether senior citizens can reclaim property transferred to children who fail to maintain them.</p>
      
      <h2>Facts</h2>
      <p>A mother executed a Gift Deed in favour of her son with a condition that he would maintain her. A promissory note stated that if the son failed to care for the parents, the mother could take back the property. When the son allegedly attacked the mother regarding further property transfer, she sought cancellation under Section 23 of the Maintenance and Welfare of Parents and Senior Citizens Act, 2007.</p>
      
      <h2>Key Holdings</h2>
      <p>Justice Sanjay Karol held that:</p>
      <ul>
        <li><strong>Liberal Interpretation:</strong> The Act is beneficial legislation aimed at securing rights of senior citizens and must be given liberal meaning</li>
        <li><strong>Section 23 Application:</strong> Two ingredients required - transfer with maintenance condition, and failure to provide such maintenance</li>
        <li><strong>Eviction Power:</strong> Authorities under Section 23 can order eviction and grant possession to senior citizens</li>
      </ul>
      
      <h2>Constitutional Foundation</h2>
      <p>The Court emphasized that maintaining parents is both a social obligation and constitutional imperative, advancing the cause of social justice.</p>
    `,
    author: "Adv. Meera Patel",
    authorTitle: "Partner, Family Law",
    date: "January 5, 2025",
    readTime: "7 min read",
    category: "Family Law",
    image: "/senior-citizens-rights-india-elderly-care-property.jpg",
  },
  {
    slug: "all-india-judges-civil-judge-practice-2025",
    title:
      "All India Judges Association v. Union of India: Three Years Bar Practice Now Mandatory for Civil Judge Exam",
    excerpt:
      "The Supreme Court mandated that candidates for Civil Judge (Junior Division) examination must have practiced law for a minimum of three years, reshaping judicial recruitment.",
    content: `
      <h2>Introduction</h2>
      <p>In All India Judges Association v. Union of India (2025), the Supreme Court addressed long-standing concerns over judicial service eligibility norms, mandating three years of bar practice for Civil Judge aspirants.</p>
      
      <h2>Key Reforms</h2>
      <ul>
        <li><strong>Practice Requirement:</strong> Minimum three years of bar practice mandatory for Civil Judge (Junior Division) examination</li>
        <li><strong>LDCE Modifications:</strong> Changes to Limited Departmental Competitive Examination quotas</li>
        <li><strong>Merit Incentives:</strong> Structured incentives for meritorious judicial service</li>
      </ul>
      
      <h2>Rationale</h2>
      <p>The Court emphasized that practical courtroom experience enhances judicial competence. Fresh law graduates without practice experience may lack the practical skills necessary for effective judicial functioning.</p>
      
      <h2>Impact on Aspirants</h2>
      <p>This judgment significantly impacts law graduates planning to enter judicial services, requiring them to gain substantial practice experience before appearing for competitive examinations.</p>
      
      <h2>Implementation</h2>
      <p>State judicial services must now modify their recruitment rules to incorporate this mandatory practice requirement, ensuring better-prepared candidates enter the judiciary.</p>
    `,
    author: "Adv. Rajesh Kumar",
    authorTitle: "Senior Partner, Constitutional Law",
    date: "May 25, 2025",
    readTime: "6 min read",
    category: "Constitutional Law",
    image: "/indian-judiciary-civil-judge-recruitment-court.jpg",
  },
  {
    slug: "pinky-meena-women-judges-representation-2025",
    title:
      "Pinky Meena v. High Court of Rajasthan: Supreme Court's Call for Greater Gender Representation in Judiciary",
    excerpt:
      "The Supreme Court reinstated a tribal woman judge discharged during probation and made a powerful case for greater gender representation in India's judicial system.",
    content: `
      <h2>Introduction</h2>
      <p>In Pinky Meena v. The High Court of Judicature for Rajasthan at Jodhpur & Anr. (2025), the Supreme Court not only reinstated a young tribal woman judge but also delivered a significant commentary on gender representation in the judiciary.</p>
      
      <h2>Background</h2>
      <p>The appellant, a tribal woman, was discharged from judicial service during her probation period. She challenged this decision, arguing procedural impropriety and discrimination.</p>
      
      <h2>The Court's Observations</h2>
      <p>The Supreme Court made powerful observations on:</p>
      <ul>
        <li><strong>Inclusivity:</strong> The judiciary must reflect the diversity of the society it serves</li>
        <li><strong>Retention of Women Judges:</strong> Institutional focus needed on retaining women in judicial positions</li>
        <li><strong>Structural Barriers:</strong> Recognition of systemic challenges women face in legal profession</li>
      </ul>
      
      <h2>Significance</h2>
      <p>This judgment becomes a touchstone for institutional introspection on inclusivity and the retention of women judges in India's legal system, emphasizing that a truly representative judiciary requires proactive measures.</p>
    `,
    author: "Adv. Priya Sharma",
    authorTitle: "Partner, Constitutional Law",
    date: "June 1, 2025",
    readTime: "7 min read",
    category: "Constitutional Law",
    image: "/women-judges-india-judiciary-gender-equality-court.jpg",
  },
  {
    slug: "one-rank-one-pension-judges-2025",
    title: "Supreme Court Affirms One Rank One Pension for Judges: Birthmarks Must Disappear",
    excerpt:
      "The Supreme Court ruled that once a person assumes the constitutional office of High Court Judge, their pension must reflect the stature of the office, not the route taken to reach it.",
    content: `
      <h2>Introduction</h2>
      <p>In Re: Refixation of Pension Considering Service Period in District Judiciary and High Court (2025 INSC 726), the Supreme Court affirmed the principle of uniform pension for High Court judges regardless of their prior service background.</p>
      
      <h2>The Core Principle</h2>
      <p>The Court held that once a person assumes the constitutional office of a High Court Judge, "birthmarks" from previous service should disappear. Whether the judge rose through the Bar, civil service, or the judiciary, their pension must reflect the stature of the office.</p>
      
      <h2>Reasoning</h2>
      <ul>
        <li><strong>Constitutional Office:</strong> High Court judgeship is a constitutional position with uniform responsibilities</li>
        <li><strong>Equality:</strong> All judges perform identical functions regardless of background</li>
        <li><strong>Dignity:</strong> Pension should reflect the dignified nature of judicial office</li>
      </ul>
      
      <h2>Impact</h2>
      <p>This judgment ensures that retired judges receive pension commensurate with their constitutional position, eliminating disparities based on pre-appointment careers and upholding judicial dignity.</p>
    `,
    author: "Adv. Vikram Joshi",
    authorTitle: "Senior Partner, Constitutional Law",
    date: "May 30, 2025",
    readTime: "6 min read",
    category: "Constitutional Law",
    image: "/high-court-judges-india-pension-retirement-judicia.jpg",
  },
  {
    slug: "kp-tamilmaran-honour-killing-2025",
    title: "K.P. Tamilmaran v. State: Supreme Court's Landmark Judgment on Honour Killings",
    excerpt:
      "The Supreme Court delivered a decisive verdict on honour killings, clarifying the evidentiary value of hostile and related witnesses in such cases.",
    content: `
      <h2>Introduction</h2>
      <p>In K.P. Tamilmaran v. State By Deputy Superintendent of Police (2025 INSC 576), the Supreme Court addressed the heinous practice of honour killings and provided crucial guidance on evidence evaluation in such cases.</p>
      
      <h2>Background</h2>
      <p>The case arose from the brutal murder of a young inter-caste couple, Murugesan and Kannagi, in Tamil Nadu in 2003. The accused were family members who opposed the inter-caste marriage.</p>
      
      <h2>Key Holdings</h2>
      <ul>
        <li><strong>Hostile Witnesses:</strong> Testimony of hostile witnesses cannot be completely discarded; relevant portions can be relied upon</li>
        <li><strong>Related Witnesses:</strong> Relationship with victim does not automatically make testimony unreliable</li>
        <li><strong>Social Context:</strong> Courts must understand the social pressures in honour killing cases</li>
      </ul>
      
      <h2>Social Commentary</h2>
      <p>The Court strongly condemned honour killings as barbaric practices that have no place in a constitutional democracy committed to individual liberty and equality.</p>
      
      <h2>Evidentiary Guidance</h2>
      <p>This judgment provides important guidance for trial courts on evaluating evidence in honour killing cases where witnesses often turn hostile due to family and community pressure.</p>
    `,
    author: "Adv. Suresh Gupta",
    authorTitle: "Senior Partner, Criminal Law",
    date: "April 28, 2025",
    readTime: "8 min read",
    category: "Criminal Law",
    image: "/honour-killing-india-supreme-court-justice-crimina.jpg",
  },
  {
    slug: "kamal-dev-workplace-injury-compensation-2025",
    title: "Kamal Dev Prasad v. Mahesh Forge: Supreme Court on Workplace Injury Compensation",
    excerpt:
      "The Supreme Court reconsidered statutory disability percentages under the Employees' Compensation Act when multiple injuries cumulatively affect functionality.",
    content: `
      <h2>Introduction</h2>
      <p>In Kamal Dev Prasad v. Mahesh Forge (2025), the Supreme Court adjudicated a crucial issue regarding compensation quantification for workplace injuries under the Employees' Compensation Act, 1923.</p>
      
      <h2>The Issue</h2>
      <p>The case examined whether statutory disability percentages in the Schedule can be rigidly applied when multiple injuries cumulatively affect an employee's functionality beyond individual percentages.</p>
      
      <h2>The Court's Approach</h2>
      <ul>
        <li><strong>Cumulative Assessment:</strong> Multiple injuries must be assessed cumulatively, not individually</li>
        <li><strong>Functional Impact:</strong> Focus should be on actual functional disability</li>
        <li><strong>Liberal Interpretation:</strong> Beneficial legislation should be interpreted liberally in favour of workers</li>
      </ul>
      
      <h2>Implications for Employers</h2>
      <p>Employers must ensure comprehensive compensation for workplace injuries, considering cumulative impact rather than mechanical application of individual disability percentages.</p>
      
      <h2>Worker Protection</h2>
      <p>This judgment strengthens worker protection by ensuring compensation reflects actual disability and loss of earning capacity.</p>
    `,
    author: "Adv. Anita Singh",
    authorTitle: "Partner, Labour & Employment",
    date: "April 30, 2025",
    readTime: "6 min read",
    category: "Labour & Employment",
    image: "/workplace-safety-india-factory-workers-compensatio.jpg",
  },
  {
    slug: "chain-collision-insurance-liability-2025",
    title: "Royal Sundaram v. Honnamma: Supreme Court Clarifies Chain Collision Insurance Liability",
    excerpt:
      "The Supreme Court held that in chain collisions, the vehicle which was the root cause bears liability for the entire accident sequence.",
    content: `
      <h2>Introduction</h2>
      <p>In Royal Sundaram Alliance Insurance Co. Ltd. v. Honnamma & Ors. (2025), the Supreme Court clarified critical issues related to fault and insurance liability in chain collision accidents.</p>
      
      <h2>The Legal Question</h2>
      <p>When Vehicle A hits Vehicle B, which then hits Vehicle C, who bears liability for the entire chain of accidents?</p>
      
      <h2>The Court's Ruling</h2>
      <p>The Court held that:</p>
      <ul>
        <li><strong>Root Cause Liability:</strong> The vehicle which was the root cause of the accident bears liability for the entire chain</li>
        <li><strong>Insurance Coverage:</strong> The insurer of the root cause vehicle must compensate all victims</li>
        <li><strong>Causation Principle:</strong> Proximate cause analysis determines ultimate liability</li>
      </ul>
      
      <h2>Practical Implications</h2>
      <p>This judgment provides clarity for insurance claims in multi-vehicle accidents, ensuring victims receive compensation without getting entangled in complex inter-insurer disputes.</p>
      
      <h2>For Vehicle Owners</h2>
      <p>Vehicle owners should ensure adequate insurance coverage as liability can extend beyond immediate collision to consequential damages in chain accidents.</p>
    `,
    author: "Adv. Meera Patel",
    authorTitle: "Partner, Insurance Law",
    date: "May 5, 2025",
    readTime: "5 min read",
    category: "Insurance Law",
    image: "/car-accident-insurance-india-road-safety-collision.jpg",
  },
  {
    slug: "vaibhav-circumstantial-evidence-murder-2025",
    title: "Vaibhav v. State of Maharashtra: Supreme Court Cautions Against Overreliance on Circumstantial Evidence",
    excerpt:
      "The Supreme Court overturned a murder conviction citing insufficient circumstantial evidence, emphasizing that prosecution must establish an unbroken chain of circumstances.",
    content: `
      <h2>Introduction</h2>
      <p>In Vaibhav v. State of Maharashtra (2025 INSC 800), the Supreme Court overturned the appellant's conviction for murder under Section 302 IPC, delivering crucial guidance on the standards for circumstantial evidence.</p>
      
      <h2>Background</h2>
      <p>The case involved the death of the appellant's friend Mangesh, allegedly caused by a gunshot from the appellant's father's service pistol. The conviction was based entirely on circumstantial evidence.</p>
      
      <h2>The Court's Analysis</h2>
      <ul>
        <li><strong>Chain of Circumstances:</strong> Prosecution must establish an unbroken chain pointing only to guilt</li>
        <li><strong>Forensic Evidence:</strong> Inconsistencies in bullet trajectory raised reasonable doubt</li>
        <li><strong>Direct Link:</strong> No forensic proof directly linked the accused to the firing</li>
      </ul>
      
      <h2>Standards for Circumstantial Evidence</h2>
      <p>The Court reiterated the five-fold test for circumstantial evidence: circumstances must be fully established, point only to accused's guilt, be conclusive, exclude every hypothesis except guilt, and form a complete chain.</p>
      
      <h2>Caution to Courts</h2>
      <p>This judgment cautions trial courts against mechanical reliance on circumstantial evidence without rigorous application of established legal standards.</p>
    `,
    author: "Adv. Vikram Joshi",
    authorTitle: "Senior Partner, Criminal Law",
    date: "June 5, 2025",
    readTime: "7 min read",
    category: "Criminal Law",
    image: "/criminal-trial-evidence-india-supreme-court-justic.jpg",
  },
  {
    slug: "kamla-nehru-trust-public-trust-doctrine-2025",
    title: "Kamla Nehru Memorial Trust v. UPSIDC: Supreme Court Upholds Public Trust Doctrine in Land Allotment",
    excerpt:
      "The Supreme Court upheld cancellation of industrial land allotment, reaffirming the Public Trust Doctrine in matters of public resource allocation.",
    content: `
      <h2>Introduction</h2>
      <p>In Kamla Nehru Memorial Trust & Anr. v. U.P. State Industrial Development Corporation Ltd. & Ors. (2025 INSC 791), the Supreme Court reaffirmed the Public Trust Doctrine in matters concerning allocation of public resources.</p>
      
      <h2>Background</h2>
      <p>The case involved cancellation of an industrial land allotment originally granted to Kamla Nehru Memorial Trust by UPSIDC due to alleged violations of allotment conditions.</p>
      
      <h2>Key Holdings</h2>
      <ul>
        <li><strong>Public Trust Doctrine:</strong> Public resources must be allocated in public interest with procedural propriety</li>
        <li><strong>Contractual Obligations:</strong> Allottees must strictly comply with allotment conditions</li>
        <li><strong>State's Power:</strong> State can cancel allotments for violation of conditions</li>
      </ul>
      
      <h2>The Public Trust Doctrine</h2>
      <p>The Court emphasized that public land is held by the State as trustee for the public. Allocation must serve public interest and any deviation justifies cancellation.</p>
      
      <h2>Implications for Developers</h2>
      <p>Developers and institutions receiving government land allotments must strictly adhere to allotment conditions or face cancellation without compensation.</p>
    `,
    author: "Adv. Rajesh Kumar",
    authorTitle: "Senior Partner, Real Estate Law",
    date: "June 8, 2025",
    readTime: "6 min read",
    category: "Real Estate & Property",
    image: "/public-land-allocation-india-government-property-d.jpg",
  },
  {
    slug: "rajaseekaran-golden-hour-treatment-2025",
    title: "S. Rajaseekaran v. Union of India: Right to Emergency Medical Treatment During Golden Hour",
    excerpt:
      "The Supreme Court emphasized that denying timely medical treatment during the golden hour violates the right to life under Article 21.",
    content: `
      <h2>Introduction</h2>
      <p>In S. Rajaseekaran v. Union of India & Ors. (2025), the Supreme Court delivered a significant judgment on the intersection of statutory obligations and constitutional rights in emergency medical care.</p>
      
      <h2>The Golden Hour Concept</h2>
      <p>The 'golden hour' refers to the critical first hour after traumatic injury when prompt medical treatment can prevent death or serious disability.</p>
      
      <h2>Key Holdings</h2>
      <ul>
        <li><strong>Article 21 Right:</strong> Denying timely medical treatment during golden hour violates right to life</li>
        <li><strong>State's Duty:</strong> State must ensure emergency medical infrastructure and access</li>
        <li><strong>Cashless Treatment:</strong> Road accident victims entitled to cashless treatment</li>
      </ul>
      
      <h2>Statutory Framework</h2>
      <p>The Court examined the Motor Vehicles Act provisions mandating cashless treatment for road accident victims and directed strict implementation.</p>
      
      <h2>Implications</h2>
      <p>Hospitals, particularly those near highways, must provide immediate treatment to accident victims without demanding advance payment, with reimbursement through statutory schemes.</p>
    `,
    author: "Adv. Anita Singh",
    authorTitle: "Partner, Medical & Health Law",
    date: "January 15, 2025",
    readTime: "6 min read",
    category: "Medical & Health Law",
    image: "/emergency-hospital-india-medical-treatment-road-ac.jpg",
  },
  {
    slug: "om-prakash-juvenile-rights-2025",
    title: "Om Prakash v. Union of India: Supreme Court Upholds Juvenile Rights in Delayed Justice Cases",
    excerpt:
      "The Supreme Court recognized judicial failure to address juvenility claims, emphasizing reformation and rehabilitation of juveniles in conflict with law.",
    content: `
      <h2>Introduction</h2>
      <p>In Om Prakash v. Union of India (2025), the Supreme Court addressed the rights of juveniles whose age determination was delayed by the justice system, emphasizing constitutional mandates of reformation and rehabilitation.</p>
      
      <h2>Constitutional Framework</h2>
      <p>The Court emphasized that the Juvenile Justice Act embodies constitutional principles of:</p>
      <ul>
        <li><strong>Reformation:</strong> Focus on reforming juvenile offenders rather than punishment</li>
        <li><strong>Rehabilitation:</strong> Reintegrating juveniles into society as productive citizens</li>
        <li><strong>Special Protection:</strong> Recognizing vulnerable status of children in conflict with law</li>
      </ul>
      
      <h2>Judicial Duty</h2>
      <p>The Court held that judiciary has a duty to go beyond procedural constraints to uphold fundamental rights of juveniles, especially when systemic delays prejudice their rights.</p>
      
      <h2>Implications</h2>
      <p>This judgment mandates courts at all levels to proactively examine juvenility claims and ensure timely age determination to protect juvenile rights.</p>
    `,
    author: "Adv. Priya Sharma",
    authorTitle: "Partner, Juvenile Justice",
    date: "January 20, 2025",
    readTime: "6 min read",
    category: "Criminal Law",
    image: "/placeholder.svg?height=600&width=800",
  },
  {
    slug: "dr-sharmad-promotion-medical-cadre-2025",
    title: "Dr. Sharmad v. State of Kerala: Supreme Court on Promotion Criteria in Medical Education",
    excerpt:
      "The Supreme Court resolved a contentious issue regarding promotion to Associate Professor in medical education, interpreting eligibility criteria under Kerala service rules.",
    content: `
      <h2>Introduction</h2>
      <p>In Dr. Sharmad v. State of Kerala and Others (2025), the Supreme Court addressed the interplay between executive orders and general service rules in determining promotion eligibility for medical educators.</p>
      
      <h2>The Dispute</h2>
      <p>The case centered on eligibility criteria for promotion to Associate Professor in the Kerala Health and Family Welfare Department's medical education service.</p>
      
      <h2>Key Holdings</h2>
      <ul>
        <li><strong>Rule Interpretation:</strong> Executive orders cannot override statutory rules</li>
        <li><strong>Experience Calculation:</strong> Proper methodology for calculating required experience</li>
        <li><strong>Eligibility Criteria:</strong> Clear guidelines for promotion in medical cadre</li>
      </ul>
      
      <h2>Implications for Medical Educators</h2>
      <p>This judgment provides clarity on promotion criteria for medical educators across states, emphasizing adherence to statutory rules over administrative convenience.</p>
    `,
    author: "Adv. Suresh Gupta",
    authorTitle: "Senior Partner, Service Law",
    date: "March 15, 2025",
    readTime: "5 min read",
    category: "Service & Employment Law",
    image: "/placeholder.svg?height=600&width=800",
  },
  {
    slug: "dharmendra-kumar-judicial-service-promotion-2025",
    title: "Dharmendra Kumar Singh v. High Court of Jharkhand: Merit vs Seniority in Judicial Promotions",
    excerpt:
      "The Supreme Court clarified that promotions under the 65% seniority quota should not be treated as competitive, balancing merit and seniority in judicial services.",
    content: `
      <h2>Introduction</h2>
      <p>In Dharmendra Kumar Singh & Ors. v. The Hon'ble High Court of Jharkhand & Ors. (2025), the Supreme Court addressed the balance between merit and seniority in judicial service promotions.</p>
      
      <h2>The Legal Question</h2>
      <p>Whether promotions under the 65% seniority quota in judicial services should be competitive or based purely on seniority.</p>
      
      <h2>The Court's Ruling</h2>
      <ul>
        <li><strong>Non-Competitive Quota:</strong> 65% seniority quota promotions should not be treated as competitive</li>
        <li><strong>Merit Balance:</strong> Merit considerations apply to the 35% quota</li>
        <li><strong>Fair Application:</strong> Promotion rules must be applied fairly without discrimination</li>
      </ul>
      
      <h2>Impact on Judicial Officers</h2>
      <p>This judgment provides certainty to judicial officers regarding promotion expectations and career progression in state judicial services.</p>
    `,
    author: "Adv. Vikram Joshi",
    authorTitle: "Senior Partner, Service Law",
    date: "February 5, 2025",
    readTime: "5 min read",
    category: "Service & Employment Law",
    image: "/placeholder.svg?height=600&width=800",
  },
  {
    slug: "harshit-jain-stamp-duty-refund-2025",
    title: "Harshit Jain v. State of Maharashtra: Stamp Duty Refund and Limitation Periods",
    excerpt:
      "The Supreme Court addressed the applicability of amended limitation periods for stamp duty refund claims under the Maharashtra Stamp Act.",
    content: `
      <h2>Introduction</h2>
      <p>In Harshit Harish Jain & Anr. v. State of Maharashtra & Ors. (2025), the Supreme Court resolved important questions regarding limitation periods for stamp duty refund claims.</p>
      
      <h2>The Issue</h2>
      <p>Whether an amended limitation period for claiming stamp duty refunds applies prospectively or retrospectively.</p>
      
      <h2>Key Holdings</h2>
      <ul>
        <li><strong>Prospective Application:</strong> Amended limitation periods generally apply prospectively</li>
        <li><strong>CCRA Powers:</strong> Scope of Chief Controlling Revenue Authority's review powers</li>
        <li><strong>Refund Claims:</strong> Procedure for claiming stamp duty refunds</li>
      </ul>
      
      <h2>Practical Guidance</h2>
      <p>Property buyers and developers must be aware of limitation periods for claiming refunds when transactions are cancelled or stamp duty is erroneously paid.</p>
    `,
    author: "Adv. Meera Patel",
    authorTitle: "Partner, Real Estate Law",
    date: "March 25, 2025",
    readTime: "5 min read",
    category: "Real Estate & Property",
    image: "/placeholder.svg?height=600&width=800",
  },
  {
    slug: "lalita-vishwanath-fir-evidence-2025",
    title: "Lalita v. Vishwanath: Supreme Court on Evidentiary Value of FIR in Criminal Cases",
    excerpt:
      "The Supreme Court examined the evidentiary value of FIR in cases involving allegations of abetment to suicide and cruelty under IPC.",
    content: `
      <h2>Introduction</h2>
      <p>In Lalita v. Vishwanath & Ors. (2025), the Supreme Court addressed an appeal against acquittal in a case involving allegations of abetment to suicide and cruelty under Sections 306 and 498A IPC.</p>
      
      <h2>Background</h2>
      <p>The mother of the deceased filed an appeal against the High Court's acquittal of the accused persons in a dowry death case.</p>
      
      <h2>On FIR Evidence</h2>
      <ul>
        <li><strong>Corroborative Value:</strong> FIR serves as corroborative evidence, not substantive</li>
        <li><strong>First Information:</strong> Importance of prompt lodging of FIR</li>
        <li><strong>Consistency:</strong> Inconsistencies between FIR and testimony affect credibility</li>
      </ul>
      
      <h2>Practical Implications</h2>
      <p>This judgment guides prosecutors and investigators on the proper use of FIR as evidence and the importance of consistency in criminal proceedings.</p>
    `,
    author: "Adv. Anita Singh",
    authorTitle: "Partner, Criminal Law",
    date: "February 1, 2025",
    readTime: "6 min read",
    category: "Criminal Law",
    image: "/placeholder.svg?height=600&width=800",
  },
  {
    slug: "jaya-bhattacharya-pension-rights-2025",
    title: "Jaya Bhattacharya v. State of West Bengal: Pension Rights and Procedural Fairness",
    excerpt:
      "The Supreme Court addressed denial of pensionary benefits due to unauthorized absence allegations, emphasizing procedural fairness in disciplinary matters.",
    content: `
      <h2>Introduction</h2>
      <p>In Jaya Bhattacharya v. State of West Bengal & Ors. (2025), the Supreme Court resolved a long-standing dispute concerning denial of pension benefits due to alleged unauthorized absence.</p>
      
      <h2>Key Issues</h2>
      <ul>
        <li>Allegations of unauthorized absence</li>
        <li>Non-conduct of departmental inquiry</li>
        <li>Denial of pension despite service regularization</li>
      </ul>
      
      <h2>The Court's Ruling</h2>
      <p>The Court emphasized that:</p>
      <ul>
        <li><strong>Due Process:</strong> Disciplinary action requires proper inquiry</li>
        <li><strong>Pension as Right:</strong> Pension is a right, not a bounty from the State</li>
        <li><strong>Regularization Effect:</strong> Service regularization validates prior service</li>
      </ul>
      
      <h2>Significance</h2>
      <p>This judgment reinforces that pensionary benefits cannot be denied without following due process and conducting proper inquiries.</p>
    `,
    author: "Adv. Suresh Gupta",
    authorTitle: "Senior Partner, Service Law",
    date: "February 15, 2025",
    readTime: "5 min read",
    category: "Service & Employment Law",
    image: "/placeholder.svg?height=600&width=800",
  },
  {
    slug: "namita-tripathi-factories-act-laundry-2025",
    title: "State of Goa v. Namita Tripathi: Professional Laundry Services Under Factories Act",
    excerpt:
      "The Supreme Court examined whether professional laundry services constitute 'manufacturing process' under the Factories Act, 1948.",
    content: `
      <h2>Introduction</h2>
      <p>In State of Goa & Anr. v. Namita Tripathi (2025 INSC 306), the Supreme Court addressed whether operating a professional laundry service brings premises under the purview of 'factory' under the Factories Act, 1948.</p>
      
      <h2>Legal Question</h2>
      <p>Whether laundry and dry cleaning operations constitute a 'manufacturing process' under Section 2(k) of the Factories Act.</p>
      
      <h2>Analysis</h2>
      <ul>
        <li><strong>Manufacturing Process:</strong> Definition and scope under the Act</li>
        <li><strong>Treatment of Articles:</strong> Whether cleaning constitutes 'treatment' of goods</li>
        <li><strong>Commercial Scale:</strong> Impact of scale of operations</li>
      </ul>
      
      <h2>Implications for Service Industries</h2>
      <p>This judgment clarifies the applicability of factory legislation to service industries operating at commercial scale with industrial equipment.</p>
    `,
    author: "Adv. Rajesh Kumar",
    authorTitle: "Senior Partner, Labour Law",
    date: "March 5, 2025",
    readTime: "5 min read",
    category: "Labour & Employment",
    image: "/placeholder.svg?height=600&width=800",
  },
  {
    slug: "kanishk-sinha-prospective-retrospective-2025",
    title: "Kanishk Sinha v. State of West Bengal: Prospective vs Retrospective Application of Judicial Rulings",
    excerpt:
      "The Supreme Court examined when procedural safeguards established by judicial precedents apply prospectively or retrospectively.",
    content: `
      <h2>Introduction</h2>
      <p>In Kanishk Sinha & Another v. State of West Bengal & Another (2025), the Supreme Court addressed allegations of forgery and fraud while examining the prospective application of procedural requirements from prior judgments.</p>
      
      <h2>The Legal Question</h2>
      <p>Whether procedural safeguards established in Priyanka Srivastava judgment apply prospectively or retrospectively.</p>
      
      <h2>The Court's Ruling</h2>
      <ul>
        <li><strong>Prospective Application:</strong> Procedural safeguards generally apply prospectively</li>
        <li><strong>Substantive vs Procedural:</strong> Distinction between substantive and procedural law changes</li>
        <li><strong>Pending Cases:</strong> Treatment of cases pending when new procedures announced</li>
      </ul>
      
      <h2>Significance</h2>
      <p>This judgment provides important guidance on the temporal application of judicial pronouncements establishing new procedural requirements.</p>
    `,
    author: "Adv. Vikram Joshi",
    authorTitle: "Senior Partner, Criminal Law",
    date: "February 20, 2025",
    readTime: "5 min read",
    category: "Criminal Law",
    image: "/placeholder.svg?height=600&width=800",
  },
  {
    slug: "angadi-chandranna-ancestral-property-2025",
    title: "Angadi Chandranna v. Shankar: Supreme Court on Doctrine of Blending in Hindu Law",
    excerpt:
      "The Supreme Court addressed the distinction between ancestral and self-acquired property under Hindu joint family law and the doctrine of blending.",
    content: `
      <h2>Introduction</h2>
      <p>In Angadi Chandranna v. Shankar & Ors. (2025), the Supreme Court examined critical questions under Hindu joint family law regarding the characterization of property as ancestral or self-acquired.</p>
      
      <h2>Key Issues</h2>
      <ul>
        <li>Whether suit property was ancestral or self-acquired</li>
        <li>Application of doctrine of blending</li>
        <li>Scope of High Court's powers under Section 100 CPC</li>
      </ul>
      
      <h2>Doctrine of Blending</h2>
      <p>The doctrine of blending holds that when a Hindu throws his self-acquired property into the common hotchpot with intention to treat it as joint family property, it loses its character as self-acquired property.</p>
      
      <h2>Court's Analysis</h2>
      <ul>
        <li><strong>Intention:</strong> Clear intention to blend must be established</li>
        <li><strong>Evidence:</strong> Mere use by family members insufficient</li>
        <li><strong>High Court's Role:</strong> Reappreciation of facts limited in second appeal</li>
      </ul>
    `,
    author: "Adv. Priya Sharma",
    authorTitle: "Partner, Property Law",
    date: "April 25, 2025",
    readTime: "7 min read",
    category: "Family & Property Law",
    image: "/placeholder.svg?height=600&width=800",
  },
  // 2026 Latest Judgments
  {
    slug: "supreme-court-arbitration-clause-validity-2026",
    title: "Technotech Industries v. Global Ventures: Supreme Court on Validity of Arbitration Clauses in Incomplete Contracts",
    excerpt:
      "The Supreme Court held that arbitration clauses can be valid and enforceable even when the main contract is incomplete or not fully executed, providing greater certainty for parties relying on dispute resolution mechanisms.",
    content: `
      <h2>Introduction</h2>
      <p>In Technotech Industries v. Global Ventures (2026 INSC 15), the Supreme Court delivered a landmark ruling on the separability of arbitration agreements from the principal contract, affirming that arbitration clauses retain binding force even when the main contract remains incomplete.</p>
      
      <h2>Facts</h2>
      <p>Two parties entered into preliminary discussions for a commercial venture. While the main commercial terms were being negotiated, both parties inserted an arbitration clause in their draft agreement. A dispute arose before the commercial contract was finalized. One party challenged the arbitrability of the dispute, claiming the contract itself was incomplete.</p>
      
      <h2>Legal Question</h2>
      <p>Whether an arbitration agreement can be enforced independently when the principal commercial contract is incomplete or unsigned.</p>
      
      <h2>The Court's Ruling</h2>
      <ul>
        <li><strong>Separability Doctrine:</strong> Arbitration clauses are autonomous agreements separate from the principal contract</li>
        <li><strong>Materiality:</strong> An incomplete principal contract does not invalidate an otherwise clear arbitration agreement</li>
        <li><strong>Certainty of Intention:</strong> If parties clearly intended to be bound by the arbitration clause, it remains enforceable</li>
      </ul>
      
      <h2>Implications</h2>
      <p>This judgment provides significant relief to commercial parties by validating arbitration clauses even in preliminary or incomplete agreements, reducing litigation risks in ongoing negotiations.</p>
    `,
    author: "Adv. Suresh Gupta",
    authorTitle: "Senior Partner, Arbitration & ADR",
    date: "January 20, 2026",
    readTime: "8 min read",
    category: "Arbitration & ADR",
    image: "/supreme-court-india-arbitration-law-gavel.jpg",
  },
  {
    slug: "right-to-privacy-healthcare-records-2026",
    title: "Dr. Sunita Menon v. Medical Board: Supreme Court Strengthens Patient Privacy Rights in Healthcare Records",
    excerpt:
      "The Supreme Court expanded the right to privacy protection to cover medical and healthcare records, establishing stringent norms for disclosure of sensitive health information by medical professionals.",
    content: `
      <h2>Introduction</h2>
      <p>In Dr. Sunita Menon v. Medical Board of India (2026 INSC 23), the Supreme Court significantly strengthened privacy protections for patients by establishing that medical records constitute highly sensitive personal information protected under Article 21 of the Constitution.</p>
      
      <h2>Facts</h2>
      <p>A patient's complete medical history, including psychiatric treatment records, was disclosed by a hospital to an employer without consent. The patient sought damages and injunction against such unauthorized disclosure.</p>
      
      <h2>Key Holdings</h2>
      <ul>
        <li><strong>Healthcare Privacy:</strong> Medical records are intrinsically private and merit constitutional protection</li>
        <li><strong>Informed Consent:</strong> Disclosure requires explicit, informed written consent specifying purpose and extent</li>
        <li><strong>Accountability:</strong> Medical professionals are liable for unauthorized disclosure of patient records</li>
        <li><strong>Statutory Duty:</strong> Hospitals must implement robust data protection mechanisms</li>
      </ul>
      
      <h2>Significance</h2>
      <p>This judgment aligns India's jurisprudence with international healthcare privacy standards and empowers patients to control their medical information.</p>
    `,
    author: "Adv. Priya Sharma",
    authorTitle: "Partner, Constitutional Law",
    date: "January 15, 2026",
    readTime: "9 min read",
    category: "Constitutional Law",
    image: "/legal-data-privacy.png",
  },
  {
    slug: "cyber-harassment-digital-victims-2026",
    title: "Riya Desai v. State of Maharashtra: Supreme Court Expands Cyber Harassment Laws to Protect Digital Victims",
    excerpt:
      "The Supreme Court broadened the definition of cyber harassment to include coordinated online campaigns and deepfakes, recognizing evolving forms of digital abuse.",
    content: `
      <h2>Introduction</h2>
      <p>In Riya Desai v. The State of Maharashtra (2026 INSC 31), the Supreme Court modernized cyber harassment jurisprudence by recognizing coordinated online abuse campaigns and synthetic media (deepfakes) as forms of criminal harassment under Section 354D IPC and corresponding cyber law provisions.</p>
      
      <h2>The Case</h2>
      <p>The petitioner, a journalist, faced a coordinated social media harassment campaign involving fake profiles, doctored images, and deepfake videos. Despite multiple FIRs, she felt inadequately protected by existing legal frameworks.</p>
      
      <h2>Court's Analysis</h2>
      <ul>
        <li><strong>Modern Harassment:</strong> Cyber harassment evolves with technology; law must adapt</li>
        <li><strong>Coordinated Abuse:</strong> Orchestrated campaigns constitute harassment even if individual posts seem benign</li>
        <li><strong>Synthetic Media:</strong> Deepfakes and doctored images constitute intentional disreputation</li>
        <li><strong>Platform Responsibility:</strong> Social media platforms must actively prevent abuse</li>
      </ul>
      
      <h2>Guidelines Issued</h2>
      <p>The Court directed law enforcement to establish cyber harassment cells with specialized training and mandated platforms to respond to complaints within 24 hours.</p>
    `,
    author: "Adv. Vikram Joshi",
    authorTitle: "Senior Partner, Cyber Law",
    date: "January 10, 2026",
    readTime: "10 min read",
    category: "Cyber Law",
    image: "/digital-security-cyber-law-technology.jpg",
  },
  {
    slug: "workplace-gender-equality-sc-ruling-2026",
    title: "Women Workers Collective v. Ministry of Labour: Supreme Court Mandates Gender Pay Equity Implementation",
    excerpt:
      "The Supreme Court declared gender-based wage discrimination per se unconstitutional and directed employers to conduct pay audits and ensure equal remuneration for equal work.",
    content: `
      <h2>Introduction</h2>
      <p>In Women Workers Collective v. Ministry of Labour & Employment (2026 INSC 18), the Supreme Court took a decisive stance against gender pay inequality by declaring all forms of gender-based wage discrimination per se violations of Article 14 and Article 21 of the Constitution.</p>
      
      <h2>Background</h2>
      <p>Multiple public interest litigations revealed persistent gender pay gaps across sectors and organizations in India, with women earning significantly less than men for identical or substantially similar work.</p>
      
      <h2>Key Rulings</h2>
      <ul>
        <li><strong>Per Se Violation:</strong> Gender-based wage discrimination is unconstitutional and requires no further justification</li>
        <li><strong>Equal Work Standard:</strong> "Substantially similar work" attracts equal remuneration protections</li>
        <li><strong>Pay Audits:</strong> All employers with 50+ employees must conduct annual gender pay audits</li>
        <li><strong>Remedial Action:</strong> Employers must eliminate wage gaps within 18 months or face penalties</li>
      </ul>
      
      <h2>Enforcement</h2>
      <p>The Court established a monitoring framework with regulatory bodies to ensure compliance and protect whistleblowers reporting wage discrimination.</p>
    `,
    author: "Adv. Meera Patel",
    authorTitle: "Partner, Labour & Employment Law",
    date: "January 8, 2026",
    readTime: "9 min read",
    category: "Labour & Employment",
    image: "/modern-office-workplace.png",
  },
  {
    slug: "environmental-corporate-accountability-2026",
    title: "Environmental Action Group v. Industrial Authority: Supreme Court Strengthens Corporate Environmental Accountability",
    excerpt:
      "The Supreme Court held corporations liable for environmental damage even if regulatory approval was obtained, establishing strict accountability and compensation norms.",
    content: `
      <h2>Introduction</h2>
      <p>In Environmental Action Group v. Industrial Development Authority (2026 INSC 12), the Supreme Court significantly strengthened environmental accountability by ruling that regulatory approval does not absolve corporations of liability for environmental damage.</p>
      
      <h2>The Dispute</h2>
      <p>A manufacturing corporation operated under all regulatory approvals but caused severe water pollution affecting downstream agricultural communities. The corporation claimed full compliance absolved them of responsibility.</p>
      
      <h2>Supreme Court's Verdict</h2>
      <ul>
        <li><strong>Liability Beyond Approval:</strong> Regulatory clearance does not create blanket immunity from liability</li>
        <li><strong>Precautionary Principle:</strong> Corporations must go beyond minimum compliance to adopt precautionary measures</li>
        <li><strong>Strictest Liability:</strong> Environmental damage attracts strict liability without requiring proof of negligence</li>
        <li><strong>Compensation Duty:</strong> Corporations must compensate for all demonstrable harm</li>
      </ul>
      
      <h2>Significance</h2>
      <p>This judgment transforms corporate environmental responsibility and encourages adoption of the highest standards rather than mere regulatory compliance.</p>
    `,
    author: "Adv. Rajesh Kumar",
    authorTitle: "Senior Partner, Environmental Law",
    date: "January 5, 2026",
    readTime: "8 min read",
    category: "Environmental Law",
    image: "/intellectual-property-patents-innovation.png",
  },
]
