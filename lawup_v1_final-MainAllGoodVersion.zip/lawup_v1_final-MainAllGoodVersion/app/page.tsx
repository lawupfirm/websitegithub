import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { HeroSection } from "@/components/hero-section"
import { ClientMarquee } from "@/components/client-marquee"
import { FeaturesSection } from "@/components/features-section"
import { AboutPreview } from "@/components/about-preview"
import { PracticeAreasPreview } from "@/components/practice-areas-preview"
import { HowItWorksSection } from "@/components/how-it-works-section"
import { TestimonialsSection } from "@/components/testimonials-section"
import { FAQSection } from "@/components/faq-section"
import { InsightsPreview } from "@/components/insights-preview"
import { CTASection } from "@/components/cta-section"
import { ScrollReveal } from "@/components/scroll-reveal"

export default function HomePage() {
  return (
    <div className="min-h-screen">
      <Navigation />

      {/* Hero Section */}
      <HeroSection />

      {/* Client Marquee */}
      <section className="py-12 bg-background border-b border-border">
        <ScrollReveal>
          <div className="text-center mb-8">
            <span className="text-sm text-muted-foreground uppercase tracking-widest">
              Trusted by Leading Organizations
            </span>
          </div>
          <ClientMarquee />
        </ScrollReveal>
      </section>

      <FeaturesSection />

      {/* About Preview */}
      <AboutPreview />

      {/* Practice Areas */}
      <PracticeAreasPreview />

      <HowItWorksSection />

      <TestimonialsSection />

      <FAQSection />

      {/* Insights */}
      <InsightsPreview />

      {/* CTA Section */}
      <CTASection />

      <Footer />
    </div>
  )
}
