"use client"

import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { PageHero } from "@/components/page-hero"
import { ScrollReveal } from "@/components/scroll-reveal"
import { FeeStructureSection } from "@/components/fee-structure-section"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { useState } from "react"
import {
  Gavel,
  Building,
  Home,
  Shield,
  Copyright,
  Users,
  Calculator,
  Monitor,
  FileCheck,
  ArrowRight,
  CheckCircle,
  Car,
  ShoppingBag,
  Heart,
  Scale,
  Globe,
  Leaf,
  Building2,
  Briefcase,
  Plane,
  ChevronDown,
} from "lucide-react"

const practiceAreas = [
  {
    id: "property-real-estate",
    icon: Home,
    title: "Property & Real Estate Lawyer",
    description:
      "Complete real estate legal services including property transactions, RERA compliance, development projects, title verification, and dispute resolution.",
    services: [
      "Property Documentation",
      "Title Verification",
      "Real Estate Transactions",
      "Land Disputes",
      "RERA Compliance",
      "Lease Agreements",
    ],
  },
  {
    id: "criminal-defense",
    icon: Gavel,
    title: "Criminal Defense Lawyer",
    description:
      "Expert criminal defense services including bail applications, FIR guidance, criminal proceedings representation, and defense strategy.",
    services: [
      "Criminal Defense",
      "Bail Applications",
      "FIR Guidance",
      "Court Representation",
      "Investigation Support",
      "Appeals & Acquittals",
    ],
  },
  {
    id: "civil-lawyer",
    icon: Scale,
    title: "Civil Lawyer",
    description:
      "Comprehensive civil litigation services covering disputes, contract matters, tort claims, and general civil proceedings.",
    services: [
      "Civil Disputes",
      "Contract Matters",
      "Tort Claims",
      "Civil Litigation",
      "Recovery Suits",
      "Injunction Matters",
    ],
  },
  {
    id: "family-lawyer",
    icon: Heart,
    title: "Family Lawyer",
    description:
      "Compassionate family law services including divorce, custody, maintenance, domestic violence, and family disputes.",
    services: [
      "Divorce Proceedings",
      "Child Custody",
      "Domestic Violence",
      "Alimony Cases",
      "Adoption Matters",
      "Inheritance Disputes",
    ],
  },
  {
    id: "divorce-lawyer",
    icon: Heart,
    title: "Divorce Lawyer",
    description:
      "Specialized divorce legal services including mutual divorce, contested divorce, alimony, maintenance, and custody matters.",
    services: [
      "Mutual Divorce Filing",
      "Contested Divorce",
      "Child Custody",
      "Alimony & Maintenance",
      "Property Settlement",
      "Separation Agreements",
    ],
  },
  {
    id: "corporate-lawyer",
    icon: Building,
    title: "Corporate Lawyer",
    description:
      "End-to-end corporate legal solutions covering company formation, governance, compliance, mergers, acquisitions, and restructuring.",
    services: [
      "Business Registration",
      "Corporate Compliance",
      "M&A Support",
      "Governance",
      "Corporate Restructuring",
      "Securities Law",
    ],
  },
  {
    id: "cyber-crime",
    icon: Monitor,
    title: "Cyber Crime Lawyer",
    description:
      "Specialized cybercrime defense including online fraud, data breach response, cybercrime investigation, and IT Act compliance.",
    services: [
      "Cyber Crime Complaints",
      "Online Fraud Defense",
      "Data Protection",
      "IT Act Compliance",
      "Social Media Disputes",
      "Hacking Cases",
    ],
  },
  {
    id: "intellectual-property",
    icon: Copyright,
    title: "Intellectual Property & Digital Signatures",
    description:
      "Comprehensive intellectual property services and digital signature solutions. We provide expert guidance on trademark & patent protection, and authorized DSC services through eMudhra and SpeedSignCA (CCA Licensed).",
    services: [
      "Trademark Registration & Renewal",
      "Patent Filing & Prosecution",
      "Copyright Protection & Registration",
      "Design Registration & Renewal",
      "Digital Signature Certificates (DSC)",
      "IP Litigation & Enforcement",
      "eMudhra DSC Services",
      "SpeedSignCA DSC Services (Become 50% Commission Partner)",
    ],
  },
  {
    id: "labour-employment",
    icon: Users,
    title: "Labour and Employment Lawyer",
    description:
      "Complete employment law solutions covering labor compliance, industrial relations, employment contracts, and workplace policies.",
    services: [
      "Employment Contracts",
      "Workplace Disputes",
      "Labor Compliance",
      "Employee Rights",
      "Industrial Relations",
      "HR Legal Advisory",
    ],
  },
  {
    id: "administrative-lawyer",
    icon: FileCheck,
    title: "Administrative Lawyer",
    description:
      "Expert services in administrative law covering government regulations, licensing, regulatory compliance, and appeals.",
    services: [
      "Government Regulations",
      "Administrative Appeals",
      "Licensing",
      "Compliance",
      "RTI Matters",
      "Regulatory Filings",
    ],
  },
  {
    id: "tax-lawyer",
    icon: Calculator,
    title: "Tax Lawyer",
    description:
      "Comprehensive tax advisory services covering direct and indirect taxes, GST compliance, tax planning, and dispute resolution.",
    services: [
      "Tax Planning",
      "GST Compliance",
      "Income Tax",
      "Tax Disputes",
      "Transfer Pricing",
      "International Taxation",
    ],
  },
  {
    id: "consumer-protection",
    icon: ShoppingBag,
    title: "Consumer Protection Lawyer",
    description:
      "Protecting consumer rights against unfair practices, defective products, service deficiencies, and e-commerce disputes.",
    services: [
      "Consumer Rights",
      "Product Liability",
      "Service Deficiency",
      "Consumer Courts",
      "E-commerce Disputes",
      "Refund Claims",
    ],
  },
  {
    id: "environmental-lawyer",
    icon: Leaf,
    title: "Environmental Lawyer",
    description:
      "Environmental law services covering compliance, pollution control, clearances, and sustainable development regulations.",
    services: [
      "Environmental Compliance",
      "Pollution Control",
      "Clearances",
      "Green Regulations",
      "Wildlife Protection",
      "Environmental Audits",
    ],
  },
  {
    id: "immigration-lawyer",
    icon: Plane,
    title: "Immigration Lawyer",
    description:
      "Comprehensive immigration services including visa applications, work permits, citizenship matters, and immigration compliance.",
    services: [
      "Visa Applications",
      "Work Permits",
      "Citizenship",
      "Immigration Compliance",
      "Deportation Defense",
      "Travel Documents",
    ],
  },
  {
    id: "insurance-lawyer",
    icon: Shield,
    title: "Insurance Lawyer",
    description:
      "Specialized insurance law services covering claims management, policy disputes, insurance fraud, and regulatory matters.",
    services: [
      "Insurance Claims",
      "Policy Disputes",
      "Insurance Fraud",
      "Regulatory Matters",
      "Claim Denial Appeals",
      "IRDAI Compliance",
    ],
  },
  {
    id: "startup-lawyer",
    icon: Briefcase,
    title: "Startup Lawyer",
    description:
      "Complete startup legal services covering registration, funding agreements, equity structuring, and startup compliance.",
    services: [
      "Startup Registration",
      "Funding Agreements",
      "Equity Structuring",
      "Compliance",
      "Shareholder Agreements",
      "Exit Strategy",
    ],
  },
  {
    id: "business-commercial",
    icon: Building2,
    title: "Business & Commercial Lawyer",
    description:
      "Comprehensive business law services covering contracts, partnership agreements, commercial disputes, and compliance.",
    services: [
      "Business Contracts",
      "Partnership Agreements",
      "Commercial Disputes",
      "Compliance",
      "Franchising",
      "Business Advisory",
    ],
  },
  {
    id: "nri-lawyer",
    icon: Globe,
    title: "NRI Lawyer",
    description:
      "Specialized NRI legal services for property, family, business, and inheritance matters with international coordination.",
    services: [
      "NRI Property Disputes",
      "Family & Inheritance",
      "Business Compliance",
      "Documentation Support",
      "Power of Attorney",
      "International Coordination",
    ],
  },
  {
    id: "traffic-challan",
    icon: Car,
    title: "Traffic Challan & Motor Vehicle",
    description:
      "Expert assistance in traffic violations, motor vehicle disputes, license issues, and representation before authorities.",
    services: [
      "Traffic Challan Defense",
      "License Suspension Issues",
      "Motor Accident Claims",
      "Vehicle Registration",
      "Transport Authority Appeals",
      "Insurance Disputes",
    ],
  },
]

export default function PracticeAreasPage() {
  const [expandedId, setExpandedId] = useState<string | null>(null)

  const toggleExpand = (id: string) => {
    setExpandedId(expandedId === id ? null : id)
  }

  return (
    <div className="min-h-screen">
      <Navigation />

      <PageHero
        badge="Our Expertise"
        title="Practice Areas"
        subtitle="Comprehensive legal services across all major practice areas, delivered with expertise, integrity, and unwavering commitment to client success."
        size="large"
      />

      {/* Disclaimer */}
      <section className="py-8 bg-secondary/30 border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="text-sm text-muted-foreground leading-relaxed text-center">
            <strong>Legal Services Disclaimer:</strong> LawUp Consulting provides legal, advisory, consultancy,
            compliance, documentation, representational, dispute resolution and allied services as permitted under the
            Advocates Act, 1961 and the Bar Council of India Rules.
          </p>
        </div>
      </section>

      {/* Practice Areas */}
      <section className="py-24 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-8 lg:space-y-16">
            {practiceAreas.map((area, index) => (
              <ScrollReveal key={area.id} delay={index * 50}>
                <div
                  id={area.id}
                  className={`grid lg:grid-cols-2 gap-12 items-center ${index % 2 === 1 ? "lg:flex-row-reverse" : ""}`}
                >
                  {/* Content */}
                  <div className={`${index % 2 === 1 ? "lg:order-2" : ""}`}>
                    <div className="flex items-center gap-4 mb-6">
                      <div className="p-3 bg-accent/10 rounded-xl">
                        <area.icon className="h-8 w-8 text-accent" />
                      </div>
                      <h2 className="font-serif text-2xl md:text-3xl font-bold text-primary">{area.title}</h2>
                    </div>
                    <p className="text-muted-foreground leading-relaxed mb-8">{area.description}</p>

                    {/* Services Grid - Hidden on mobile, shown on lg */}
                    <div className="hidden lg:grid grid-cols-2 gap-3">
                      {area.services.map((service, i) => (
                        <div key={i} className="flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-accent flex-shrink-0" />
                          <span className="text-sm text-foreground">{service}</span>
                        </div>
                      ))}
                    </div>

                    {/* Mobile Accordion */}
                    <div className="lg:hidden">
                      <button
                        onClick={() => toggleExpand(area.id)}
                        className="w-full flex items-center justify-between bg-secondary/30 hover:bg-secondary/50 p-4 rounded-lg transition-colors mb-4"
                      >
                        <span className="font-semibold">View Services</span>
                        <ChevronDown
                          className={`h-5 w-5 transition-transform ${expandedId === area.id ? "rotate-180" : ""}`}
                        />
                      </button>
                      {expandedId === area.id && (
                        <div className="grid grid-cols-2 gap-3 p-4 bg-secondary/20 rounded-lg">
                          {area.services.map((service, i) => (
                            <div key={i} className="flex items-center gap-2">
                              <CheckCircle className="h-4 w-4 text-accent flex-shrink-0" />
                              <span className="text-sm text-foreground">{service}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Visual Card */}
                  <div className={index % 2 === 1 ? "lg:order-1" : ""}>
                    <div className="relative bg-gradient-to-br from-primary to-primary/80 rounded-2xl p-8 lg:p-12 text-primary-foreground overflow-hidden">
                      {/* Background pattern */}
                      <div className="absolute inset-0 opacity-10">
                        <div
                          className="absolute inset-0"
                          style={{
                            backgroundImage: `radial-gradient(circle at 2px 2px, currentColor 1px, transparent 0)`,
                            backgroundSize: "24px 24px",
                          }}
                        />
                      </div>

                      <div className="relative z-10">
                        <area.icon className="h-16 w-16 text-accent mb-6" />
                        <h3 className="font-serif text-2xl font-bold mb-4">Expert {area.title} Counsel</h3>
                        <p className="text-primary-foreground/80 mb-6">
                          Our experienced team provides strategic guidance tailored to your specific needs.
                        </p>
                        <Button asChild className="bg-accent hover:bg-accent/90 text-accent-foreground">
                          <Link href="/contact" className="flex items-center gap-2">
                            Schedule Consultation
                            <ArrowRight className="h-4 w-4" />
                          </Link>
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>

                {index < practiceAreas.length - 1 && <div className="border-b border-border pt-8 lg:pt-16" />}
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 bg-primary text-primary-foreground">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <ScrollReveal>
            <span className="inline-flex items-center gap-2 text-accent text-sm font-medium tracking-widest uppercase mb-4">
              <span className="w-8 h-px bg-accent" />
              Get Started
              <span className="w-8 h-px bg-accent" />
            </span>
            <h2 className="font-serif text-3xl md:text-4xl font-bold mb-6">Need Legal Assistance?</h2>
            <p className="text-primary-foreground/80 text-lg mb-8 max-w-2xl mx-auto">
              Our experienced legal team is ready to provide expert guidance tailored to your specific needs across any
              of our practice areas.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground px-8">
                <Link href="/contact" className="flex items-center gap-2">
                  Schedule Consultation
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10 bg-transparent px-8"
              >
                <Link href="/team">Meet Our Team</Link>
              </Button>
            </div>
          </ScrollReveal>
        </div>
      </section>

      <FeeStructureSection />

      <Footer />
    </div>
  )
}
