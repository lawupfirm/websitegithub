import type { Metadata } from "next"
import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertTriangle, Scale, Shield } from "lucide-react"

export const metadata: Metadata = {
  title: "Legal Disclaimer - LawUp Consulting",
  description:
    "Legal disclaimer for LawUp Consulting - Important legal notices and Bar Council of India compliance information.",
  alternates: {
    canonical: "https://lawup.in/disclaimer",
  },
}

export default function DisclaimerPage() {
  return (
    <div className="min-h-screen">
      <Navigation />

      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-primary/5 to-accent/5">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="font-playfair text-4xl lg:text-5xl font-bold text-primary mb-6">Legal Disclaimer</h1>
            <p className="text-xl text-muted-foreground leading-relaxed">
              Important legal notices and compliance information for users of our website and services.
            </p>
          </div>
        </div>
      </section>

      {/* Disclaimer Content */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-8">
            {/* Bar Council Disclaimer */}
            <Card className="border-l-4 border-l-accent">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-2xl">
                  <Scale className="h-6 w-6 text-accent" />
                  Bar Council of India Disclaimer
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start gap-3 p-4 bg-accent/5 rounded-lg">
                  <AlertTriangle className="h-5 w-5 text-accent flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-muted-foreground leading-relaxed">
                      As per the rules of the Bar Council of India, LawUp Consulting and its associates are prohibited
                      from soliciting work or advertising. By accessing this website, you acknowledge the following:
                    </p>
                  </div>
                </div>

                <ul className="space-y-3 text-muted-foreground">
                  <li className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-accent rounded-full flex-shrink-0 mt-2"></div>
                    <span>
                      You are seeking information relating to LawUp Consulting of your own accord and there has been no
                      form of solicitation, advertisement or inducement by the firm or any of its members.
                    </span>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-accent rounded-full flex-shrink-0 mt-2"></div>
                    <span>This website does not seek to create or invite any lawyer-client relationship.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-accent rounded-full flex-shrink-0 mt-2"></div>
                    <span>No material/information provided on this website should be construed as legal advice.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-accent rounded-full flex-shrink-0 mt-2"></div>
                    <span>
                      LawUp Consulting shall not be liable for consequences arising out of any action taken by you
                      relying on material/information provided on this website.
                    </span>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-accent rounded-full flex-shrink-0 mt-2"></div>
                    <span>
                      In cases where you have any legal issues, you must in all cases seek independent legal advice.
                    </span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            {/* General Disclaimer */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-xl">
                  <Shield className="h-5 w-5 text-accent" />
                  General Disclaimer
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <section>
                  <h3 className="text-lg font-semibold text-primary mb-3">Information Accuracy</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    While we strive to provide accurate and up-to-date information, we make no representations or
                    warranties of any kind, express or implied, about the completeness, accuracy, reliability,
                    suitability or availability of the information contained on this website.
                  </p>
                </section>

                <section>
                  <h3 className="text-lg font-semibold text-primary mb-3">No Legal Advice</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    The content on this website is for general information purposes only and does not constitute legal
                    advice. Legal advice can only be provided after a detailed analysis of your specific circumstances
                    by a qualified attorney.
                  </p>
                </section>

                <section>
                  <h3 className="text-lg font-semibold text-primary mb-3">External Links</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    This website may contain links to external websites. We have no control over the nature, content and
                    availability of those sites. The inclusion of any links does not necessarily imply a recommendation
                    or endorse the views expressed within them.
                  </p>
                </section>

                <section>
                  <h3 className="text-lg font-semibold text-primary mb-3">Limitation of Liability</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    In no event will LawUp Consulting be liable for any loss or damage including without limitation,
                    indirect or consequential loss or damage, or any loss or damage whatsoever arising from loss of data
                    or profits arising out of, or in connection with, the use of this website.
                  </p>
                </section>

                <section>
                  <h3 className="text-lg font-semibold text-primary mb-3">Confidentiality Notice</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Do not send confidential information through this website until an attorney-client relationship has
                    been established. Any information sent through this website may not be protected by attorney-client
                    privilege.
                  </p>
                </section>
              </CardContent>
            </Card>

            {/* Contact Information */}
            <Card className="bg-muted/50">
              <CardHeader>
                <CardTitle className="text-xl">Questions About This Disclaimer?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  If you have any questions about this disclaimer or need legal consultation, please contact us:
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <p className="font-semibold">LawUp Consulting</p>
                    <p className="text-muted-foreground">Chamber: Ground B188a, Jamunapuri</p>
                    <p className="text-muted-foreground">Jaipur, Rajasthan - 302039</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Email: support@lawup.in</p>
                    <p className="text-muted-foreground">Phone: +91-9716968000</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
