import { type NextRequest, NextResponse } from "next/server"
import { Resend } from "resend"

const resend = new Resend(process.env.RESEND_API_KEY)

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const name = formData.get("name") as string
    const email = formData.get("email") as string
    const phone = formData.get("phone") as string
    const company = formData.get("company") as string
    const serviceType = formData.get("serviceType") as string
    const subject = formData.get("subject") as string
    const message = formData.get("message") as string

    // Validate required fields
    if (!name || !email || !subject || !message) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    const fileAttachments: { filename: string; content: string }[] = []
    let fileIndex = 0
    while (true) {
      const file = formData.get(`file_${fileIndex}`) as File | null
      if (!file) break
      const buffer = Buffer.from(await file.arrayBuffer())
      const base64Content = buffer.toString("base64")
      fileAttachments.push({
        filename: file.name,
        content: base64Content,
      })
      fileIndex++
    }

    // Email to the law firm with premium design
    const firmEmailContent = `
      <div style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; max-width: 600px; margin: 0 auto; background: #f8f9fa;">
        <!-- Header -->
        <div style="background: linear-gradient(135deg, #1e2d52 0%, #2d3e5f 100%); padding: 30px; text-align: center; border-bottom: 4px solid #d4af37;">
          <h1 style="color: #d4af37; margin: 0; font-size: 24px;">⚖️ LawUp Consulting</h1>
          <p style="color: #ffffff; margin: 8px 0 0 0; font-size: 14px; letter-spacing: 1px;">Justice in Clear Sight</p>
        </div>

        <!-- Main Content -->
        <div style="padding: 40px; background: #ffffff; color: #333;">
          <h2 style="color: #1e2d52; margin-top: 0; border-bottom: 2px solid #d4af37; padding-bottom: 15px;">New Contact Form Submission</h2>
          
          <table style="width: 100%; border-collapse: collapse; margin: 30px 0;">
            <tr style="background: #f8f9fa;">
              <td style="padding: 12px; border: 1px solid #e0e0e0; font-weight: bold; color: #1e2d52; width: 35%;">Name</td>
              <td style="padding: 12px; border: 1px solid #e0e0e0;">${name}</td>
            </tr>
            <tr>
              <td style="padding: 12px; border: 1px solid #e0e0e0; font-weight: bold; color: #1e2d52;">Email</td>
              <td style="padding: 12px; border: 1px solid #e0e0e0;"><a href="mailto:${email}" style="color: #d4af37; text-decoration: none;">${email}</a></td>
            </tr>
            ${
              phone
                ? `
            <tr style="background: #f8f9fa;">
              <td style="padding: 12px; border: 1px solid #e0e0e0; font-weight: bold; color: #1e2d52;">Phone</td>
              <td style="padding: 12px; border: 1px solid #e0e0e0;"><a href="tel:${phone}" style="color: #d4af37; text-decoration: none;">${phone}</a></td>
            </tr>
            `
                : ""
            }
            ${
              company
                ? `
            <tr>
              <td style="padding: 12px; border: 1px solid #e0e0e0; font-weight: bold; color: #1e2d52;">Organization</td>
              <td style="padding: 12px; border: 1px solid #e0e0e0;">${company}</td>
            </tr>
            `
                : ""
            }
            ${
              serviceType
                ? `
            <tr style="background: #f8f9fa;">
              <td style="padding: 12px; border: 1px solid #e0e0e0; font-weight: bold; color: #1e2d52;">Service Type</td>
              <td style="padding: 12px; border: 1px solid #e0e0e0;"><span style="background: #d4af37; color: #1e2d52; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: bold;">${serviceType}</span></td>
            </tr>
            `
                : ""
            }
            <tr>
              <td style="padding: 12px; border: 1px solid #e0e0e0; font-weight: bold; color: #1e2d52;">Subject</td>
              <td style="padding: 12px; border: 1px solid #e0e0e0;">${subject}</td>
            </tr>
          </table>

          <div style="background: #f8f9fa; padding: 20px; border-left: 4px solid #d4af37; margin: 30px 0;">
            <h3 style="color: #1e2d52; margin-top: 0;">Message</h3>
            <p style="color: #555; line-height: 1.6; white-space: pre-wrap;">${message.replace(/</g, "&lt;").replace(/>/g, "&gt;")}</p>
          </div>

          ${
            fileAttachments.length > 0
              ? `
          <div style="background: #e8f5e9; padding: 15px; border-radius: 5px; margin: 20px 0;">
            <p style="color: #1b5e20; margin: 0 0 10px 0;"><strong>📎 Attachments (${fileAttachments.length}):</strong></p>
            <ul style="margin: 0; padding-left: 20px; color: #2e7d32;">
              ${fileAttachments.map((f) => `<li style="margin: 5px 0;">${f.filename}</li>`).join("")}
            </ul>
          </div>
          `
              : ""
          }
        </div>

        <!-- Footer -->
        <div style="background: #1e2d52; color: #ffffff; padding: 30px; text-align: center; border-top: 4px solid #d4af37;">
          <p style="margin: 0; font-size: 14px;">
            <strong>LawUp Consulting</strong><br>
            "Justice in Clear Sight"
          </p>
          <p style="margin: 15px 0 0 0; font-size: 12px; color: #b0b0b0;">
            📍 Jaipur, Rajasthan<br>
            📞 +91-9716968000<br>
            ✉️ support@lawup.in
          </p>
          <p style="margin: 15px 0 0 0; font-size: 11px; color: #808080;">
            This message was received through the LawUp Consulting contact form
          </p>
        </div>
      </div>
    `

    // Auto-reply to the client
    const clientEmailContent = `
      <div style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; max-width: 600px; margin: 0 auto; background: #f8f9fa;">
        <!-- Header -->
        <div style="background: linear-gradient(135deg, #1e2d52 0%, #2d3e5f 100%); padding: 30px; text-align: center; border-bottom: 4px solid #d4af37;">
          <h1 style="color: #d4af37; margin: 0; font-size: 24px;">⚖️ LawUp Consulting</h1>
          <p style="color: #ffffff; margin: 8px 0 0 0; font-size: 14px; letter-spacing: 1px;">Justice in Clear Sight</p>
        </div>

        <!-- Main Content -->
        <div style="padding: 40px; background: #ffffff; color: #333;">
          <h2 style="color: #1e2d52; margin-top: 0;">Thank You, ${name}!</h2>
          
          <p style="font-size: 16px; line-height: 1.6; color: #555;">
            We have received your inquiry regarding <strong>"${subject}"</strong> and truly appreciate you entrusting LawUp Consulting with your legal matter.
          </p>

          <div style="background: #e3f2fd; padding: 20px; border-radius: 5px; border-left: 4px solid #d4af37; margin: 30px 0;">
            <p style="margin: 0; color: #1e2d52; font-weight: bold;">What happens next?</p>
            <ul style="margin: 10px 0 0 0; padding-left: 20px; color: #555;">
              <li>Our expert team will review your submission within <strong>24 hours</strong> (business days)</li>
              <li>A senior attorney will assess your case and requirements</li>
              <li>We'll contact you at the earliest with our recommendations</li>
              <li>For urgent matters, call us directly at <strong>+91-9716968000</strong></li>
            </ul>
          </div>

          <h3 style="color: #1e2d52; border-bottom: 2px solid #d4af37; padding-bottom: 10px;">Your Submission Summary</h3>
          
          <table style="width: 100%; border-collapse: collapse; margin: 20px 0;">
            <tr style="background: #f8f9fa;">
              <td style="padding: 10px; border: 1px solid #e0e0e0; font-weight: bold; color: #1e2d52; width: 30%;">Subject</td>
              <td style="padding: 10px; border: 1px solid #e0e0e0;">${subject}</td>
            </tr>
            ${
              serviceType
                ? `
            <tr>
              <td style="padding: 10px; border: 1px solid #e0e0e0; font-weight: bold; color: #1e2d52;">Service Type</td>
              <td style="padding: 10px; border: 1px solid #e0e0e0;"><span style="background: #d4af37; color: #1e2d52; padding: 4px 10px; border-radius: 15px; font-size: 12px; font-weight: bold;">${serviceType}</span></td>
            </tr>
            `
                : ""
            }
            <tr style="background: #f8f9fa;">
              <td style="padding: 10px; border: 1px solid #e0e0e0; font-weight: bold; color: #1e2d52;">Message</td>
              <td style="padding: 10px; border: 1px solid #e0e0e0;"><small style="color: #666; white-space: pre-wrap;">${message.substring(0, 100)}${message.length > 100 ? "..." : ""}</small></td>
            </tr>
            ${
              fileAttachments.length > 0
                ? `
            <tr>
              <td style="padding: 10px; border: 1px solid #e0e0e0; font-weight: bold; color: #1e2d52;">Attachments</td>
              <td style="padding: 10px; border: 1px solid #e0e0e0;"><small style="color: #2e7d32;">✓ ${fileAttachments.length} file(s) received</small></td>
            </tr>
            `
                : ""
            }
          </table>

          <div style="background: #fff3e0; padding: 15px; border-radius: 5px; margin: 30px 0; border-left: 4px solid #ff9800;">
            <p style="margin: 0; color: #e65100;"><strong>🚨 Urgent Matter?</strong></p>
            <p style="margin: 5px 0 0 0; color: #bf360c;">Call us immediately at <strong>+91-9716968000</strong> for immediate legal assistance.</p>
          </div>
        </div>

        <!-- Footer -->
        <div style="background: #1e2d52; color: #ffffff; padding: 30px; text-align: center;">
          <p style="margin: 0 0 15px 0; font-size: 14px;">
            <strong>LawUp Consulting</strong><br>
            <span style="color: #d4af37; font-size: 13px;">Justice in Clear Sight</span>
          </p>
          
          <table style="width: 100%; border-collapse: collapse; margin: 20px 0; text-align: left; font-size: 13px; color: #ccc;">
            <tr>
              <td style="padding: 5px;">📍 <strong>Office:</strong> Jaipur, Rajasthan</td>
              <td style="padding: 5px;">📞 <strong>Phone:</strong> +91-9716968000</td>
            </tr>
            <tr>
              <td style="padding: 5px;">✉️ <strong>Email:</strong> support@lawup.in</td>
              <td style="padding: 5px;">🌐 <strong>Web:</strong> www.lawup.in</td>
            </tr>
          </table>

          <p style="margin: 20px 0 0 0; font-size: 11px; color: #888; border-top: 1px solid #444; padding-top: 15px;">
            This is an automated response from LawUp Consulting. Please do not reply to this email. For support, use the contact form or call us directly.
          </p>
        </div>
      </div>
    `

    // Send email to the firm with file attachments
    await resend.emails.send({
      from: "noreply@ver.lawup.in",
      to: ["support@lawup.in"],
      subject: `New Contact Form: ${subject}`,
      html: firmEmailContent,
      replyTo: email,
      ...(fileAttachments.length > 0 && { attachments: fileAttachments }),
    })

    // Send auto-reply to the client
    await resend.emails.send({
      from: "noreply@ver.lawup.in",
      to: [email],
      subject: "Thank you for contacting LawUp Consulting",
      html: clientEmailContent,
    })

    return NextResponse.json({ message: "Message sent successfully" }, { status: 200 })
  } catch (error) {
    console.error("Error processing contact form:", error)
    return NextResponse.json({ error: "Failed to send message" }, { status: 500 })
  }
}
