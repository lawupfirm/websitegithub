import { type NextRequest, NextResponse } from "next/server"
import { Resend } from "resend"

const resend = new Resend(process.env.RESEND_API_KEY)

// Store OTPs temporarily (in production, use Redis or database)
const otpStore = new Map<string, { otp: string; expires: number }>()

function generateOTP(): string {
  return Math.floor(100000 + Math.random() * 900000).toString()
}

export async function POST(request: NextRequest) {
  try {
    const { email } = await request.json()

    if (!email) {
      return NextResponse.json({ error: "Email is required" }, { status: 400 })
    }

    const otp = generateOTP()
    const expires = Date.now() + 15 * 60 * 1000 // 15 minutes

    // Store OTP
    otpStore.set(email, { otp, expires })
    console.log("[v0] OTP generated for", email, "expires at", new Date(expires).toISOString())

    // Send OTP email
    await resend.emails.send({
      from: "noreply@ver.lawup.in",
      to: [email],
      subject: "Your OTP for LawUp Contact Form",
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #1e2d52;">⚖️ LawUp Consulting</h2>
          <p>Your One-Time Password (OTP) for the contact form is:</p>
          <div style="background: #f3f4f6; padding: 20px; text-align: center; margin: 20px 0; border-left: 4px solid #d4af37;">
            <h1 style="color: #1e2d52; font-size: 32px; margin: 0; letter-spacing: 4px;">${otp}</h1>
          </div>
          <p style="color: #555; font-size: 14px;">This OTP is valid for <strong>15 minutes</strong> only.</p>
          <p style="color: #888; font-size: 12px;">If you didn't request this OTP, please ignore this email.</p>
          <hr style="margin: 20px 0; border: none; border-top: 1px solid #e0e0e0;">
          <p style="color: #888; font-size: 12px;">
            <strong>LawUp Consulting</strong><br>
            Justice in Clear Sight<br>
            📞 +91-9716968000
          </p>
        </div>
      `,
    })

    return NextResponse.json({ message: "OTP sent successfully" }, { status: 200 })
  } catch (error) {
    console.error("Error sending OTP:", error)
    return NextResponse.json({ error: "Failed to send OTP" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const { email, otp } = await request.json()

    if (!email || !otp) {
      return NextResponse.json({ error: "Email and OTP are required" }, { status: 400 })
    }

    const trimmedOtp = otp.toString().trim()
    console.log("[v0] Verifying OTP for", email, "provided OTP:", trimmedOtp)

    const storedData = otpStore.get(email)

    if (!storedData) {
      console.log("[v0] No OTP found for", email)
      return NextResponse.json({ error: "OTP not found. Please request a new OTP." }, { status: 400 })
    }

    console.log(
      "[v0] Current time:",
      Date.now(),
      "OTP expires at:",
      storedData.expires,
      "Difference (ms):",
      storedData.expires - Date.now(),
    )

    if (Date.now() > storedData.expires) {
      console.log("[v0] OTP expired for", email)
      otpStore.delete(email)
      return NextResponse.json({ error: "OTP has expired. Please request a new OTP." }, { status: 400 })
    }

    if (storedData.otp !== trimmedOtp) {
      console.log("[v0] Invalid OTP for", email, "expected:", storedData.otp, "got:", trimmedOtp)
      return NextResponse.json({ error: "Invalid OTP. Please check and try again." }, { status: 400 })
    }

    // OTP is valid, remove it from store
    console.log("[v0] OTP verified successfully for", email)
    otpStore.delete(email)

    return NextResponse.json({ message: "OTP verified successfully" }, { status: 200 })
  } catch (error) {
    console.error("Error verifying OTP:", error)
    return NextResponse.json({ error: "Failed to verify OTP" }, { status: 500 })
  }
}
