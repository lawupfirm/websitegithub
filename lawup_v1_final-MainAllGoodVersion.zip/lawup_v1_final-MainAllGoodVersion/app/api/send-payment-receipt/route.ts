import { NextRequest, NextResponse } from "next/server"
import { Resend } from "resend"

const resend = new Resend(process.env.RESEND_API_KEY)

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const {
      email,
      name,
      amount,
      service,
      payment_id,
      order_id,
      contact_message,
    } = body

    const receiptHtml = `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <style>
            body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; background: #f9f9f9; padding: 20px; border-radius: 8px; }
            .header { background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%); color: white; padding: 30px; border-radius: 8px 8px 0 0; text-align: center; }
            .header h1 { margin: 0; font-size: 28px; }
            .header p { margin: 10px 0 0 0; opacity: 0.9; }
            .content { background: white; padding: 30px; }
            .receipt-section { margin: 20px 0; }
            .receipt-section h3 { color: #1a1a1a; border-bottom: 2px solid #c9a227; padding-bottom: 10px; }
            .detail-row { display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid #eee; }
            .detail-row:last-child { border-bottom: none; }
            .detail-label { font-weight: 600; color: #666; }
            .detail-value { color: #333; }
            .amount-box { background: #f0f0f0; padding: 20px; border-radius: 8px; margin: 20px 0; }
            .amount-row { display: flex; justify-content: space-between; padding: 10px 0; font-size: 16px; }
            .total-row { border-top: 2px solid #c9a227; padding-top: 10px; font-weight: bold; font-size: 20px; color: #1a1a1a; }
            .status { background: #d4edda; color: #155724; padding: 15px; border-radius: 4px; margin: 20px 0; text-align: center; font-weight: 600; }
            .message { background: #e7f3ff; color: #0066cc; padding: 15px; border-radius: 4px; margin: 20px 0; }
            .footer { background: #f9f9f9; padding: 20px; text-align: center; border-top: 1px solid #eee; font-size: 12px; color: #666; }
            .contact-info { background: #fff3cd; padding: 15px; border-radius: 4px; margin: 20px 0; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>Payment Receipt</h1>
              <p>LawUp Consulting - Legal Services</p>
            </div>
            
            <div class="content">
              <div class="receipt-section">
                <h3>Receipt Details</h3>
                <div class="detail-row">
                  <span class="detail-label">Receipt Number:</span>
                  <span class="detail-value">#${order_id?.substring(0, 8).toUpperCase()}</span>
                </div>
                <div class="detail-row">
                  <span class="detail-label">Payment ID:</span>
                  <span class="detail-value">${payment_id}</span>
                </div>
                <div class="detail-row">
                  <span class="detail-label">Date:</span>
                  <span class="detail-value">${new Date().toLocaleDateString("en-IN", {
                    year: "numeric",
                    month: "long",
                    day: "numeric",
                  })}</span>
                </div>
              </div>

              <div class="receipt-section">
                <h3>Client Information</h3>
                <div class="detail-row">
                  <span class="detail-label">Name:</span>
                  <span class="detail-value">${name}</span>
                </div>
                <div class="detail-row">
                  <span class="detail-label">Email:</span>
                  <span class="detail-value">${email}</span>
                </div>
              </div>

              <div class="receipt-section">
                <h3>Service Details</h3>
                <div class="detail-row">
                  <span class="detail-label">Service:</span>
                  <span class="detail-value">${service}</span>
                </div>
              </div>

              <div class="amount-box">
                <div class="amount-row">
                  <span>Service Fee</span>
                  <span>₹${amount.toLocaleString("en-IN")}</span>
                </div>
                <div class="amount-row total-row">
                  <span>Total Amount Paid</span>
                  <span>₹${amount.toLocaleString("en-IN")}</span>
                </div>
              </div>

              <div class="status">
                ✓ Payment Received Successfully
              </div>

              <div class="message">
                <strong>What happens next?</strong><br>
                Our team will get in touch with you shortly to discuss your legal requirements and provide expert guidance. We will contact you within 24 business hours.
              </div>

              ${
                contact_message
                  ? `<div class="contact-info">
                <strong>Your Message:</strong><br>
                ${contact_message}
              </div>`
                  : ""
              }

              <div class="receipt-section">
                <h3>Payment Method</h3>
                <div class="detail-row">
                  <span class="detail-label">Gateway:</span>
                  <span class="detail-value">Razorpay (Secure)</span>
                </div>
                <div class="detail-row">
                  <span class="detail-label">Status:</span>
                  <span class="detail-value" style="color: #28a745; font-weight: bold;">✓ Completed</span>
                </div>
              </div>
            </div>

            <div class="footer">
              <p><strong>LawUp Consulting</strong></p>
              <p>Chamber: Ground B188a, Jamunapuri, Jaipur, Rajasthan - 302039</p>
              <p>Phone: +91-9716968000 | Email: support@lawup.in</p>
              <p style="margin-top: 20px; border-top: 1px solid #ddd; padding-top: 15px;">
                This is an automated receipt. Please keep it for your records.
              </p>
            </div>
          </div>
        </body>
      </html>
    `

    const result = await resend.emails.send({
      from: "noreply@lawup.in",
      to: email,
      subject: `Payment Receipt - LawUp Consulting (₹${amount})`,
      html: receiptHtml,
    })

    if (result.error) {
      console.error("Error sending receipt:", result.error)
      return NextResponse.json(
        { error: "Failed to send receipt" },
        { status: 500 }
      )
    }

    return NextResponse.json({
      success: true,
      message: "Receipt sent successfully",
      email_id: result.data?.id,
    })
  } catch (error) {
    console.error("Error sending receipt:", error)
    return NextResponse.json(
      { error: "Failed to send receipt" },
      { status: 500 }
    )
  }
}
