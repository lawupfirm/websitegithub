import { createClient } from "@supabase/supabase-js"
import { NextRequest, NextResponse } from "next/server"
import crypto from "crypto"

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || "",
  process.env.SUPABASE_SERVICE_ROLE_KEY || ""
)

export async function POST(req: NextRequest) {
  try {
    const body = await req.text()
    const signature = req.headers.get("x-razorpay-signature")

    // Verify webhook signature
    const expected_signature = crypto
      .createHmac("sha256", process.env.RAZORPAY_WEBHOOK_SECRET || "")
      .update(body)
      .digest("hex")

    if (signature !== expected_signature) {
      return NextResponse.json(
        { error: "Webhook signature verification failed" },
        { status: 400 }
      )
    }

    const event = JSON.parse(body)

    if (event.event === "payment.authorized") {
      const payment = event.payload.payment.entity

      // Update payment in database
      await supabase
        .from("payments")
        .update({
          status: "completed",
          payment_id: payment.id,
        })
        .eq("order_id", payment.order_id)
    }

    if (event.event === "payment.failed") {
      const payment = event.payload.payment.entity

      // Update payment status to failed
      await supabase
        .from("payments")
        .update({
          status: "failed",
          payment_id: payment.id,
        })
        .eq("order_id", payment.order_id)
    }

    return NextResponse.json({ received: true })
  } catch (error) {
    console.error("Error processing webhook:", error)
    return NextResponse.json(
      { error: "Webhook processing failed" },
      { status: 500 }
    )
  }
}
