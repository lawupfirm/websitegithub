import { createClient } from "@supabase/supabase-js"
import { NextRequest, NextResponse } from "next/server"
import Razorpay from "razorpay"

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID || "",
  key_secret: process.env.RAZORPAY_KEY_SECRET || "",
})

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || "",
  process.env.SUPABASE_SERVICE_ROLE_KEY || ""
)

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { amount, email, phone, name, service, orderId } = body

    // Validate amount (in smallest currency unit - paise)
    const amountInPaise = Math.round(amount * 100)

    if (amountInPaise < 10000) {
      // Minimum 100 INR
      return NextResponse.json(
        { error: "Minimum amount is ₹100" },
        { status: 400 }
      )
    }

    // Create Razorpay order
    const order = await razorpay.orders.create({
      amount: amountInPaise,
      currency: "INR",
      receipt: `lawup_${Date.now()}`,
      notes: {
        service,
        userEmail: email,
        orderId,
      },
    })

    // Save order to database
    const { data, error } = await supabase.from("payments").insert([
      {
        order_id: order.id,
        amount: amount,
        currency: "INR",
        status: "pending",
        email,
        phone,
        name,
        service,
        payment_id: null,
        signature: null,
        receipt_data: {
          order_id: orderId,
        },
      },
    ])

    if (error) {
      console.error("Database error:", error)
      return NextResponse.json(
        { error: "Failed to create order in database" },
        { status: 500 }
      )
    }

    return NextResponse.json({
      orderId: order.id,
      amount: amountInPaise,
      currency: order.currency,
      key: process.env.RAZORPAY_KEY_ID,
    })
  } catch (error) {
    console.error("[v0] Error creating order:", error)
    const errorMessage = error instanceof Error ? error.message : "Failed to create order"
    return NextResponse.json(
      { error: errorMessage, success: false },
      { status: 500 }
    )
  }
}
