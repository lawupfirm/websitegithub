import type { Metadata } from "next"
import ContactPageClient from "./ContactPageClient"

export const metadata: Metadata = {
  title: "Contact Us - LawUp Consulting | Get Legal Consultation",
  description:
    "Contact LawUp Consulting for expert legal consultation. Located in Jaipur, Rajasthan. Call +91-141-XXX-XXXX or email contact@lawup.in for immediate assistance.",
  keywords: [
    "contact law firm",
    "legal consultation",
    "law firm Jaipur",
    "legal advice",
    "lawyer contact",
    "legal services contact",
    "advocate consultation",
  ],
  openGraph: {
    title: "Contact Us - LawUp Consulting",
    description: "Get in touch for expert legal consultation and professional legal services.",
    images: ["/jaipur-office-map.png"],
  },
  alternates: {
    canonical: "https://lawup.in/contact",
  },
}

export default function ContactPage() {
  return <ContactPageClient />
}
