"use client"

import type React from "react"
import { useState } from "react"
import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { PageHero } from "@/components/page-hero"
import { ScrollReveal } from "@/components/scroll-reveal"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import { MapPin, Phone, Mail, Clock, Send, Loader2, Shield, CheckCircle, ArrowRight, FileUp, X, CreditCard } from "lucide-react"
import { PaymentModal } from "@/components/payment-modal"

export default function ContactPageClient() {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [showOtpField, setShowOtpField] = useState(false)
  const [isVerifyingOtp, setIsVerifyingOtp] = useState(false)
  const [otpVerified, setOtpVerified] = useState(false)
  const [otp, setOtp] = useState("")
  const [otpSent, setOtpSent] = useState(false)
  const [selectedFiles, setSelectedFiles] = useState<File[]>([])
  const [showPaymentModal, setShowPaymentModal] = useState(false)
  const [selectedServiceForPayment, setSelectedServiceForPayment] = useState<string | null>(null)
  const { toast } = useToast()
  const [showPaymentOptions, setShowPaymentOptions] = useState(false) // Declare showPaymentOptions

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    company: "",
    serviceType: "",
    subject: "",
    message: "",
  })

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (value: string) => {
    setFormData((prev) => ({ ...prev, serviceType: value }))
  }

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || [])
    const maxSize = 5 * 1024 * 1024 // 5MB per file
    const allowedTypes = [
      "application/pdf",
      "application/msword",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "image/jpeg",
      "image/png",
    ]

    const validFiles = files.filter((file) => {
      if (file.size > maxSize) {
        toast({
          title: "File Too Large",
          description: `${file.name} exceeds 5MB limit.`,
          variant: "destructive",
        })
        return false
      }
      if (!allowedTypes.includes(file.type)) {
        toast({
          title: "Invalid File Type",
          description: `${file.name} is not supported. Use PDF, DOC, DOCX, JPG, or PNG.`,
          variant: "destructive",
        })
        return false
      }
      return true
    })

    if (selectedFiles.length + validFiles.length > 5) {
      toast({
        title: "Too Many Files",
        description: "Maximum 5 files allowed.",
        variant: "destructive",
      })
      return
    }

    setSelectedFiles((prev) => [...prev, ...validFiles])
  }

  const removeFile = (index: number) => {
    setSelectedFiles((prev) => prev.filter((_, i) => i !== index))
  }

  const sendOtp = async () => {
    if (!formData.email) {
      toast({ title: "Email Required", description: "Please enter your email address first.", variant: "destructive" })
      return
    }
    try {
      const response = await fetch("/api/send-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: formData.email }),
      })
      if (response.ok) {
        setShowOtpField(true)
        setOtpSent(true)
        toast({ title: "OTP Sent", description: "Please check your email for the verification code." })
      } else {
        throw new Error("Failed to send OTP")
      }
    } catch {
      toast({ title: "Error", description: "Failed to send OTP. Please try again.", variant: "destructive" })
    }
  }

  const verifyOtp = async () => {
    if (!otp) {
      toast({ title: "OTP Required", description: "Please enter the OTP sent to your email.", variant: "destructive" })
      return
    }
    setIsVerifyingOtp(true)
    try {
      const response = await fetch("/api/send-otp", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: formData.email, otp }),
      })
      if (response.ok) {
        setOtpVerified(true)
        toast({ title: "Email Verified", description: "You can now submit your message." })
      } else {
        const data = await response.json()
        throw new Error(data.error || "Invalid OTP")
      }
    } catch (error) {
      toast({
        title: "Verification Failed",
        description: error instanceof Error ? error.message : "Invalid OTP.",
        variant: "destructive",
      })
    } finally {
      setIsVerifyingOtp(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!otpVerified) {
      toast({
        title: "Email Verification Required",
        description: "Please verify your email with OTP before submitting.",
        variant: "destructive",
      })
      return
    }
    setIsSubmitting(true)
    try {
      const submitFormData = new FormData()
      Object.entries(formData).forEach(([key, value]) => {
        submitFormData.append(key, value as string)
      })
      selectedFiles.forEach((file, index) => {
        submitFormData.append(`file_${index}`, file)
      })

      const response = await fetch("/api/contact", {
        method: "POST",
        body: submitFormData,
      })
      if (response.ok) {
        toast({
          title: "Message Sent Successfully",
          description: "Thank you for contacting us. We'll get back to you within 24 hours.",
        })
        setFormData({ name: "", email: "", phone: "", company: "", serviceType: "", subject: "", message: "" })
        setSelectedFiles([])
        setShowOtpField(false)
        setOtpVerified(false)
        setOtp("")
        setOtpSent(false)
        setShowPaymentOptions(false) // Reset showPaymentOptions on submit
      } else {
        throw new Error("Failed to send message")
      }
    } catch {
      toast({
        title: "Error Sending Message",
        description: "Please try again or contact us directly.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen">
      <Navigation />

      <PageHero
        badge="Get In Touch"
        title="Contact Us"
        subtitle="Ready to discuss your legal needs? Get in touch with our expert team for professional consultation and guidance."
        size="large"
      />

      {/* Quick Contact Bar */}
      <section className="py-6 bg-accent">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-center gap-6 md:gap-12 text-accent-foreground">
            <a href="tel:+919716968000" className="flex items-center gap-2 hover:opacity-80 transition-opacity">
              <Phone className="h-5 w-5" />
              <span className="font-medium">+91-9716968000</span>
            </a>
            <a href="mailto:support@lawup.in" className="flex items-center gap-2 hover:opacity-80 transition-opacity">
              <Mail className="h-5 w-5" />
              <span className="font-medium">support@lawup.in</span>
            </a>
            <div className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              <span className="font-medium">Mon-Fri: 9AM-6PM IST</span>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-24 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-5 gap-12">
            {/* Contact Info */}
            <div className="lg:col-span-2 space-y-8">
              <ScrollReveal>
                <h2 className="font-serif text-2xl font-bold text-primary mb-4">Visit Our Office</h2>
                <p className="text-muted-foreground leading-relaxed mb-8">
                  We're here to help you navigate your legal challenges with expertise and dedication.
                </p>
              </ScrollReveal>

              <ScrollReveal delay={100}>
                <Card className="border-0 shadow-lg">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="p-3 bg-accent/10 rounded-lg">
                        <MapPin className="h-6 w-6 text-accent" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-primary mb-2">LawUp Consulting</h3>
                        <p className="text-muted-foreground">
                          Chamber: Ground B188a, Jamunapuri, Jaipur, Rajasthan - 302039
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </ScrollReveal>

              <ScrollReveal delay={200}>
                <Card className="border-0 shadow-lg">
                  <CardContent className="p-6">
                    <h3 className="font-semibold text-primary mb-4 flex items-center gap-2">
                      <Clock className="h-5 w-5 text-accent" />
                      Office Hours
                    </h3>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Monday - Friday</span>
                        <span className="font-medium">9:00 AM - 6:00 PM</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Saturday</span>
                        <span className="font-medium">10:00 AM - 2:00 PM</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Sunday</span>
                        <span className="font-medium text-accent">Closed</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </ScrollReveal>

              <ScrollReveal delay={300}>
                <div className="p-6 bg-primary rounded-xl text-primary-foreground">
                  <h3 className="font-semibold mb-3">Need Immediate Assistance?</h3>
                  <p className="text-primary-foreground/80 text-sm mb-4">
                    For urgent legal matters, call us directly for immediate consultation.
                  </p>
                  <Button asChild className="w-full bg-accent hover:bg-accent/90 text-accent-foreground">
                    <a href="tel:+919716968000" className="flex items-center justify-center gap-2">
                      <Phone className="h-4 w-4" />
                      Call Now
                    </a>
                  </Button>
                </div>
              </ScrollReveal>
            </div>

            {/* Contact Form */}
            <div className="lg:col-span-3">
              <ScrollReveal direction="right">
                <Card className="border-0 shadow-xl">
                  <CardContent className="p-8">
                    <h2 className="font-serif text-2xl font-bold text-primary mb-2">Send Us a Message</h2>
                    <p className="text-muted-foreground mb-8">
                      Fill out the form below and verify your email to get in touch.
                    </p>

                    <form onSubmit={handleSubmit} className="space-y-6">
                      <div className="grid sm:grid-cols-2 gap-4">
                        <div>
                          <label htmlFor="name" className="block text-sm font-medium mb-2">
                            Full Name <span className="text-destructive">*</span>
                          </label>
                          <Input
                            id="name"
                            name="name"
                            required
                            value={formData.name}
                            onChange={handleInputChange}
                            placeholder="Your full name"
                            className="bg-secondary/30"
                          />
                        </div>
                        <div>
                          <label htmlFor="email" className="block text-sm font-medium mb-2">
                            Email Address <span className="text-destructive">*</span>
                          </label>
                          <div className="flex gap-2">
                            <Input
                              id="email"
                              name="email"
                              type="email"
                              required
                              value={formData.email}
                              onChange={handleInputChange}
                              placeholder="your@email.com"
                              disabled={otpVerified}
                              className="bg-secondary/30"
                            />
                            {!otpVerified && (
                              <Button
                                type="button"
                                variant="outline"
                                onClick={sendOtp}
                                disabled={!formData.email}
                                className="whitespace-nowrap bg-transparent"
                              >
                                {otpSent ? "Resend" : "Verify"}
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>

                      {showOtpField && !otpVerified && (
                        <div className="p-4 bg-secondary/30 rounded-lg">
                          <label htmlFor="otp" className="block text-sm font-medium mb-2">
                            Enter OTP sent to your email
                          </label>
                          <div className="flex gap-2">
                            <Input
                              id="otp"
                              value={otp}
                              onChange={(e) => setOtp(e.target.value)}
                              placeholder="6-digit OTP"
                              maxLength={6}
                              className="bg-background"
                            />
                            <Button type="button" onClick={verifyOtp} disabled={isVerifyingOtp || !otp}>
                              {isVerifyingOtp ? <Loader2 className="h-4 w-4 animate-spin" /> : "Verify"}
                            </Button>
                          </div>
                        </div>
                      )}

                      {otpVerified && (
                        <div className="space-y-4">
                          <div className="flex items-center gap-2 text-green-600 text-sm p-3 bg-green-50 rounded-lg">
                            <CheckCircle className="h-4 w-4" />
                            Email verified successfully
                          </div>

                          <Button
                            type="button"
                            onClick={() => setShowPaymentModal(true)}
                            className="w-full bg-accent hover:bg-accent/90 text-accent-foreground py-6"
                          >
                            <CreditCard className="mr-2 h-4 w-4" />
                            💳 Pay Consultation Fee (Optional)
                          </Button>
                        </div>
                      )}

                      <div className="grid sm:grid-cols-2 gap-4">
                        <div>
                          <label htmlFor="phone" className="block text-sm font-medium mb-2">
                            Phone Number
                          </label>
                          <Input
                            id="phone"
                            name="phone"
                            type="tel"
                            value={formData.phone}
                            onChange={handleInputChange}
                            placeholder="+91 XXXXX XXXXX"
                            className="bg-secondary/30"
                          />
                        </div>
                        <div>
                          <label htmlFor="company" className="block text-sm font-medium mb-2">
                            Company/Organization
                          </label>
                          <Input
                            id="company"
                            name="company"
                            value={formData.company}
                            onChange={handleInputChange}
                            placeholder="Your company"
                            className="bg-secondary/30"
                          />
                        </div>
                      </div>

                      <div>
                        <label htmlFor="serviceType" className="block text-sm font-medium mb-2">
                          Type of Service
                        </label>
                        <Select value={formData.serviceType} onValueChange={handleSelectChange}>
                          <SelectTrigger className="bg-secondary/30">
                            <SelectValue placeholder="Select service type" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="legal-consultation">Legal Consultation</SelectItem>
                            <SelectItem value="litigation">Litigation</SelectItem>
                            <SelectItem value="corporate">Corporate Law</SelectItem>
                            <SelectItem value="real-estate">Real Estate & RERA</SelectItem>
                            <SelectItem value="banking">Banking & Finance</SelectItem>
                            <SelectItem value="ipr">Intellectual Property</SelectItem>
                            <SelectItem value="trademark-dsc">Trademark & Digital Signatures (DSC)</SelectItem>
                            <SelectItem value="dsc-emudhra">Digital Signature - eMudhra</SelectItem>
                            <SelectItem value="dsc-speedsign">Digital Signature - SpeedSignCA</SelectItem>
                            <SelectItem value="labour">Labour & Employment</SelectItem>
                            <SelectItem value="cyber">Cyber Law</SelectItem>
                            <SelectItem value="taxation">Taxation</SelectItem>
                            <SelectItem value="other">Other</SelectItem>
                            <SelectItem value="career-inquiry">Career Inquiry</SelectItem>
                            <SelectItem value="for-associateship">For Associateship</SelectItem>
                            <SelectItem value="for-internships">For Internships</SelectItem>
                            <SelectItem value="for-paralegal">For Paralegal</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <label htmlFor="subject" className="block text-sm font-medium mb-2">
                          Subject <span className="text-destructive">*</span>
                        </label>
                        <Input
                          id="subject"
                          name="subject"
                          required
                          value={formData.subject}
                          onChange={handleInputChange}
                          placeholder="Brief subject of your inquiry"
                          className="bg-secondary/30"
                        />
                      </div>

                      <div>
                        <label htmlFor="message" className="block text-sm font-medium mb-2">
                          Message <span className="text-destructive">*</span>
                        </label>
                        <Textarea
                          id="message"
                          name="message"
                          required
                          rows={5}
                          value={formData.message}
                          onChange={handleInputChange}
                          placeholder="Please describe your legal needs..."
                          className="bg-secondary/30"
                        />
                      </div>

                      <div>
                        <label htmlFor="files" className="block text-sm font-medium mb-2">
                          Attach Documents (Optional)
                        </label>
                        <div className="relative">
                          <input
                            id="files"
                            type="file"
                            multiple
                            onChange={handleFileSelect}
                            accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
                            className="hidden"
                          />
                          <label
                            htmlFor="files"
                            className="flex items-center justify-center gap-2 px-4 py-3 border-2 border-dashed border-secondary rounded-lg cursor-pointer hover:border-accent hover:bg-secondary/20 transition-colors"
                          >
                            <FileUp className="h-4 w-4 text-muted-foreground" />
                            <span className="text-sm text-muted-foreground">
                              Click to upload or drag files (Max 5MB each, up to 5 files)
                            </span>
                          </label>
                        </div>

                        {selectedFiles.length > 0 && (
                          <div className="mt-3 space-y-2">
                            {selectedFiles.map((file, index) => (
                              <div
                                key={index}
                                className="flex items-center justify-between bg-secondary/20 p-3 rounded-lg"
                              >
                                <span className="text-sm text-foreground truncate">{file.name}</span>
                                <button
                                  type="button"
                                  onClick={() => removeFile(index)}
                                  className="p-1 hover:bg-secondary rounded transition-colors"
                                >
                                  <X className="h-4 w-4 text-muted-foreground" />
                                </button>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>

                      <Button
                        type="submit"
                        disabled={isSubmitting || !otpVerified}
                        className="w-full bg-primary hover:bg-primary/90 text-primary-foreground py-6"
                      >
                        {isSubmitting ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Sending...
                          </>
                        ) : !otpSent ? (
                          <>
                            <Shield className="mr-2 h-4 w-4" />
                            Verify Email to Continue
                          </>
                        ) : !otpVerified ? (
                          <>
                            <Shield className="mr-2 h-4 w-4" />
                            Complete Verification
                          </>
                        ) : (
                          <>
                            <Send className="mr-2 h-4 w-4" />
                            Submit & Get Contacted Soon
                            <ArrowRight className="ml-2 h-4 w-4" />
                          </>
                        )}
                      </Button>

                      <p className="text-xs text-muted-foreground text-center">
                        By submitting this form, you acknowledge this does not create an attorney-client relationship.
                      </p>
                    </form>
                  </CardContent>
                </Card>
              </ScrollReveal>
            </div>
          </div>
        </div>
      </section>

      <PaymentModal
        isOpen={showPaymentModal}
        onClose={() => setShowPaymentModal(false)}
        email={formData.email}
        name={formData.name}
        phone={formData.phone}
        contactMessage={formData.message}
        onPaymentSuccess={() => {
          toast({
            title: "Payment Successful!",
            description: "Receipt sent to your email. We will get in touch soon.",
          })
          setShowPaymentModal(false)
        }}
      />

      <Footer />
    </div>
  )
}
