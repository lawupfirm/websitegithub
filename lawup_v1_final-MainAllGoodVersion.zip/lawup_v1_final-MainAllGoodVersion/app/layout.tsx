import type React from "react"
import type { Metadata, Viewport } from "next"
import { Inter, Playfair_Display } from "next/font/google"
import { SpeedInsights } from "@vercel/speed-insights/next"
import "./globals.css"
import { OrganizationSchema } from "@/components/seo/organization-schema"
import { DisclaimerPopup } from "@/components/disclaimer-popup"
import { Toaster } from "@/components/ui/toaster"
import { FloatingContactWidget } from "@/components/floating-contact-widget"

const inter = Inter({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-inter",
  preload: true,
  fallback: ["system-ui", "arial"],
})

const playfair = Playfair_Display({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-playfair",
  preload: true,
  fallback: ["Georgia", "serif"],
})

export const metadata: Metadata = {
  title: "LawUp Consulting | India's Premier Legal Counsel",
  description:
    "Full-service Indian law firm with over 5 years of excellence and 5,000+ matters handled. Expert legal services in corporate law, litigation, regulatory compliance, and strategic counsel across India.",
  keywords: [
    "law firm India",
    "legal services",
    "corporate law",
    "litigation",
    "legal consultation",
    "advocates India",
    "business law",
    "regulatory compliance",
    "cyber law",
    "banking law",
    "LawUp",
    "legal counsel India",
    "commercial disputes",
    "M&A lawyers India",
  ],
  authors: [{ name: "LawUp Consulting" }],
  creator: "LawUp Consulting",
  publisher: "LawUp Consulting",
  icons: {
    icon: "/favicon.ico",
    shortcut: "/favicon.ico",
    apple: "/apple-icon.png",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  openGraph: {
    title: "LawUp Consulting | India's Premier Legal Counsel",
    description:
      "Full-service Indian law firm delivering strategic legal excellence. 5,000+ matters handled with unwavering commitment to integrity and client success.",
    type: "website",
    locale: "en_IN",
    url: "https://lawup.in",
    siteName: "LawUp Consulting",
    images: [
      {
        url: "/images/lady-justice.png",
        width: 1200,
        height: 630,
        alt: "LawUp Consulting - India's Premier Legal Counsel",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "LawUp Consulting | India's Premier Legal Counsel",
    description:
      "Full-service Indian law firm delivering strategic legal excellence across corporate, litigation, and regulatory matters.",
    images: ["/images/lady-justice.png"],
  },
  alternates: {
    canonical: "https://lawup.in",
  },
  verification: {
    google: "google-site-verification-code",
  },
    generator: 'v0.app'
}

export const viewport: Viewport = {
  themeColor: "#1a1f36",
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
  userScalable: true,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${inter.variable} ${playfair.variable}`}>
      <head>
        <OrganizationSchema />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
      </head>
      <body className="font-sans antialiased">
        <DisclaimerPopup />
        {children}
        <Toaster />
        <FloatingContactWidget />
        <SpeedInsights />
      </body>
    </html>
  )
}
