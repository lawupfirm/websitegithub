import type { Metadata } from "next"
import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Calendar, MapPin, Clock, Users, GraduationCap, FileText, Mail } from "lucide-react"

export const metadata: Metadata = {
  title: "Internships - LawUp Consulting | Legal Internship Opportunities",
  description:
    "Join LawUp Consulting as a legal intern. Gain hands-on experience in corporate law, litigation, and legal research. Apply for internship positions in Jaipur, Rajasthan.",
  keywords: [
    "legal internship",
    "law firm internship",
    "legal training",
    "law student internship",
    "corporate law internship",
    "litigation internship",
    "legal research internship",
    "Jaipur internship",
    "law firm training",
  ],
  openGraph: {
    title: "Internships - LawUp Consulting",
    description: "Join our team as a legal intern and gain valuable experience in professional legal practice.",
  },
  alternates: {
    canonical: "https://lawup.in/internships",
  },
}

const internshipPositions = [
  {
    id: 1,
    title: "Legal Research Intern",
    duration: "3-6 months",
    location: "Jaipur, Rajasthan",
    type: "Full-time",
    stipend: "₹8,000 - ₹12,000/month",
    requirements: [
      "Currently pursuing LLB/LLM",
      "Strong research and writing skills",
      "Knowledge of legal databases",
      "Attention to detail",
    ],
    responsibilities: [
      "Conduct legal research on various practice areas",
      "Draft legal memorandums and briefs",
      "Assist in case preparation",
      "Maintain legal databases and files",
    ],
    skills: ["Legal Research", "Legal Writing", "Case Analysis", "Database Management"],
    posted: "2025-01-10",
    deadline: "2025-02-15",
  },
  {
    id: 2,
    title: "Corporate Law Intern",
    duration: "4-6 months",
    location: "Jaipur, Rajasthan",
    type: "Full-time",
    stipend: "₹10,000 - ₹15,000/month",
    requirements: [
      "LLB/LLM student (3rd year onwards)",
      "Interest in corporate and commercial law",
      "Good communication skills",
      "Basic understanding of company law",
    ],
    responsibilities: [
      "Assist in corporate compliance matters",
      "Draft corporate documents and agreements",
      "Support due diligence processes",
      "Attend client meetings and court proceedings",
    ],
    skills: ["Corporate Law", "Contract Drafting", "Compliance", "Client Relations"],
    posted: "2025-01-08",
    deadline: "2025-02-10",
  },
  {
    id: 3,
    title: "Litigation Support Intern",
    duration: "3-4 months",
    location: "Jaipur, Rajasthan",
    type: "Full-time",
    stipend: "₹7,000 - ₹10,000/month",
    requirements: [
      "Law student (2nd year onwards)",
      "Interest in litigation and court procedures",
      "Good organizational skills",
      "Ability to work under pressure",
    ],
    responsibilities: [
      "Assist advocates in court proceedings",
      "Prepare case files and documents",
      "Conduct client interviews",
      "Research case laws and precedents",
    ],
    skills: ["Litigation Support", "Court Procedures", "Case Management", "Client Communication"],
    posted: "2025-01-12",
    deadline: "2025-02-20",
  },
  {
    id: 4,
    title: "Intellectual Property Intern",
    duration: "4-5 months",
    location: "Jaipur, Rajasthan",
    type: "Full-time",
    stipend: "₹9,000 - ₹13,000/month",
    requirements: [
      "LLB/LLM with focus on IP law",
      "Understanding of trademark and patent law",
      "Research and analytical skills",
      "Technology-oriented mindset",
    ],
    responsibilities: [
      "Assist in trademark and patent applications",
      "Conduct IP searches and analysis",
      "Draft IP-related documents",
      "Support IP litigation matters",
    ],
    skills: ["IP Law", "Patent Research", "Trademark Law", "Technology Law"],
    posted: "2025-01-05",
    deadline: "2025-02-05",
  },
]

export default function InternshipsPage() {
  return (
    <div className="min-h-screen">
      <Navigation />

      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-primary/5 to-accent/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="font-playfair text-4xl lg:text-5xl font-bold text-primary mb-6">Legal Internships</h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
              Launch your legal career with hands-on experience at LawUp Consulting. Join our team and learn from
              experienced advocates in a professional environment.
            </p>
          </div>
        </div>
      </section>

      {/* Internship Benefits */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="font-playfair text-3xl font-bold text-primary mb-4">Why Intern With Us?</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Gain valuable experience and build your legal career with comprehensive training and mentorship.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="text-center">
              <CardContent className="p-6">
                <GraduationCap className="h-12 w-12 text-accent mx-auto mb-4" />
                <h3 className="font-semibold mb-2">Practical Learning</h3>
                <p className="text-sm text-muted-foreground">
                  Work on real cases and gain hands-on experience in legal practice.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="p-6">
                <Users className="h-12 w-12 text-accent mx-auto mb-4" />
                <h3 className="font-semibold mb-2">Expert Mentorship</h3>
                <p className="text-sm text-muted-foreground">
                  Learn from experienced advocates and senior legal professionals.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="p-6">
                <FileText className="h-12 w-12 text-accent mx-auto mb-4" />
                <h3 className="font-semibold mb-2">Skill Development</h3>
                <p className="text-sm text-muted-foreground">Develop legal research, writing, and analytical skills.</p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="p-6">
                <Clock className="h-12 w-12 text-accent mx-auto mb-4" />
                <h3 className="font-semibold mb-2">Flexible Duration</h3>
                <p className="text-sm text-muted-foreground">
                  Choose internship duration that fits your academic schedule.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Available Positions */}
      <section className="py-16 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="font-playfair text-3xl font-bold text-primary mb-4">Current Openings</h2>
            <p className="text-muted-foreground">
              Explore our available internship positions and find the perfect opportunity for your career growth.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {internshipPositions.map((position) => (
              <Card key={position.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-xl mb-2">{position.title}</CardTitle>
                      <div className="flex flex-wrap gap-2 mb-3">
                        <Badge variant="secondary">{position.type}</Badge>
                        <Badge variant="outline">{position.duration}</Badge>
                      </div>
                    </div>
                    <div className="text-right text-sm text-muted-foreground">
                      <div className="flex items-center gap-1 mb-1">
                        <Calendar className="h-3 w-3" />
                        Posted: {new Date(position.posted).toLocaleDateString()}
                      </div>
                      <div className="text-red-600 font-medium">
                        Deadline: {new Date(position.deadline).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="space-y-4">
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <MapPin className="h-4 w-4" />
                      {position.location}
                    </div>
                    <div className="font-medium text-green-600">{position.stipend}</div>
                  </div>

                  <div>
                    <h4 className="font-semibold mb-2">Requirements:</h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      {position.requirements.map((req, index) => (
                        <li key={index} className="flex items-start gap-2">
                          <span className="text-accent mt-1">•</span>
                          {req}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-semibold mb-2">Key Responsibilities:</h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      {position.responsibilities.slice(0, 3).map((resp, index) => (
                        <li key={index} className="flex items-start gap-2">
                          <span className="text-accent mt-1">•</span>
                          {resp}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-semibold mb-2">Skills You'll Develop:</h4>
                    <div className="flex flex-wrap gap-2">
                      {position.skills.map((skill, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <Button className="w-full mt-4">
                    <Mail className="mr-2 h-4 w-4" />
                    Apply Now
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Application Process */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="font-playfair text-3xl font-bold text-primary mb-4">Application Process</h2>
            <p className="text-muted-foreground">
              Follow these simple steps to apply for an internship position with us.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-12 h-12 bg-primary text-white rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                1
              </div>
              <h3 className="font-semibold mb-2">Submit Application</h3>
              <p className="text-sm text-muted-foreground">
                Send your resume, cover letter, and academic transcripts to support@lawup.in
              </p>
            </div>

            <div className="text-center">
              <div className="w-12 h-12 bg-primary text-white rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                2
              </div>
              <h3 className="font-semibold mb-2">Initial Screening</h3>
              <p className="text-sm text-muted-foreground">
                Our team will review your application and contact shortlisted candidates within 5-7 days.
              </p>
            </div>

            <div className="text-center">
              <div className="w-12 h-12 bg-primary text-white rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                3
              </div>
              <h3 className="font-semibold mb-2">Interview & Selection</h3>
              <p className="text-sm text-muted-foreground">
                Attend an interview (in-person or virtual) and receive confirmation within 2-3 days.
              </p>
            </div>
          </div>

          <div className="mt-12 text-center">
            <Card className="max-w-2xl mx-auto">
              <CardContent className="p-6">
                <h3 className="font-semibold mb-4">Ready to Apply?</h3>
                <p className="text-muted-foreground mb-6">
                  Send your application documents to our HR team and take the first step towards your legal career.
                </p>
                <Button size="lg" className="w-full sm:w-auto">
                  <Mail className="mr-2 h-4 w-4" />
                  Email: support@lawup.in
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
