import type { Metadata } from "next"
import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export const metadata: Metadata = {
  title: "Terms of Service - LawUp Consulting",
  description: "Terms of Service for LawUp Consulting - Legal terms and conditions for using our website and services.",
  alternates: {
    canonical: "https://lawup.in/terms",
  },
}

export default function TermsPage() {
  return (
    <div className="min-h-screen">
      <Navigation />

      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-primary/5 to-accent/5">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="font-playfair text-4xl lg:text-5xl font-bold text-primary mb-6">Terms of Service</h1>
            <p className="text-xl text-muted-foreground leading-relaxed">
              Please read these terms carefully before using our website and services.
            </p>
          </div>
        </div>
      </section>

      {/* Terms Content */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">Terms of Service</CardTitle>
              <p className="text-muted-foreground">Last updated: January 2025</p>
            </CardHeader>
            <CardContent className="prose prose-gray max-w-none">
              <div className="space-y-8">
                <section>
                  <h2 className="text-xl font-semibold text-primary mb-4">1. Acceptance of Terms</h2>
                  <p className="text-muted-foreground leading-relaxed">
                    By accessing and using this website, you accept and agree to be bound by the terms and provision of
                    this agreement. If you do not agree to abide by the above, please do not use this service.
                  </p>
                </section>

                <section>
                  <h2 className="text-xl font-semibold text-primary mb-4">2. Website Usage</h2>
                  <p className="text-muted-foreground leading-relaxed mb-4">
                    This website is provided for informational purposes only. You may use this website for lawful
                    purposes only. You agree not to use the website:
                  </p>
                  <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
                    <li>In any way that violates any applicable law or regulation</li>
                    <li>To transmit or procure the sending of any unsolicited advertising or promotional material</li>
                    <li>To impersonate or attempt to impersonate the company or its employees</li>
                    <li>To engage in any other conduct that restricts or inhibits anyone's use of the website</li>
                  </ul>
                </section>

                <section>
                  <h2 className="text-xl font-semibold text-primary mb-4">3. No Attorney-Client Relationship</h2>
                  <p className="text-muted-foreground leading-relaxed">
                    The information on this website is not intended as legal advice. Communication with LawUp Consulting
                    through this website does not create an attorney-client relationship. Do not send confidential
                    information until an attorney-client relationship has been established.
                  </p>
                </section>

                <section>
                  <h2 className="text-xl font-semibold text-primary mb-4">4. Bar Council of India Compliance</h2>
                  <p className="text-muted-foreground leading-relaxed">
                    In accordance with the Bar Council of India rules, this website does not solicit work or advertise.
                    Any information provided is for educational purposes only. Users acknowledge they are seeking
                    information of their own accord.
                  </p>
                </section>

                <section>
                  <h2 className="text-xl font-semibold text-primary mb-4">5. Intellectual Property</h2>
                  <p className="text-muted-foreground leading-relaxed">
                    The content, organization, graphics, design, compilation, magnetic translation, digital conversion
                    and other matters related to the website are protected under applicable copyrights, trademarks and
                    other proprietary rights.
                  </p>
                </section>

                <section>
                  <h2 className="text-xl font-semibold text-primary mb-4">6. Disclaimer of Warranties</h2>
                  <p className="text-muted-foreground leading-relaxed">
                    The information on this website is provided on an "as is" basis. To the fullest extent permitted by
                    law, LawUp Consulting excludes all representations, warranties, conditions and terms whether express
                    or implied.
                  </p>
                </section>

                <section>
                  <h2 className="text-xl font-semibold text-primary mb-4">7. Limitation of Liability</h2>
                  <p className="text-muted-foreground leading-relaxed">
                    LawUp Consulting shall not be liable for any indirect, incidental, special, consequential or
                    punitive damages, including without limitation, loss of profits, data, use, goodwill, or other
                    intangible losses.
                  </p>
                </section>

                <section>
                  <h2 className="text-xl font-semibold text-primary mb-4">8. Governing Law</h2>
                  <p className="text-muted-foreground leading-relaxed">
                    These terms shall be interpreted and governed in accordance with the laws of India. Any disputes
                    shall be subject to the exclusive jurisdiction of the courts in Jaipur, Rajasthan.
                  </p>
                </section>

                <section>
                  <h2 className="text-xl font-semibold text-primary mb-4">9. Contact Information</h2>
                  <p className="text-muted-foreground leading-relaxed">
                    Questions about the Terms of Service should be sent to us at:
                  </p>
                  <div className="mt-4 p-4 bg-muted rounded-lg">
                    <p className="font-semibold">LawUp Consulting</p>
                    <p className="text-muted-foreground">Email: support@lawup.in</p>
                    <p className="text-muted-foreground">Phone: +91-9716968000</p>
                    <p className="text-muted-foreground">Address: Chamber: Ground B188a, Jamunapuri, Jaipur, Rajasthan - 302039</p>
                  </div>
                </section>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      <Footer />
    </div>
  )
}
