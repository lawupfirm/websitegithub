import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { PageHero } from "@/components/page-hero"
import { ScrollReveal } from "@/components/scroll-reveal"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { LegalCalculators } from "@/components/legal-calculators"
import {
  FileText,
  Scale,
  BookOpen,
  Users,
  Building,
  Home,
  ShoppingCart,
  Heart,
  ArrowRight,
  ExternalLink,
  Calendar,
  Calculator,
  Gavel,
  FileCheck,
  Shield,
  Briefcase,
  FileSearch,
  AlertCircle,
  CheckCircle,
  Clock,
  Copyright,
} from "lucide-react"

const courtResources = [
  {
    category: "Supreme Court of India",
    icon: Scale,
    color: "from-blue-600 to-blue-700",
    resources: [
      {
        title: "Daily Cause Lists",
        url: "https://www.sci.gov.in/cause-list/",
        description: "Access daily, advance, and weekly cause lists",
      },
      {
        title: "Supreme Court Calendar 2025",
        url: "https://www.sci.gov.in/calendar/",
        description: "Court working days and holidays",
      },
      {
        title: "Case Status",
        url: "https://main.sci.gov.in/case-status",
        description: "Track case status by CNR or case number",
      },
      {
        title: "Latest Judgments",
        url: "https://main.sci.gov.in/judgments",
        description: "Search and download recent judgments",
      },
      {
        title: "Landmark Judgments",
        url: "https://www.sci.gov.in/landmark-judgment-summaries/",
        description: "Important Supreme Court landmark judgments",
      },
    ],
  },
  {
    category: "Rajasthan High Court & Jaipur Courts",
    icon: Building,
    color: "from-pink-600 to-pink-700",
    resources: [
      {
        title: "Rajasthan HC - Cause Lists",
        url: "https://hcraj.nic.in/",
        description: "Daily orders, cause lists, and case status",
      },
      {
        title: "Rajasthan HC - Jaipur Bench",
        url: "https://hcraj.nic.in/causelist/",
        description: "Jaipur bench cause lists and orders",
      },
      {
        title: "Rajasthan HC - Jodhpur Bench",
        url: "https://hcraj.nic.in/jodhpur/",
        description: "Jodhpur bench cause lists",
      },
      {
        title: "District Courts Jaipur",
        url: "https://districts.ecourts.gov.in/jaipur-rural",
        description: "Jaipur district and session courts",
      },
      {
        title: "NCLT Jaipur Bench",
        url: "https://nclt.gov.in/jaipur-bench",
        description: "National Company Law Tribunal - Jaipur",
      },
      {
        title: "Rajasthan Judiciary Services",
        url: "https://hcraj.nic.in/e-services.php",
        description: "e-Filing, case status, and online services",
      },
    ],
  },
  {
    category: "High Courts - National",
    icon: Building,
    color: "from-purple-600 to-purple-700",
    resources: [
      {
        title: "Delhi High Court - Cause Lists",
        url: "https://dhcbkp.nic.in/causelist/",
        description: "Daily, regular, and advance cause lists",
      },
      {
        title: "Bombay High Court - Case Status",
        url: "https://hcservices.ecourts.gov.in/ecourtindiaHC/",
        description: "Search cases by advocate name or case number",
      },
      {
        title: "All High Courts Portal",
        url: "https://services.ecourts.gov.in/ecourtindia_v6/",
        description: "Access all High Court services nationwide",
      },
      {
        title: "eCourts Case Status",
        url: "https://services.ecourts.gov.in/ecourtindia_v6/?p=casestatus/index",
        description: "National case status search across courts",
      },
    ],
  },
  {
    category: "Legal Databases",
    icon: BookOpen,
    color: "from-green-600 to-green-700",
    resources: [
      {
        title: "Indian Kanoon",
        url: "https://indiankanoon.org/",
        description: "Free database of Indian case law and legislation",
      },
      {
        title: "SCC Online",
        url: "https://www.scconline.com/",
        description: "Comprehensive legal research platform",
      },
      {
        title: "Manupatra",
        url: "https://www.manupatrafast.com/",
        description: "Extensive Indian legal material database",
      },
      {
        title: "India Code",
        url: "https://www.indiacode.nic.in/",
        description: "Official repository of all Central Acts",
      },
    ],
  },
  {
    category: "Government Portals",
    icon: Users,
    color: "from-orange-600 to-orange-700",
    resources: [
      {
        title: "Ministry of Law & Justice",
        url: "https://lawmin.gov.in/",
        description: "Official portal for legal affairs",
      },
      {
        title: "National Legal Services Authority",
        url: "https://nalsa.gov.in/",
        description: "Free legal aid and services",
      },
      {
        title: "Consumer Helpline",
        url: "https://consumerhelpline.gov.in/",
        description: "File consumer complaints online",
      },
      {
        title: "RERA India",
        url: "https://rera.india.gov.in/",
        description: "Real estate regulatory authority portal",
      },
    ],
  },
]

const latestJudgments = [
  {
    title: "Gayatri Balasamy v. ISG Novasoft Technologies Ltd.",
    date: "January 2025",
    court: "Supreme Court of India",
    subject: "Arbitration Law - Award Modification",
    summary:
      "SC held that arbitral awards can be modified under Section 34, expanding judicial review scope in arbitration matters.",
    url: "https://www.sci.gov.in/landmark-judgment-summaries/",
  },
  {
    title: "Varshatai Balasaheb Salunke v. State of Maharashtra",
    date: "January 2025",
    court: "Supreme Court of India",
    subject: "Linguistic Rights - Urdu Language",
    summary:
      "Landmark judgment on linguistic rights, upholding right to use Urdu in official proceedings across India.",
    url: "https://www.sci.gov.in/landmark-judgment-summaries/",
  },
  {
    title: "Imran Pratapgadhi v. State of Uttar Pradesh",
    date: "December 2024",
    court: "Supreme Court of India",
    subject: "Freedom of Expression - Article 19(1)(a)",
    summary:
      "SC reinforced protection of freedom of expression and set guidelines for restrictions under Article 19(2).",
    url: "https://www.sci.gov.in/landmark-judgment-summaries/",
  },
]

const legalTools = [
  {
    title: "Court Fee Calculator",
    description: "Calculate court fees for various types of cases",
    icon: Calculator,
    features: ["Civil suits", "Appeals", "Revision petitions", "State-wise calculation"],
  },
  {
    title: "Limitation Period Calculator",
    description: "Check limitation periods under Indian law",
    icon: Calendar,
    features: ["Civil cases", "Criminal cases", "Property disputes", "Contract matters"],
  },
  {
    title: "Interest Calculator",
    description: "Calculate simple and compound interest for legal matters",
    icon: Calculator,
    features: ["Pre-judgment interest", "Post-judgment interest", "Pendente lite interest", "Custom rates"],
  },
  {
    title: "Stamp Duty Calculator",
    description: "Estimate stamp duty for property transactions",
    icon: FileCheck,
    features: ["State-wise rates", "Property value based", "Document types", "Registration charges"],
  },
]

const criminalLawGuides = [
  {
    title: "FIR & Investigation",
    icon: FileSearch,
    color: "from-red-500 to-red-600",
    topics: [
      "How to file an FIR",
      "Zero FIR procedure",
      "Police investigation process",
      "Rights during investigation",
      "Section 154 CrPC/BNSS",
      "e-FIR filing online",
    ],
  },
  {
    title: "Arrest & Bail",
    icon: Shield,
    color: "from-blue-500 to-blue-600",
    topics: [
      "Types of arrest procedures",
      "Anticipatory bail application",
      "Regular bail conditions",
      "Section 41 BNSS guidelines",
      "Bail in bailable offenses",
      "Supreme Court bail guidelines",
    ],
  },
  {
    title: "Quashing of FIR",
    icon: AlertCircle,
    color: "from-yellow-500 to-yellow-600",
    topics: [
      "Section 482 CrPC/BNSS petition",
      "Grounds for quashing FIR",
      "High Court jurisdiction",
      "Compoundable offenses",
      "Abuse of process of law",
      "Lack of prima facie case",
    ],
  },
  {
    title: "Charge & Trial",
    icon: Gavel,
    color: "from-purple-500 to-purple-600",
    topics: [
      "Framing of charges procedure",
      "Trial process stages",
      "Evidence presentation",
      "Examination of witnesses",
      "Arguments and judgment",
      "Appeal process",
    ],
  },
]

const civilLawGuides = [
  {
    title: "Injunctions",
    icon: AlertCircle,
    color: "from-indigo-500 to-indigo-600",
    topics: [
      "Temporary injunction (Order 39)",
      "Permanent injunction",
      "Ex-parte injunction",
      "Mandatory injunction",
      "Conditions for grant",
      "Balance of convenience test",
    ],
  },
  {
    title: "Recovery Suits",
    icon: FileCheck,
    color: "from-green-500 to-green-600",
    topics: [
      "Money recovery suit procedure",
      "Summary suit (Order 37 CPC)",
      "Written statement filing",
      "Summary judgment",
      "Execution of decree",
      "Attachment of property",
    ],
  },
  {
    title: "Limitation",
    icon: Clock,
    color: "from-orange-500 to-orange-600",
    topics: [
      "Limitation Act 1963 provisions",
      "Limitation periods for suits",
      "Condonation of delay",
      "Section 5 application",
      "Acknowledgment of debt",
      "Part performance doctrine",
    ],
  },
  {
    title: "Procedural Law",
    icon: BookOpen,
    color: "from-teal-500 to-teal-600",
    topics: [
      "CPC stages and procedures",
      "Plaint and written statement",
      "Issues framing",
      "Trial procedure",
      "Evidence Act provisions",
      "Judgment and decree",
    ],
  },
]

const newCriminalLaws = [
  {
    title: "BNS Explained",
    subtitle: "Bharatiya Nyaya Sanhita 2023",
    icon: Scale,
    color: "from-blue-600 to-blue-700",
    description: "Replaces IPC 1860 with 358 sections (reduced from 511)",
    keyPoints: [
      "21 new offenses including mob lynching, terrorism, organized crime",
      "Hate crimes and hate speech provisions",
      "Redefined sedition as acts endangering national integrity",
      "Enhanced punishment for crimes against women and children",
      "Community service as punishment introduced",
      "Effective from July 1, 2024",
    ],
    url: "https://www.mha.gov.in/en/commoncontent/new-criminal-laws",
  },
  {
    title: "BNSS Explained",
    subtitle: "Bharatiya Nagarik Suraksha Sanhita 2023",
    icon: Shield,
    color: "from-green-600 to-green-700",
    description: "Replaces CrPC 1973 with victim-centric approach",
    keyPoints: [
      "Zero FIR system nationwide",
      "Electronic summons and warrants",
      "Forensic investigation mandatory for serious crimes",
      "Trials in absentia for proclaimed offenders",
      "Witness Protection Scheme",
      "Extended police custody provisions",
    ],
    url: "https://www.mha.gov.in/en/commoncontent/new-criminal-laws",
  },
  {
    title: "Sakshya Adhiniyam",
    subtitle: "Bharatiya Sakshya Adhiniyam 2023",
    icon: FileCheck,
    color: "from-purple-600 to-purple-700",
    description: "Replaces Evidence Act 1872 with digital-ready provisions",
    keyPoints: [
      "Electronic and digital records as primary evidence",
      "Admissibility of electronic documents",
      "Digital signatures validity",
      "Video conferencing for testimony",
      "Secondary evidence rules updated",
      "Modern forensic evidence provisions",
    ],
    url: "https://www.mha.gov.in/en/commoncontent/new-criminal-laws",
  },
]

const intellectualPropertyGuides = [
  {
    title: "Patents",
    icon: Briefcase,
    color: "from-indigo-500 to-indigo-600",
    topics: [
      "Patent filing procedure (Form 1)",
      "Search and examination process",
      "Patent claim drafting",
      "Request for examination (Form 18)",
      "Patent prosecution strategy",
      "Patent infringement & enforcement",
    ],
  },
  {
    title: "Trademarks",
    icon: Shield,
    color: "from-amber-500 to-amber-600",
    topics: [
      "Trademark search on IP India",
      "Classes of goods/services",
      "Filing & examination process",
      "Office action responses",
      "Trademark renewal every 10 years",
      "Trademark licensing & assignment",
    ],
  },
  {
    title: "Copyrights",
    icon: FileText,
    color: "from-rose-500 to-rose-600",
    topics: [
      "Copyright registration (literary/artistic)",
      "Software copyright protection",
      "Copyright infringement remedies",
      "Orphan works & exceptions",
      "Assignment & licensing",
      "Copyright duration & renewal",
    ],
  },
  {
    title: "Designs & GI",
    icon: Home,
    color: "from-cyan-500 to-cyan-600",
    topics: [
      "Design registration process",
      "Novelty & independent creation",
      "Geographical indication filing",
      "GI protection period",
      "Design amendment & renewal",
      "Opposition & cancellation",
    ],
  },
]

const ncltAppealGuides = [
  {
    title: "NCLT Applications",
    icon: FileCheck,
    color: "from-green-500 to-green-600",
    topics: [
      "Oppression & mismanagement (₹5,000)",
      "Mergers, amalgamations, arrangements (₹5,000)",
      "Company revival & restoration (₹1,000)",
      "Change in registered office (₹5,000)",
      "CIRP - Financial creditor (₹25,000)",
      "CIRP - Operational creditor (₹2,000)",
    ],
  },
  {
    title: "NCLAT Appeals",
    icon: Scale,
    color: "from-blue-500 to-blue-600",
    topics: [
      "Appeal filing from NCLT order",
      "Certified copy requirement",
      "Appeal memorandum preparation",
      "Jurisdictional grounds",
      "Stay application procedure",
      "Appeal disposal timeline (90 days)",
    ],
  },
]

const legalGuides = [
  {
    category: "Consumer Rights",
    icon: ShoppingCart,
    color: "from-blue-500 to-blue-600",
    guides: [
      {
        title: "How to File a Consumer Complaint - Complete Process",
        description: "Step-by-step guide to filing consumer complaints under Consumer Protection Act 2019",
        process: [
          {
            step: "Step 1: Gather Documentation",
            details:
              "Collect purchase invoice, warranty card, payment receipts, photographs/videos of defect, correspondence with seller/manufacturer, and any other relevant documents.",
          },
          {
            step: "Step 2: Send Legal Notice",
            details:
              "Send a written complaint to the seller/service provider within 30 days. Keep a copy and proof of delivery. Wait 30-45 days for response.",
          },
          {
            step: "Step 3: Determine Jurisdiction",
            details:
              "District Forum: Claims up to ₹1 crore | State Commission: ₹1-10 crores | National Commission: Above ₹10 crores",
          },
          {
            step: "Step 4: File Online Complaint",
            details:
              "Visit https://edaakhil.nic.in/ and register. Fill Form 1-A with case details, upload documents (max 20MB), pay prescribed fee online.",
          },
          {
            step: "Step 5: Attend Hearings",
            details:
              "Receive notice within 21 days. Attend hearings as scheduled. Present evidence and witnesses. Forum may order mediation.",
          },
          {
            step: "Step 6: Obtain Order",
            details:
              "Order typically passed within 3-5 months. If favorable, manufacturer must comply within 45 days or face penalties.",
          },
        ],
        documents: ["Purchase invoice", "Legal notice copy", "ID proof", "Address proof", "Defect evidence"],
        timeline: "3-6 months for district forum",
        fees: "₹200-5000 based on claim amount",
      },
    ],
  },
  {
    category: "Property & Real Estate",
    icon: Home,
    color: "from-green-500 to-green-600",
    guides: [
      {
        title: "Property Purchase Process - Complete Checklist",
        description: "Essential steps for buying property in India with legal due diligence",
        process: [
          {
            step: "Step 1: Property Search & Site Visit",
            details:
              "Identify property, verify location, check physical condition, confirm measurements match documents, inspect for encroachments.",
          },
          {
            step: "Step 2: Document Verification",
            details:
              "Verify title deed (7/12 extract in Maharashtra, Khata/RTC in Karnataka), check encumbrance certificate for 30 years, verify approved building plans, check property tax receipts.",
          },
          {
            step: "Step 3: Legal Due Diligence",
            details:
              "Hire a lawyer to verify chain of title, check for litigation/disputes, verify seller's ownership, confirm no mortgages/liens exist, check for any government acquisition.",
          },
          {
            step: "Step 4: Agreement to Sell",
            details:
              "Draft agreement with all terms, pay token advance (typically 10%), register agreement if required by state law, pay stamp duty on agreement.",
          },
          {
            step: "Step 5: Obtain NOCs",
            details:
              "Society NOC (for flats), Encumbrance Certificate, Tax Paid Certificate, Occupancy Certificate, Completion Certificate, Building Plan Approval.",
          },
          {
            step: "Step 6: Home Loan (if applicable)",
            details:
              "Apply for loan, bank conducts technical and legal verification, loan approval and sanction letter, create lien on property.",
          },
          {
            step: "Step 7: Sale Deed Execution",
            details:
              "Draft sale deed, pay stamp duty (varies by state: 4-7%), pay registration charges (1%), execute before Sub-Registrar, both parties sign in presence of witnesses.",
          },
          {
            step: "Step 8: Post-Registration",
            details:
              "Collect registered sale deed, transfer property tax, transfer electricity/water connections, update society records (if flat), obtain possession.",
          },
        ],
        documents: [
          "Sale deed/Title deed",
          "Encumbrance certificate",
          "Property tax receipts",
          "Building plan approval",
          "Completion certificate",
          "NOC from society",
          "PAN card",
          "Aadhar card",
        ],
        timeline: "45-90 days from agreement to registration",
        fees: "Stamp duty 4-7% + Registration 1% + Legal fees ₹25,000-1,00,000",
      },
    ],
  },
  {
    category: "Corporate & Business",
    icon: Building,
    color: "from-purple-500 to-purple-600",
    guides: [
      {
        title: "Company Registration Process - Step by Step",
        description: "Complete guide to registering a Private Limited Company in India",
        process: [
          {
            step: "Step 1: Obtain Digital Signature Certificate (DSC)",
            details:
              "Apply for Class 3 DSC for all directors. Required documents: PAN, Aadhaar, photograph. Cost: ₹1,000-2,000. Validity: 2 years. Time: 2-3 days.",
          },
          {
            step: "Step 2: Obtain Director Identification Number (DIN)",
            details:
              "File Form DIR-3 on MCA portal. Attach DSC, ID proof, address proof, photograph. Processing time: 1-2 days. No fee charged.",
          },
          {
            step: "Step 3: Name Reservation",
            details:
              "File Form RUN (SPICe+) with 2 proposed names. Check availability on MCA portal. Avoid prohibited words. Approval in 1-2 days. Valid for 20 days.",
          },
          {
            step: "Step 4: Draft MOA & AOA",
            details:
              "Memorandum of Association: Company objectives, capital structure. Articles of Association: Internal management rules. Can use model articles or customize.",
          },
          {
            step: "Step 5: File SPICe+ Form",
            details:
              "Integrated form for name reservation, incorporation, DIN, PAN, TAN. Upload MOA, AOA, ID/address proofs. Declaration by professional. Pay fees.",
          },
          {
            step: "Step 6: Pay Stamp Duty",
            details:
              "Varies by state on authorized capital. Maharashtra: ₹200-500 per ₹1 lakh. Delhi: 0.3%. Karnataka: 0.2%. Payment through NSDL portal.",
          },
          {
            step: "Step 7: Certificate of Incorporation",
            details:
              "ROC processes application in 2-5 days. Issues CIN (Corporate Identification Number). Digital certificate sent via email. Company legally formed.",
          },
          {
            step: "Step 8: Post-Incorporation Compliance",
            details:
              "Issue share certificates within 60 days. File ACTIVE form (INC-20A). Open bank account. Apply for GST if turnover > ₹40 lakhs. Maintain statutory registers.",
          },
        ],
        documents: [
          "PAN cards of directors",
          "Aadhaar cards",
          "Passport-size photographs",
          "Address proof of directors",
          "Registered office proof",
          "Rent agreement (if rented)",
          "NOC from property owner",
        ],
        timeline: "7-15 days for complete incorporation",
        fees: "Govt fees: ₹4,000-10,000 + Professional fees: ₹10,000-25,000",
      },
    ],
  },
  {
    category: "Family Law",
    icon: Heart,
    color: "from-pink-500 to-pink-600",
    guides: [
      {
        title: "Mutual Consent Divorce - Complete Procedure",
        description: "Step-by-step process for filing mutual consent divorce under Section 13B",
        process: [
          {
            step: "Step 1: Mutual Agreement",
            details:
              "Both spouses must agree on: Division of property, child custody arrangements, alimony/maintenance amount, settlement of all financial matters. Draft MOU with lawyer.",
          },
          {
            step: "Step 2: File First Motion Petition",
            details:
              "File joint petition under Section 13B in Family Court. State mutual consent and grounds. Attach marriage certificate, settlement terms. Both parties must appear together.",
          },
          {
            step: "Step 3: First Hearing",
            details:
              "Both parties appear before judge. Judge ensures consent is voluntary. Records statements under oath. No coercion or pressure. May suggest counseling.",
          },
          {
            step: "Step 4: Cooling-Off Period (6 months)",
            details:
              "Mandatory waiting period of 6-18 months from first motion. Cannot be waived (except Supreme Court in exceptional cases). Parties can reconcile during this period.",
          },
          {
            step: "Step 5: File Second Motion",
            details:
              "After 6 months but within 18 months, file second motion. Confirm mutual consent continues. Both parties must appear again. Submit final settlement terms.",
          },
          {
            step: "Step 6: Final Hearing",
            details:
              "Judge confirms both parties maintain consent. Reviews settlement terms. Ensures no coercion. May ask questions separately. Records final statements.",
          },
          {
            step: "Step 7: Decree of Divorce",
            details:
              "If satisfied, court passes decree dissolving marriage. Decree becomes final after appeal period (90 days). Marriage officially dissolved. Both receive certified copies.",
          },
          {
            step: "Step 8: Post-Divorce Compliance",
            details:
              "Execute property transfer as per settlement. Comply with alimony terms. Follow custody arrangements. Update marital status in records.",
          },
        ],
        documents: [
          "Marriage certificate",
          "ID proofs of both parties",
          "Address proofs",
          "Passport-size photographs",
          "Income proofs",
          "Property documents",
          "Custody agreement",
          "Settlement MOU",
        ],
        timeline: "Minimum 6 months to 12-18 months total",
        fees: "Court fees: ₹500-1,000 + Lawyer fees: ₹25,000-1,00,000",
      },
    ],
  },
]

export default function LegalGuidePage() {
  return (
    <div className="min-h-screen">
      <Navigation />

      <PageHero
        badge="Knowledge Center"
        title="Legal Guide & Resources"
        subtitle="Comprehensive legal guides with detailed processes, court resources for Rajasthan & Jaipur, tools, and daily resources for legal professionals."
        size="large"
      />

      {/* Court Resources - Most Important for Advocates */}
      <section className="py-16 sm:py-24 bg-gradient-to-b from-primary/5 to-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollReveal>
            <div className="text-center mb-12">
              <Gavel className="h-12 w-12 text-accent mx-auto mb-4" />
              <h2 className="font-serif text-3xl md:text-4xl font-bold text-primary mb-4">Essential Court Resources</h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Quick access to Rajasthan High Court, Jaipur Courts, Supreme Court cause lists, case status, calendars,
                and judgments
              </p>
            </div>
          </ScrollReveal>

          <div className="space-y-12">
            {courtResources.map((category, catIndex) => (
              <ScrollReveal key={catIndex}>
                <div>
                  <div className="flex items-center gap-3 mb-6">
                    <div className={`p-3 bg-gradient-to-br ${category.color} rounded-lg`}>
                      <category.icon className="h-6 w-6 text-white" />
                    </div>
                    <h3 className="font-serif text-2xl font-bold text-primary">{category.category}</h3>
                  </div>

                  <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {category.resources.map((resource, resIndex) => (
                      <ScrollReveal key={resIndex} delay={resIndex * 50}>
                        <a
                          href={resource.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="block bg-card border border-border rounded-lg p-4 hover:border-accent hover:shadow-lg transition-all duration-300 hover:-translate-y-1 group"
                        >
                          <div className="flex items-start justify-between mb-2">
                            <h4 className="font-semibold text-primary group-hover:text-accent transition-colors">
                              {resource.title}
                            </h4>
                            <ExternalLink className="h-4 w-4 text-muted-foreground group-hover:text-accent flex-shrink-0 ml-2" />
                          </div>
                          <p className="text-sm text-muted-foreground line-clamp-2">{resource.description}</p>
                        </a>
                      </ScrollReveal>
                    ))}
                  </div>
                </div>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* Latest Supreme Court Judgments */}
      <section className="py-16 sm:py-24 bg-secondary/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollReveal>
            <div className="text-center mb-12">
              <Scale className="h-12 w-12 text-accent mx-auto mb-4" />
              <h2 className="font-serif text-3xl md:text-4xl font-bold text-primary mb-4">
                Latest Supreme Court Judgments
              </h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Recent landmark judgments from the Supreme Court of India
              </p>
            </div>
          </ScrollReveal>

          <div className="grid md:grid-cols-3 gap-6">
            {latestJudgments.map((judgment, index) => (
              <ScrollReveal key={index} delay={index * 100}>
                <a
                  href={judgment.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block bg-card border border-border rounded-xl p-6 hover:border-accent hover:shadow-xl transition-all duration-300 hover:-translate-y-1 group"
                >
                  <div className="flex items-start justify-between mb-3">
                    <span className="text-xs font-medium text-accent bg-accent/10 px-3 py-1 rounded-full">
                      {judgment.date}
                    </span>
                    <ExternalLink className="h-4 w-4 text-muted-foreground group-hover:text-accent" />
                  </div>
                  <h3 className="font-serif text-lg font-bold text-primary mb-2 group-hover:text-accent transition-colors">
                    {judgment.title}
                  </h3>
                  <p className="text-sm font-medium text-accent/80 mb-3">{judgment.subject}</p>
                  <p className="text-sm text-muted-foreground">{judgment.summary}</p>
                </a>
              </ScrollReveal>
            ))}
          </div>

          <div className="text-center mt-8">
            <Button asChild variant="outline" size="lg">
              <a href="https://www.sci.gov.in/landmark-judgment-summaries/" target="_blank" rel="noopener noreferrer">
                View All Landmark Judgments
                <ArrowRight className="ml-2 h-4 w-4" />
              </a>
            </Button>
          </div>
        </div>
      </section>

      {/* New Criminal Laws 2024 */}
      <section className="py-16 sm:py-24 bg-gradient-to-b from-background to-primary/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollReveal>
            <div className="text-center mb-12">
              <BookOpen className="h-12 w-12 text-accent mx-auto mb-4" />
              <h2 className="font-serif text-3xl md:text-4xl font-bold text-primary mb-4">New Criminal Laws 2024</h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Comprehensive guide to India's new criminal laws that replaced colonial-era codes from July 1, 2024
              </p>
            </div>
          </ScrollReveal>

          <div className="grid md:grid-cols-3 gap-6">
            {newCriminalLaws.map((law, index) => (
              <ScrollReveal key={index} delay={index * 100}>
                <div className="bg-card border border-border rounded-xl overflow-hidden hover:border-accent hover:shadow-xl transition-all duration-300">
                  <div className={`bg-gradient-to-br ${law.color} p-6 text-white`}>
                    <law.icon className="h-10 w-10 mb-3" />
                    <h3 className="font-serif text-xl font-bold mb-1">{law.title}</h3>
                    <p className="text-sm opacity-90">{law.subtitle}</p>
                  </div>
                  <div className="p-6">
                    <p className="text-sm text-muted-foreground mb-4 font-medium">{law.description}</p>
                    <div className="space-y-2">
                      {law.keyPoints.map((point, pIndex) => (
                        <div key={pIndex} className="flex items-start gap-2">
                          <CheckCircle className="h-4 w-4 text-accent flex-shrink-0 mt-0.5" />
                          <p className="text-sm text-foreground">{point}</p>
                        </div>
                      ))}
                    </div>
                    <Button asChild variant="outline" size="sm" className="w-full mt-6 bg-transparent">
                      <a href={law.url} target="_blank" rel="noopener noreferrer">
                        Learn More
                        <ExternalLink className="ml-2 h-3 w-3" />
                      </a>
                    </Button>
                  </div>
                </div>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* Criminal Law Guides */}
      <section className="py-16 sm:py-24 bg-secondary/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollReveal>
            <div className="text-center mb-12">
              <Shield className="h-12 w-12 text-accent mx-auto mb-4" />
              <h2 className="font-serif text-3xl md:text-4xl font-bold text-primary mb-4">Criminal Law Guides</h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Essential guides covering FIR, bail, investigation, and trial procedures
              </p>
            </div>
          </ScrollReveal>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {criminalLawGuides.map((guide, index) => (
              <ScrollReveal key={index} delay={index * 100}>
                <div className="bg-card border border-border rounded-xl overflow-hidden hover:border-accent hover:shadow-lg transition-all duration-300">
                  <div className={`bg-gradient-to-br ${guide.color} p-4 text-white flex items-center gap-3`}>
                    <guide.icon className="h-8 w-8" />
                    <h3 className="font-semibold text-lg">{guide.title}</h3>
                  </div>
                  <div className="p-4">
                    <ul className="space-y-2">
                      {guide.topics.map((topic, tIndex) => (
                        <li key={tIndex} className="flex items-start gap-2 text-sm">
                          <div className="h-1.5 w-1.5 rounded-full bg-accent mt-1.5 flex-shrink-0" />
                          <span className="text-foreground">{topic}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* Civil Law Guides */}
      <section className="py-16 sm:py-24 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollReveal>
            <div className="text-center mb-12">
              <Briefcase className="h-12 w-12 text-accent mx-auto mb-4" />
              <h2 className="font-serif text-3xl md:text-4xl font-bold text-primary mb-4">Civil Law Guides</h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Comprehensive guides on injunctions, recovery suits, limitation, and civil procedure
              </p>
            </div>
          </ScrollReveal>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {civilLawGuides.map((guide, index) => (
              <ScrollReveal key={index} delay={index * 100}>
                <div className="bg-card border border-border rounded-xl overflow-hidden hover:border-accent hover:shadow-lg transition-all duration-300">
                  <div className={`bg-gradient-to-br ${guide.color} p-4 text-white flex items-center gap-3`}>
                    <guide.icon className="h-8 w-8" />
                    <h3 className="font-semibold text-lg">{guide.title}</h3>
                  </div>
                  <div className="p-4">
                    <ul className="space-y-2">
                      {guide.topics.map((topic, tIndex) => (
                        <li key={tIndex} className="flex items-start gap-2 text-sm">
                          <div className="h-1.5 w-1.5 rounded-full bg-accent mt-1.5 flex-shrink-0" />
                          <span className="text-foreground">{topic}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* Legal Tools & Calculators */}
      <section className="py-16 sm:py-24 pb-24 bg-secondary/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollReveal>
            <div className="text-center mb-12">
              <Calculator className="h-12 w-12 text-accent mx-auto mb-4" />
              <h2 className="font-serif text-3xl md:text-4xl font-bold text-primary mb-4">Legal Calculators & Tools</h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Practical tools to calculate court fees, limitation periods, interest, and stamp duty
                (Rajasthan-specific)
              </p>
            </div>
          </ScrollReveal>

          <div className="w-full">
            <LegalCalculators />
          </div>
        </div>
      </section>

      {/* Detailed Legal Guides with Step-by-Step Processes */}
      <section className="py-16 sm:py-24 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollReveal>
            <div className="text-center mb-12">
              <FileText className="h-12 w-12 text-accent mx-auto mb-4" />
              <h2 className="font-serif text-3xl md:text-4xl font-bold text-primary mb-4">Detailed Legal Procedures</h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Step-by-step guides with complete processes, required documents, timelines, and fees
              </p>
            </div>
          </ScrollReveal>

          <div className="space-y-16">
            {legalGuides.map((category, catIndex) => (
              <ScrollReveal key={catIndex}>
                <div>
                  <div className="flex items-center gap-4 mb-8">
                    <div className={`p-4 bg-gradient-to-br ${category.color} rounded-xl shadow-lg`}>
                      <category.icon className="h-8 w-8 text-white" />
                    </div>
                    <div>
                      <h3 className="font-serif text-2xl md:text-3xl font-bold text-primary">{category.category}</h3>
                      <p className="text-muted-foreground">Detailed guides with complete procedures</p>
                    </div>
                  </div>

                  {category.guides.map((guide, guideIndex) => (
                    <ScrollReveal key={guideIndex} delay={guideIndex * 100}>
                      <div className="bg-card border border-border rounded-xl p-6 md:p-8 mb-6 hover:border-accent/30 transition-colors">
                        <h4 className="font-serif text-xl md:text-2xl font-semibold text-primary mb-3">
                          {guide.title}
                        </h4>
                        <p className="text-muted-foreground mb-6">{guide.description}</p>

                        {/* Step-by-Step Process */}
                        {guide.process && (
                          <div className="mb-6">
                            <h5 className="font-semibold text-primary mb-4 flex items-center gap-2">
                              <ArrowRight className="h-5 w-5 text-accent" />
                              Complete Procedure
                            </h5>
                            <div className="space-y-4">
                              {guide.process.map((step, stepIndex) => (
                                <div
                                  key={stepIndex}
                                  className="pl-4 border-l-2 border-accent/30 hover:border-accent transition-colors"
                                >
                                  <h6 className="font-semibold text-primary mb-1">{step.step}</h6>
                                  <p className="text-sm text-muted-foreground leading-relaxed">{step.details}</p>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* Required Documents */}
                        {guide.documents && (
                          <div className="mb-4">
                            <h5 className="font-semibold text-primary mb-3 flex items-center gap-2">
                              <FileCheck className="h-5 w-5 text-accent" />
                              Required Documents
                            </h5>
                            <div className="grid sm:grid-cols-2 gap-2">
                              {guide.documents.map((doc, docIndex) => (
                                <div key={docIndex} className="flex items-center gap-2 text-sm text-muted-foreground">
                                  <div className="h-1.5 w-1.5 rounded-full bg-accent flex-shrink-0" />
                                  {doc}
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* Timeline and Fees */}
                        <div className="grid sm:grid-cols-2 gap-4 pt-4 border-t border-border/50">
                          {guide.timeline && (
                            <div>
                              <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">
                                Expected Timeline
                              </p>
                              <p className="text-sm font-semibold text-primary">{guide.timeline}</p>
                            </div>
                          )}
                          {guide.fees && (
                            <div>
                              <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">
                                Approximate Fees
                              </p>
                              <p className="text-sm font-semibold text-primary">{guide.fees}</p>
                            </div>
                          )}
                        </div>

                        <Button asChild size="sm" className="mt-6 bg-accent hover:bg-accent/90 text-accent-foreground">
                          <Link href="/contact" className="flex items-center gap-2">
                            Get Expert Assistance
                            <ArrowRight className="h-4 w-4" />
                          </Link>
                        </Button>
                      </div>
                    </ScrollReveal>
                  ))}
                </div>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* Intellectual Property (IP) Protection Guide */}
      <section className="py-16 sm:py-24 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollReveal>
            <div className="text-center mb-12">
              <Copyright className="h-12 w-12 text-accent mx-auto mb-4" />
              <h2 className="font-serif text-3xl md:text-4xl font-bold text-primary mb-4">
                Intellectual Property (IP) Protection Guide
              </h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Complete procedures and expert guidance for patents, trademarks, copyrights, designs, and geographical
                indications
              </p>
            </div>
          </ScrollReveal>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {intellectualPropertyGuides.map((guide, idx) => (
              <ScrollReveal key={idx} delay={idx * 50}>
                <div className={`bg-gradient-to-br ${guide.color} rounded-xl p-6 text-white h-full flex flex-col`}>
                  <guide.icon className="h-8 w-8 mb-4" />
                  <h3 className="font-semibold text-lg mb-4">{guide.title}</h3>
                  <ul className="space-y-2 flex-grow text-sm">
                    {guide.topics.map((topic, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <CheckCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                        <span>{topic}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </ScrollReveal>
            ))}
          </div>

          {/* IP Registration Fees Table */}
          <div className="mt-12 grid md:grid-cols-2 gap-6">
            <ScrollReveal>
              <div className="bg-secondary/50 rounded-xl p-6 border border-border">
                <h3 className="font-semibold text-lg mb-4 text-primary">Government Registration Fees (2025)</h3>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span>Patent Filing</span>
                    <span className="font-semibold">₹1,600 - ₹8,000 ~</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Patent Examination</span>
                    <span className="font-semibold">₹4,000 - ₹20,000 ~</span>
                  </div>
                  <div className="flex justify-between border-t pt-3">
                    <span>Trademark (per class)</span>
                    <span className="font-semibold">₹4,500 - ₹9,000 ~</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Copyright Registration</span>
                    <span className="font-semibold">₹500 - ₹2,000 ~</span>
                  </div>
                  <div className="flex justify-between border-t pt-3">
                    <span>Design Registration</span>
                    <span className="font-semibold">₹1,000 - ₹4,000 ~</span>
                  </div>
                  <div className="flex justify-between">
                    <span>GI Registration</span>
                    <span className="font-semibold">₹1,000 - ₹12,000 ~</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-4">*Approx values, includes registration charges</p>
                </div>
              </div>
            </ScrollReveal>

            <ScrollReveal>
              <div className="bg-secondary/50 rounded-xl p-6 border border-border">
                <h3 className="font-semibold text-lg mb-4 text-primary">Advocate Professional Fees</h3>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span>Patent (Filing to Grant)</span>
                    <span className="font-semibold">₹30,000 - ₹75,000</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Patent Agent Search</span>
                    <span className="font-semibold">₹15,000 - ₹30,000</span>
                  </div>
                  <div className="flex justify-between border-t pt-3">
                    <span>Trademark (per class)</span>
                    <span className="font-semibold">₹10,000 - ₹25,000</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Trademark Renewal</span>
                    <span className="font-semibold">₹5,000 - ₹12,000</span>
                  </div>
                  <div className="flex justify-between border-t pt-3">
                    <span>Copyright Registration</span>
                    <span className="font-semibold">₹8,000 - ₹18,000</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Design Registration</span>
                    <span className="font-semibold">₹5,000 - ₹15,000</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-4">Note: Varies by complexity and experience</p>
                </div>
              </div>
            </ScrollReveal>
          </div>
        </div>
      </section>

      {/* NCLT & Appeals Guide */}
      <section className="py-16 sm:py-24 bg-secondary/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollReveal>
            <div className="text-center mb-12">
              <Gavel className="h-12 w-12 text-accent mx-auto mb-4" />
              <h2 className="font-serif text-3xl md:text-4xl font-bold text-primary mb-4">NCLT & Appeals Guide</h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                National Company Law Tribunal procedures, filing fees, and appellate remedies under Companies Act & IBC
              </p>
            </div>
          </ScrollReveal>

          <div className="grid md:grid-cols-2 gap-6 mb-12">
            {ncltAppealGuides.map((guide, idx) => (
              <ScrollReveal key={idx} delay={idx * 50}>
                <div className={`bg-gradient-to-br ${guide.color} rounded-xl p-6 text-white h-full flex flex-col`}>
                  <guide.icon className="h-8 w-8 mb-4" />
                  <h3 className="font-semibold text-lg mb-4">{guide.title}</h3>
                  <ul className="space-y-2 flex-grow text-sm">
                    {guide.topics.map((topic, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <CheckCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                        <span>{topic}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </ScrollReveal>
            ))}
          </div>

          {/* NCLT Fees & Appeals Fees */}
          <div className="grid md:grid-cols-2 gap-6">
            <ScrollReveal>
              <div className="bg-white rounded-xl p-6 border border-border">
                <h3 className="font-semibold text-lg mb-4 text-primary">NCLT Filing Fees</h3>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span>Oppression & Mismanagement</span>
                    <span className="font-semibold">₹5,000 ~</span>
                  </div>
                  <div className="flex justify-between">
                    <span>M&A, Mergers, Amalgamations</span>
                    <span className="font-semibold">₹5,000 ~</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Company Revival/Restoration</span>
                    <span className="font-semibold">₹1,000 ~</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Registered Office Change</span>
                    <span className="font-semibold">₹5,000 ~</span>
                  </div>
                  <div className="flex justify-between border-t pt-3">
                    <span>CIRP - Financial Creditor (IBC)</span>
                    <span className="font-semibold">₹25,000 ~</span>
                  </div>
                  <div className="flex justify-between">
                    <span>CIRP - Operational Creditor (IBC)</span>
                    <span className="font-semibold">₹2,000 ~</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Voluntary Liquidation</span>
                    <span className="font-semibold">₹2,000 ~</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-4">*Approx tribunal filing fees only</p>
                </div>
              </div>
            </ScrollReveal>

            <ScrollReveal>
              <div className="bg-white rounded-xl p-6 border border-border">
                <h3 className="font-semibold text-lg mb-4 text-primary">NCLAT Appeal Advocate Fees</h3>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span>Appeal Preparation & Filing</span>
                    <span className="font-semibold">₹25,000 - ₹50,000</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Stay Application</span>
                    <span className="font-semibold">₹15,000 - ₹30,000</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Appeal Hearing (per hearing)</span>
                    <span className="font-semibold">₹10,000 - ₹25,000</span>
                  </div>
                  <div className="flex justify-between border-t pt-3">
                    <span>Complete Appeal Conduct</span>
                    <span className="font-semibold">₹50,000 - ₹1,50,000</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Complex Corporate Cases</span>
                    <span className="font-semibold">₹1,00,000 - ₹3,00,000+</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-4">
                    Note: Depends on case complexity and counsel seniority
                  </p>
                </div>
              </div>
            </ScrollReveal>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 sm:py-24 bg-gradient-to-b from-primary to-primary/90 text-primary-foreground">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <ScrollReveal>
            <Scale className="h-12 w-12 text-accent mx-auto mb-6" />
            <h2 className="font-serif text-3xl md:text-4xl font-bold mb-6">Need Personalized Legal Guidance?</h2>
            <p className="text-lg text-primary-foreground/90 mb-8 max-w-2xl mx-auto leading-relaxed">
              While our comprehensive guides provide detailed procedures, every legal situation is unique. Our
              experienced advocates provide personalized advice tailored to your specific circumstances.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground px-8">
                <Link href="/contact" className="flex items-center gap-2">
                  Schedule Free Consultation
                  <ArrowRight className="h-5 w-5" />
                </Link>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="px-8 border-primary-foreground/20 text-primary-foreground hover:bg-primary-foreground/10 bg-transparent"
              >
                <Link href="/practice-areas">View All Practice Areas</Link>
              </Button>
            </div>
          </ScrollReveal>
        </div>
      </section>

      <Footer />
    </div>
  )
}

export const metadata = {
  title: "Legal Guide & Resources - Complete Procedures, Tools & Court Links | LawUp Consulting",
  description:
    "Comprehensive legal guides with step-by-step procedures, Supreme Court & High Court cause lists, case status links, legal calculators, and daily resources for advocates and individuals.",
}
