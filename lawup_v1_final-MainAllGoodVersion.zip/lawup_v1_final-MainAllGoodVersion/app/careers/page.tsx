import type { Metadata } from "next"
import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { MapPin, Clock, Users, Briefcase, TrendingUp, Mail, Phone } from "lucide-react"
import Link from "next/link"

export const metadata: Metadata = {
  title: "Careers - LawUp Consulting | Join Our Legal Team",
  description:
    "Join LawUp Consulting and build your legal career. Current openings for advocates, legal associates, and support staff in Jaipur, Rajasthan.",
  keywords: [
    "legal jobs",
    "law firm careers",
    "advocate jobs",
    "legal associate",
    "lawyer jobs",
    "legal careers",
    "law firm jobs Jaipur",
    "legal employment",
    "advocate recruitment",
  ],
  openGraph: {
    title: "Careers - LawUp Consulting",
    description: "Join our growing legal team and advance your career in a dynamic law firm environment.",
  },
  alternates: {
    canonical: "https://lawup.in/careers",
  },
}

const jobOpenings = [
  {
    id: 1,
    title: "Senior Associate - Corporate Law",
    department: "Corporate Practice",
    location: "Jaipur, Rajasthan",
    type: "Full-time",
    experience: "3-5 years",
    salary: "₹8-12 LPA",
    requirements: [
      "LLB/LLM from recognized university",
      "3-5 years experience in corporate law",
      "Strong drafting and negotiation skills",
      "Experience with M&A, compliance, and corporate governance",
    ],
    responsibilities: [
      "Handle corporate transactions and compliance matters",
      "Draft and review commercial agreements",
      "Advise clients on corporate governance issues",
      "Manage junior associates and coordinate with clients",
    ],
    skills: ["Corporate Law", "Contract Drafting", "M&A", "Compliance", "Client Management"],
  },
  {
    id: 2,
    title: "Litigation Associate",
    department: "Litigation Practice",
    location: "Jaipur, Rajasthan",
    type: "Full-time",
    experience: "2-4 years",
    salary: "₹6-10 LPA",
    requirements: [
      "LLB with good academic record",
      "2-4 years litigation experience",
      "Strong court advocacy skills",
      "Knowledge of civil and commercial litigation",
    ],
    responsibilities: [
      "Represent clients in various courts and tribunals",
      "Prepare legal briefs and court documents",
      "Conduct legal research and case analysis",
      "Assist senior advocates in complex matters",
    ],
    skills: ["Litigation", "Court Advocacy", "Legal Research", "Case Management", "Legal Writing"],
  },
  {
    id: 3,
    title: "Legal Manager - Real Estate",
    department: "Real Estate Practice",
    location: "Jaipur, Rajasthan",
    type: "Full-time",
    experience: "4-6 years",
    salary: "₹10-15 LPA",
    requirements: [
      "LLB/LLM with specialization in property law",
      "4-6 years experience in real estate law",
      "Knowledge of RERA and property regulations",
      "Strong project management skills",
    ],
    responsibilities: [
      "Lead real estate transactions and due diligence",
      "Handle RERA compliance and approvals",
      "Manage property disputes and litigation",
      "Coordinate with developers, buyers, and regulatory authorities",
    ],
    skills: ["Real Estate Law", "RERA Compliance", "Due Diligence", "Project Management", "Regulatory Affairs"],
  },
  {
    id: 4,
    title: "Junior Associate - General Practice",
    department: "General Practice",
    location: "Jaipur, Rajasthan",
    type: "Full-time",
    experience: "0-2 years",
    salary: "₹4-6 LPA",
    requirements: [
      "Fresh LLB graduate or up to 2 years experience",
      "Strong academic background",
      "Good research and writing skills",
      "Eagerness to learn and grow",
    ],
    responsibilities: [
      "Assist senior advocates in various practice areas",
      "Conduct legal research and prepare memorandums",
      "Draft basic legal documents and correspondence",
      "Support case preparation and client coordination",
    ],
    skills: ["Legal Research", "Legal Writing", "Case Preparation", "Client Support", "Documentation"],
  },
  {
    id: 5,
    title: "Legal Operations Manager",
    department: "Operations",
    location: "Jaipur, Rajasthan",
    type: "Full-time",
    experience: "3-5 years",
    salary: "₹7-11 LPA",
    requirements: [
      "LLB/MBA with legal background",
      "3-5 years experience in legal operations",
      "Strong organizational and leadership skills",
      "Knowledge of legal technology and processes",
    ],
    responsibilities: [
      "Manage firm operations and administrative functions",
      "Implement legal technology solutions",
      "Coordinate between different practice groups",
      "Ensure compliance with firm policies and procedures",
    ],
    skills: ["Operations Management", "Legal Technology", "Process Improvement", "Team Leadership", "Compliance"],
  },
  {
    id: 6,
    title: "Legal Internship",
    department: "Internship Program",
    location: "Jaipur, Rajasthan",
    type: "Full-time / Part-time",
    experience: "Fresher",
    salary: "Stipend: ₹5,000-15,000/month",
    requirements: [
      "Currently pursuing or recently completed LLB",
      "Strong interest in legal practice areas",
      "Good communication and writing skills",
      "Willingness to learn and contribute",
    ],
    responsibilities: [
      "Research on current legal matters",
      "Assist in document preparation and drafting",
      "Support advocates in case management",
      "Attend court hearings and client meetings",
    ],
    skills: ["Legal Research", "Legal Writing", "Communication", "Attention to Detail", "Time Management"],
  },
  {
    id: 7,
    title: "Paralegal - Litigation",
    department: "Litigation Support",
    location: "Jaipur, Rajasthan",
    type: "Full-time",
    experience: "0-2 years",
    salary: "₹3-5 LPA",
    requirements: [
      "Diploma in Paralegal Studies or LLB student",
      "Knowledge of legal documentation and procedures",
      "Proficient in MS Office and legal software",
      "Strong organizational skills",
    ],
    responsibilities: [
      "Maintain case files and legal documents",
      "Prepare court pleadings and documents",
      "Coordinate with courts and parties",
      "Manage witness and evidence documentation",
    ],
    skills: ["Documentation", "Case Management", "Legal Software", "Organization", "Communication"],
  },
  {
    id: 8,
    title: "Paralegal - Corporate",
    department: "Corporate Support",
    location: "Jaipur, Rajasthan",
    type: "Full-time",
    experience: "0-2 years",
    salary: "₹3-5 LPA",
    requirements: [
      "Diploma in Paralegal Studies or LLB student",
      "Understanding of corporate procedures",
      "Attention to compliance and detail",
      "Data entry and documentation skills",
    ],
    responsibilities: [
      "Prepare corporate compliance documents",
      "Maintain corporate records and filings",
      "Assist in contract management",
      "Track regulatory requirements and deadlines",
    ],
    skills: ["Compliance", "Documentation", "Corporate Procedures", "Data Management", "Attention to Detail"],
  },
  {
    id: 9,
    title: "Legal Assistant",
    department: "General Administration",
    location: "Jaipur, Rajasthan",
    type: "Full-time",
    experience: "Fresher",
    salary: "₹2.5-4 LPA",
    requirements: [
      "12th Pass or Bachelor's Degree",
      "Interest in legal field",
      "Good computer and communication skills",
      "Willing to support legal processes",
    ],
    responsibilities: [
      "Assist in general office administration",
      "Support document management",
      "Handle client inquiries and scheduling",
      "Maintain legal records and archives",
    ],
    skills: ["Administration", "Communication", "Data Entry", "Organization", "Customer Service"],
  },
  {
    id: 10,
    title: "Intern - Research & Writing",
    department: "Research Team",
    location: "Jaipur, Rajasthan",
    type: "Full-time / Part-time",
    experience: "Fresher",
    salary: "Stipend: ₹5,000-12,000/month",
    requirements: [
      "Pursuing or completed LLB",
      "Strong research and writing abilities",
      "Interest in legal analysis",
      "Proficiency in Indian legal system",
    ],
    responsibilities: [
      "Conduct legal research on specified topics",
      "Prepare research memorandums and briefs",
      "Update legal databases and libraries",
      "Assist in legal publications",
    ],
    skills: ["Legal Research", "Writing", "Analysis", "Documentation", "Time Management"],
  },
  {
    id: 11,
    title: "Paralegal - Family Law",
    department: "Family Law Support",
    location: "Jaipur, Rajasthan",
    type: "Full-time",
    experience: "0-2 years",
    salary: "₹3-5 LPA",
    requirements: [
      "Diploma in Paralegal Studies or LLB student",
      "Sensitivity to family law matters",
      "Understanding of domestic procedures",
      "Good written and verbal communication",
    ],
    responsibilities: [
      "Assist in family law case documentation",
      "Coordinate with family law courts",
      "Maintain confidential client records",
      "Support advocates in family disputes",
    ],
    skills: ["Confidentiality", "Documentation", "Communication", "Empathy", "Case Management"],
  },
  {
    id: 12,
    title: "Intern - Compliance",
    department: "Compliance Team",
    location: "Jaipur, Rajasthan",
    type: "Full-time / Part-time",
    experience: "Fresher",
    salary: "Stipend: ₹7,000-15,000/month",
    requirements: [
      "Pursuing or completed LLB/Commerce",
      "Understanding of regulatory compliance",
      "Attention to detail",
      "Interest in corporate law",
    ],
    responsibilities: [
      "Monitor compliance requirements",
      "Prepare compliance reports",
      "Track regulatory changes",
      "Assist in audit preparations",
    ],
    skills: ["Compliance", "Research", "Analysis", "Documentation", "Attention to Detail"],
  },
]

export default function CareersPage() {
  return (
    <div className="min-h-screen">
      <Navigation />

      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-primary/5 to-accent/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="font-playfair text-4xl lg:text-5xl font-bold text-primary mb-6">Join Our Team</h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
              Build your legal career with LawUp Consulting. We offer exciting opportunities for growth, professional
              development, and meaningful work in a collaborative environment.
            </p>
          </div>
        </div>
      </section>

      {/* Why Work With Us */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="font-playfair text-3xl font-bold text-primary mb-4">Why Choose LawUp?</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Discover what makes LawUp Consulting an exceptional place to build your legal career.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="text-center">
              <CardContent className="p-6">
                <TrendingUp className="h-12 w-12 text-accent mx-auto mb-4" />
                <h3 className="font-semibold mb-2">Career Growth</h3>
                <p className="text-sm text-muted-foreground">
                  Clear advancement paths and opportunities for professional development.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="p-6">
                <Users className="h-12 w-12 text-accent mx-auto mb-4" />
                <h3 className="font-semibold mb-2">Collaborative Culture</h3>
                <p className="text-sm text-muted-foreground">
                  Work with experienced professionals in a supportive team environment.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="p-6">
                <Briefcase className="h-12 w-12 text-accent mx-auto mb-4" />
                <h3 className="font-semibold mb-2">Diverse Practice</h3>
                <p className="text-sm text-muted-foreground">
                  Gain experience across multiple practice areas and legal domains.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="p-6">
                <Clock className="h-12 w-12 text-accent mx-auto mb-4" />
                <h3 className="font-semibold mb-2">Work-Life Balance</h3>
                <p className="text-sm text-muted-foreground">
                  Maintain a healthy balance between professional and personal life.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Current Openings */}
      <section className="py-16 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="font-playfair text-3xl font-bold text-primary mb-4">Current Openings</h2>
            <p className="text-muted-foreground">
              Explore our available positions and find the perfect opportunity to advance your legal career.
            </p>
          </div>

          <div className="space-y-6">
            {jobOpenings.map((job) => (
              <Card key={job.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex justify-between items-start flex-col sm:flex-row gap-4">
                    <div className="flex-1">
                      <CardTitle className="text-xl mb-2">{job.title}</CardTitle>
                      <div className="flex flex-wrap gap-2 mb-3">
                        <Badge variant="secondary">{job.department}</Badge>
                        <Badge variant="outline">{job.type}</Badge>
                        <Badge variant="outline">{job.experience} experience</Badge>
                      </div>
                    </div>
                  </div>
                </CardHeader>

                <CardContent>
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <div className="lg:col-span-2 space-y-4">
                      <div className="flex flex-col sm:flex-row sm:items-center gap-4 text-sm text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <MapPin className="h-4 w-4" />
                          {job.location}
                        </div>
                        <div className="font-medium text-green-600">{job.salary}</div>
                      </div>

                      <div>
                        <h4 className="font-semibold mb-2">Requirements:</h4>
                        <ul className="text-sm text-muted-foreground space-y-1">
                          {job.requirements.map((req, index) => (
                            <li key={index} className="flex items-start gap-2">
                              <span className="text-accent mt-1">•</span>
                              {req}
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div>
                        <h4 className="font-semibold mb-2">Key Responsibilities:</h4>
                        <ul className="text-sm text-muted-foreground space-y-1">
                          {job.responsibilities.map((resp, index) => (
                            <li key={index} className="flex items-start gap-2">
                              <span className="text-accent mt-1">•</span>
                              {resp}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <h4 className="font-semibold mb-2">Key Skills:</h4>
                        <div className="flex flex-wrap gap-2">
                          {job.skills.map((skill, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {skill}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      <Button asChild className="w-full">
                        <Link href="/contact?type=career" className="flex items-center justify-center">
                          <Mail className="mr-2 h-4 w-4" />
                          Apply Now
                        </Link>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Application Process */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="font-playfair text-3xl font-bold text-primary mb-4">How to Apply</h2>
            <p className="text-muted-foreground">
              Follow these steps to submit your application and join our legal team.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-12 h-12 bg-primary text-white rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                1
              </div>
              <h3 className="font-semibold mb-2">Submit Application</h3>
              <p className="text-sm text-muted-foreground">
                Send your resume, cover letter, and relevant documents to our HR team.
              </p>
            </div>

            <div className="text-center">
              <div className="w-12 h-12 bg-primary text-white rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                2
              </div>
              <h3 className="font-semibold mb-2">Interview Process</h3>
              <p className="text-sm text-muted-foreground">
                Participate in multiple rounds of interviews with our legal team and partners.
              </p>
            </div>

            <div className="text-center">
              <div className="w-12 h-12 bg-primary text-white rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                3
              </div>
              <h3 className="font-semibold mb-2">Join Our Team</h3>
              <p className="text-sm text-muted-foreground">
                Complete the onboarding process and start your journey with LawUp.
              </p>
            </div>
          </div>

          <div className="mt-12">
            <Card className="max-w-2xl mx-auto">
              <CardContent className="p-6 text-center">
                <h3 className="font-semibold mb-4">Ready to Apply?</h3>
                <p className="text-muted-foreground mb-6">
                  Contact our HR team to discuss career opportunities and submit your application.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button size="lg">
                    <Mail className="mr-2 h-4 w-4" />
                    support@lawup.in
                  </Button>
                  <Button size="lg" variant="outline">
                    <Phone className="mr-2 h-4 w-4" />
                    +91-9716968000
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
