import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { PageHero } from "@/components/page-hero"
import { ScrollReveal } from "@/components/scroll-reveal"
import { AnimatedCounter } from "@/components/animated-counter"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Image from "next/image"
import Link from "next/link"
import { Scale, Eye, Heart, Users, Award, Globe, ArrowRight, Target, Shield, Lightbulb } from "lucide-react"

export default function AboutPage() {
  return (
    <div className="min-h-screen">
      <Navigation />

      <PageHero
        badge="About LawUp"
        title="Justice in Clear Sight"
        subtitle="Incorporated in 2020, LawUp Consulting represents the evolving face of legal practice in India. With partners contributing over five years of continuous experience and having served more than 5,000+ clients across Indian courts and tribunals."
        size="large"
      />

      {/* Stats Bar */}
      <section className="py-12 bg-background border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { value: 5000, suffix: "+", label: "Matters Handled" },
              { value: 5, suffix: "+", label: "Years Excellence" },
              { value: 15, suffix: "+", label: "Legal Experts" },
              { value: 100, suffix: "%", label: "Client Focused" },
            ].map((stat, index) => (
              <ScrollReveal key={index} delay={index * 100} className="text-center">
                <div className="text-3xl md:text-4xl font-serif font-bold text-accent mb-2">
                  <AnimatedCounter end={stat.value} suffix={stat.suffix} />
                </div>
                <div className="text-sm text-muted-foreground uppercase tracking-wider">{stat.label}</div>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-24 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <ScrollReveal direction="left">
              <div className="relative">
                <div className="aspect-[4/5] rounded-2xl overflow-hidden">
                  <Image
                    src="/modern-law-office.png"
                    alt="LawUp Consulting office interior"
                    fill
                    className="object-cover"
                  />
                </div>
                {/* Floating accent */}
                <div className="absolute -bottom-6 -right-6 bg-accent p-6 rounded-xl shadow-2xl">
                  <div className="text-3xl font-serif font-bold text-accent-foreground mb-1">Est.</div>
                  <div className="text-4xl font-serif font-bold text-accent-foreground">2020</div>
                </div>
              </div>
            </ScrollReveal>

            <div>
              <ScrollReveal>
                <span className="inline-flex items-center gap-2 text-accent text-sm font-medium tracking-widest uppercase mb-4">
                  <span className="w-8 h-px bg-accent" />
                  Our Story
                </span>
              </ScrollReveal>

              <ScrollReveal delay={100}>
                <h2 className="font-serif text-3xl md:text-4xl font-bold text-primary mb-6">
                  Building Legal Excellence Through Integrity
                </h2>
              </ScrollReveal>

              <ScrollReveal delay={200}>
                <p className="text-muted-foreground mb-6 leading-relaxed">
                  LawUp was founded on the principle that justice should be transparent, accessible, and effective. Our
                  name reflects our commitment to elevating legal standards and our tagline,{" "}
                  <span className="text-accent font-medium">"Law Simplified, Justice Amplified,"</span> symbolizes our
                  belief in demystifying complex legal challenges.
                </p>
              </ScrollReveal>

              <ScrollReveal delay={300}>
                <p className="text-muted-foreground mb-6 leading-relaxed">
                  We have built our practice on the foundation of ethical conduct, professional excellence, and
                  unwavering commitment to our clients' success. Our team combines deep legal expertise with innovative
                  approaches to deliver comprehensive solutions across all major practice areas.
                </p>
              </ScrollReveal>

              <ScrollReveal delay={400}>
                <p className="text-muted-foreground mb-8 leading-relaxed">
                  From our headquarters, we serve clients across India, representing them in various courts and
                  tribunals while maintaining the highest standards of professional conduct as prescribed by the Bar
                  Council of India.
                </p>
              </ScrollReveal>

              <ScrollReveal delay={500}>
                <Button asChild className="bg-primary hover:bg-primary/90 text-primary-foreground">
                  <Link href="/team" className="flex items-center gap-2">
                    Meet Our Team
                    <ArrowRight className="h-4 w-4" />
                  </Link>
                </Button>
              </ScrollReveal>
            </div>
          </div>
        </div>
      </section>

      {/* Core Values */}
      <section className="py-24 bg-secondary/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollReveal className="text-center mb-16">
            <span className="inline-flex items-center gap-2 text-accent text-sm font-medium tracking-widest uppercase mb-4">
              <span className="w-8 h-px bg-accent" />
              Our Principles
              <span className="w-8 h-px bg-accent" />
            </span>
            <h2 className="font-serif text-3xl md:text-4xl font-bold text-primary mb-4">Core Values</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              The principles that guide every aspect of our legal practice and client relationships.
            </p>
          </ScrollReveal>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: Eye,
                title: "Transparency",
                description:
                  "Clear communication, honest assessments, and transparent processes in all our client interactions.",
              },
              {
                icon: Scale,
                title: "Integrity",
                description:
                  "Unwavering commitment to ethical practice and professional conduct in accordance with BCI guidelines.",
              },
              {
                icon: Award,
                title: "Excellence",
                description:
                  "Delivering superior legal solutions through continuous learning and innovative approaches.",
              },
              {
                icon: Target,
                title: "Client Focus",
                description: "Putting client interests at the forefront of every decision and strategy we develop.",
              },
              {
                icon: Shield,
                title: "Confidentiality",
                description: "Maintaining absolute discretion and protecting sensitive information with utmost care.",
              },
              {
                icon: Lightbulb,
                title: "Innovation",
                description: "Embracing modern legal technology and creative solutions to complex challenges.",
              },
            ].map((value, index) => (
              <ScrollReveal key={index} delay={index * 100}>
                <Card className="h-full border-0 shadow-lg hover-lift bg-background">
                  <CardContent className="p-8 text-center">
                    <div className="inline-flex items-center justify-center w-14 h-14 bg-accent/10 rounded-xl mb-6">
                      <value.icon className="h-7 w-7 text-accent" />
                    </div>
                    <h3 className="font-serif text-xl font-semibold text-primary mb-3">{value.title}</h3>
                    <p className="text-muted-foreground leading-relaxed">{value.description}</p>
                  </CardContent>
                </Card>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* Leadership */}
      <section className="py-24 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollReveal className="text-center mb-16">
            <span className="inline-flex items-center gap-2 text-accent text-sm font-medium tracking-widest uppercase mb-4">
              <span className="w-8 h-px bg-accent" />
              Leadership
              <span className="w-8 h-px bg-accent" />
            </span>
            <h2 className="font-serif text-3xl md:text-4xl font-bold text-primary mb-4">Founding Partners</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Meet the visionaries who bring decades of combined legal expertise and leadership to LawUp Consulting.
            </p>
          </ScrollReveal>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {[
              {
                name: "Advocate Ravi K Sharma",
                role: "Founding Partner",
                image: "/indian-male-lawyer-portrait.png",
                bio: "Expert and Best Legal Advisor with 5+ years of experience of many cases. Practicing at all Courts and Tribunals in India and nearby areas. Advocate Ravi Kumar Sharma stands top with specializes in high-stakes Criminal Defense and Specialized Practice areas: Criminal: NDPS Act, POCSO, Bail Applications, & Quashing Petitions. Family : Mutual & Contested Divorce, Child Custody, Maintenance (125 CrPC), DV Act & matrimonial matter Cybercrime: UPI Fraud, Banking Scams, & Digital Crimes. White-Collar Crime: Handling PMLA, GST, SEBI, & Corp. Frauds. Expertise in Discharge Applications, Section 138 NI Act (Cheque Bounce), & Private Complaints. Serving Individuals, MSMEs, & Startups. Trusted for result-oriented litigation and quick turnaround.",
                credentials: ["LLB,MBA Rajasthan University", "5+ Years PQE"],
              },
              {
                name: "Advocate Priya Sharma",
                role: "Partner",
                image: "/indian-female-lawyer-portrait.png",
                bio: "Priya brings 6 years of specialized experience in banking & finance, real estate, and RERA matters. She holds an LLM in Corporate Law and has been instrumental in structuring complex financial transactions for corporate clients.",
                credentials: ["LLM, Corporate Law", "6+ Years PQE"],
              },
            ].map((leader, index) => (
              <ScrollReveal key={index} delay={index * 150}>
                <Card className="overflow-hidden border-0 shadow-xl hover-lift">
                  <CardContent className="p-0">
                    <div className="relative h-80 sm:h-96 md:h-full md:aspect-[3/4]">
                      <Image src={leader.image || "/placeholder.svg"} alt={leader.name} fill className="object-cover object-top" />
                      <div className="absolute inset-0 bg-gradient-to-t from-primary/90 via-primary/20 to-transparent" />
                      <div className="absolute bottom-6 left-6 right-6 text-primary-foreground">
                        <h3 className="font-serif text-2xl font-bold mb-1">{leader.name}</h3>
                        <p className="text-accent font-medium">{leader.role}</p>
                      </div>
                    </div>
                    <div className="p-6">
                      <p className="text-muted-foreground leading-relaxed mb-4">{leader.bio}</p>
                      <div className="flex flex-wrap gap-2">
                        {leader.credentials.map((cred, i) => (
                          <span
                            key={i}
                            className="inline-flex items-center px-3 py-1 bg-secondary text-secondary-foreground text-xs font-medium rounded-full"
                          >
                            {cred}
                          </span>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* Commitment Section */}
      <section className="py-24 bg-primary text-primary-foreground">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <ScrollReveal>
              <span className="inline-flex items-center gap-2 text-accent text-sm font-medium tracking-widest uppercase mb-4">
                <span className="w-8 h-px bg-accent" />
                Our Commitment
              </span>
              <h2 className="font-serif text-3xl md:text-4xl font-bold mb-6">Ethical Practice Above All</h2>
              <p className="text-primary-foreground/80 leading-relaxed mb-8">
                We are committed to maintaining the highest standards of professional conduct, transparency, and ethical
                practice as mandated by the Bar Council of India. Our approach ensures that every client receives
                honest, competent, and diligent representation while upholding the dignity of the legal profession.
              </p>
              <Button asChild className="bg-accent hover:bg-accent/90 text-accent-foreground">
                <Link href="/contact" className="flex items-center gap-2">
                  Contact Us
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
            </ScrollReveal>

            <ScrollReveal direction="right">
              <div className="grid grid-cols-3 gap-6">
                {[
                  { icon: Users, title: "Client-Centric", desc: "Your interests first" },
                  { icon: Heart, title: "Compassionate", desc: "Empathetic approach" },
                  { icon: Globe, title: "Accessible", desc: "Pan-India presence" },
                ].map((item, index) => (
                  <div key={index} className="text-center">
                    <div className="inline-flex items-center justify-center w-14 h-14 bg-primary-foreground/10 rounded-xl mb-4">
                      <item.icon className="h-7 w-7 text-accent" />
                    </div>
                    <h3 className="font-medium mb-1">{item.title}</h3>
                    <p className="text-sm text-primary-foreground/60">{item.desc}</p>
                  </div>
                ))}
              </div>
            </ScrollReveal>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
