"use client"

import { useState, useMemo } from "react"
import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { PageHero } from "@/components/page-hero"
import { ScrollReveal } from "@/components/scroll-reveal"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import Image from "next/image"
import Link from "next/link"
import { Mail, MapPin, Award, Search, X, ArrowRight } from "lucide-react"
import counselData from "@/data/counsel.json"

export default function TeamPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [cityFilter, setCityFilter] = useState("all")
  const [specializationFilter, setSpecializationFilter] = useState("all")
  const [pqeFilter, setPqeFilter] = useState("all")

  const cities = useMemo(() => {
    const allCities = counselData.map((counsel) => counsel.city)
    return [...new Set(allCities)]
  }, [])

  const specializations = useMemo(() => {
    const allSpecializations = counselData.flatMap((counsel) => counsel.specialization)
    return [...new Set(allSpecializations)]
  }, [])

  const filteredTeam = useMemo(() => {
    const filtered = counselData.filter((counsel) => {
      const matchesSearch =
        counsel.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        counsel.specialization.some((spec) => spec.toLowerCase().includes(searchTerm.toLowerCase()))

      const matchesCity = cityFilter === "all" || counsel.city === cityFilter
      const matchesSpecialization =
        specializationFilter === "all" || counsel.specialization.includes(specializationFilter)
      const matchesPqe =
        pqeFilter === "all" ||
        (pqeFilter === "junior" && counsel.pqe <= 3) ||
        (pqeFilter === "senior" && counsel.pqe > 3 && counsel.pqe <= 7) ||
        (pqeFilter === "partner" && counsel.pqe > 7)

      return matchesSearch && matchesCity && matchesSpecialization && matchesPqe
    })

    return filtered.sort((a, b) => {
      const aIsPartner = a.designation.toLowerCase().includes("partner")
      const bIsPartner = b.designation.toLowerCase().includes("partner")
      if (aIsPartner && !bIsPartner) return -1
      if (!aIsPartner && bIsPartner) return 1
      return b.pqe - a.pqe
    })
  }, [searchTerm, cityFilter, specializationFilter, pqeFilter])

  const clearFilters = () => {
    setSearchTerm("")
    setCityFilter("all")
    setSpecializationFilter("all")
    setPqeFilter("all")
  }

  const hasActiveFilters = searchTerm || cityFilter !== "all" || specializationFilter !== "all" || pqeFilter !== "all"

  return (
    <div className="min-h-screen">
      <Navigation />

      <PageHero
        badge="Our People"
        title="Legal Team"
        subtitle="Meet our experienced legal professionals who bring diverse expertise and unwavering commitment to delivering exceptional legal services across India."
        size="large"
      />

      {/* Filters - Better mobile layout with horizontal scroll */}
      <section className="py-4 sm:py-8 bg-secondary/30 border-b border-border sticky top-14 sm:top-16 z-30 backdrop-blur-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col gap-3 sm:gap-4">
            {/* Search - Full width on mobile */}
            <div className="relative w-full lg:max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by name or expertise..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-background"
              />
            </div>

            {/* Filters row - Horizontal scroll on mobile */}
            <div className="flex items-center gap-2 sm:gap-3 overflow-x-auto pb-2 sm:pb-0 -mx-4 px-4 sm:mx-0 sm:px-0 scrollbar-hide">
              <Select value={cityFilter} onValueChange={setCityFilter}>
                <SelectTrigger className="w-[120px] sm:w-[140px] bg-background flex-shrink-0">
                  <SelectValue placeholder="City" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Cities</SelectItem>
                  {cities.map((city) => (
                    <SelectItem key={city} value={city}>
                      {city}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={specializationFilter} onValueChange={setSpecializationFilter}>
                <SelectTrigger className="w-[140px] sm:w-[160px] bg-background flex-shrink-0">
                  <SelectValue placeholder="Specialization" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Specializations</SelectItem>
                  {specializations.map((spec) => (
                    <SelectItem key={spec} value={spec}>
                      {spec}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={pqeFilter} onValueChange={setPqeFilter}>
                <SelectTrigger className="w-[120px] sm:w-[140px] bg-background flex-shrink-0">
                  <SelectValue placeholder="Experience" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Levels</SelectItem>
                  <SelectItem value="junior">Junior (0-3 yrs)</SelectItem>
                  <SelectItem value="senior">Senior (4-7 yrs)</SelectItem>
                  <SelectItem value="partner">Partner (8+ yrs)</SelectItem>
                </SelectContent>
              </Select>

              {hasActiveFilters && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={clearFilters}
                  className="text-muted-foreground flex-shrink-0"
                >
                  <X className="h-4 w-4 mr-1" />
                  Clear
                </Button>
              )}

              <div className="text-xs sm:text-sm text-muted-foreground whitespace-nowrap flex-shrink-0 ml-auto">
                {filteredTeam.length}/{counselData.length}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Team Grid - Better responsive grid */}
      <section className="py-10 sm:py-16 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {filteredTeam.length === 0 ? (
            <div className="text-center py-16 sm:py-20">
              <p className="text-lg sm:text-xl text-muted-foreground mb-4">
                No team members found matching your criteria.
              </p>
              <Button onClick={clearFilters}>Clear All Filters</Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
              {filteredTeam.map((counsel, index) => (
                <ScrollReveal key={counsel.id} delay={Math.min(index * 50, 300)}>
                  <Card className="group h-full border-0 shadow-lg hover-lift overflow-hidden">
                    <CardContent className="p-0">
                      {/* Image Section */}
                      

                      {/* Content */}
                      <div className="p-4 sm:p-6">
                        <h3 className="font-serif text-lg sm:text-xl font-semibold text-primary mb-1">
                          {counsel.name}
                        </h3>
                        <p className="text-accent font-medium text-xs sm:text-sm mb-3 sm:mb-4">{counsel.designation}</p>

                        <div className="flex items-center gap-3 sm:gap-4 text-xs sm:text-sm text-muted-foreground mb-3 sm:mb-4">
                          <div className="flex items-center gap-1">
                            <MapPin className="h-3 w-3 sm:h-3.5 sm:w-3.5" />
                            {counsel.city}
                          </div>
                          <div className="flex items-center gap-1">
                            <Award className="h-3 w-3 sm:h-3.5 sm:w-3.5" />
                            {counsel.pqe} Yrs
                          </div>
                        </div>

                        <div className="flex flex-wrap gap-1 sm:gap-1.5 mb-3 sm:mb-4">
                          {counsel.specialization.slice(0, 2).map((spec, i) => (
                            <Badge key={i} variant="secondary" className="text-[10px] sm:text-xs font-normal">
                              {spec}
                            </Badge>
                          ))}
                          {counsel.specialization.length > 2 && (
                            <Badge variant="secondary" className="text-[10px] sm:text-xs font-normal">
                              +{counsel.specialization.length - 2}
                            </Badge>
                          )}
                        </div>

                        <Button asChild variant="outline" size="sm" className="w-full bg-transparent">
                          <Link href={`mailto:${counsel.contact}`} className="flex items-center justify-center gap-2">
                            <Mail className="h-4 w-4" />
                            Contact
                          </Link>
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </ScrollReveal>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* CTA - Reduced padding */}
      <section className="py-16 sm:py-24 bg-primary text-primary-foreground">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <ScrollReveal>
            <span className="inline-flex items-center gap-2 text-accent text-xs sm:text-sm font-medium tracking-widest uppercase mb-3 sm:mb-4">
              <span className="w-6 sm:w-8 h-px bg-accent" />
              Work With Us
              <span className="w-6 sm:w-8 h-px bg-accent" />
            </span>
            <h2 className="font-serif text-2xl sm:text-3xl md:text-4xl font-bold mb-4 sm:mb-6">
              Connect With Our Experts
            </h2>
            <p className="text-primary-foreground/80 text-base sm:text-lg mb-6 sm:mb-8 max-w-2xl mx-auto">
              Ready to discuss your legal needs? Get in touch to find the right expertise for your case.
            </p>
            <Button
              asChild
              size="lg"
              className="bg-accent hover:bg-accent/90 text-accent-foreground px-6 sm:px-8 w-full sm:w-auto"
            >
              <Link href="/contact" className="flex items-center justify-center gap-2">
                Schedule Consultation
                <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>
          </ScrollReveal>
        </div>
      </section>

      <Footer />
    </div>
  )
}
