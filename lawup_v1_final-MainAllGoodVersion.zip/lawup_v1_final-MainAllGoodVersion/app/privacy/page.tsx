import type { Metadata } from "next"
import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export const metadata: Metadata = {
  title: "Privacy Policy - LawUp Consulting",
  description: "Privacy Policy for LawUp Consulting - How we collect, use, and protect your personal information.",
  alternates: {
    canonical: "https://lawup.in/privacy",
  },
}

export default function PrivacyPage() {
  return (
    <div className="min-h-screen">
      <Navigation />

      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-primary/5 to-accent/5">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="font-playfair text-4xl lg:text-5xl font-bold text-primary mb-6">Privacy Policy</h1>
            <p className="text-xl text-muted-foreground leading-relaxed">
              Your privacy is important to us. This policy explains how we collect, use, and protect your information.
            </p>
          </div>
        </div>
      </section>

      {/* Privacy Policy Content */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">Privacy Policy</CardTitle>
              <p className="text-muted-foreground">Last updated: January 2025</p>
            </CardHeader>
            <CardContent className="prose prose-gray max-w-none">
              <div className="space-y-8">
                <section>
                  <h2 className="text-xl font-semibold text-primary mb-4">1. Information We Collect</h2>
                  <p className="text-muted-foreground leading-relaxed mb-4">
                    We collect information you provide directly to us, such as when you:
                  </p>
                  <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
                    <li>Fill out our contact form or request consultation</li>
                    <li>Subscribe to our newsletter or legal updates</li>
                    <li>Communicate with us via email or phone</li>
                    <li>Visit our website (through cookies and analytics)</li>
                  </ul>
                </section>

                <section>
                  <h2 className="text-xl font-semibold text-primary mb-4">2. How We Use Your Information</h2>
                  <p className="text-muted-foreground leading-relaxed mb-4">We use the information we collect to:</p>
                  <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
                    <li>Respond to your inquiries and provide legal consultation</li>
                    <li>Send you legal updates and newsletters (with your consent)</li>
                    <li>Improve our website and services</li>
                    <li>Comply with legal obligations and professional standards</li>
                  </ul>
                </section>

                <section>
                  <h2 className="text-xl font-semibold text-primary mb-4">3. Information Sharing</h2>
                  <p className="text-muted-foreground leading-relaxed">
                    We do not sell, trade, or otherwise transfer your personal information to third parties without your
                    consent, except as described in this policy. We may share information with trusted service providers
                    who assist us in operating our website and conducting our business, provided they agree to keep this
                    information confidential.
                  </p>
                </section>

                <section>
                  <h2 className="text-xl font-semibold text-primary mb-4">4. Data Security</h2>
                  <p className="text-muted-foreground leading-relaxed">
                    We implement appropriate security measures to protect your personal information against unauthorized
                    access, alteration, disclosure, or destruction. However, no method of transmission over the internet
                    is 100% secure.
                  </p>
                </section>

                <section>
                  <h2 className="text-xl font-semibold text-primary mb-4">5. Attorney-Client Privilege</h2>
                  <p className="text-muted-foreground leading-relaxed">
                    Please note that communication through our website contact form does not establish an
                    attorney-client relationship. Confidential or time-sensitive information should not be sent through
                    this website.
                  </p>
                </section>

                <section>
                  <h2 className="text-xl font-semibold text-primary mb-4">6. Your Rights</h2>
                  <p className="text-muted-foreground leading-relaxed mb-4">You have the right to:</p>
                  <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
                    <li>Access and update your personal information</li>
                    <li>Request deletion of your personal information</li>
                    <li>Opt-out of marketing communications</li>
                    <li>Request information about how we use your data</li>
                  </ul>
                </section>

                <section>
                  <h2 className="text-xl font-semibold text-primary mb-4">7. Contact Us</h2>
                  <p className="text-muted-foreground leading-relaxed">
                    If you have any questions about this Privacy Policy, please contact us at:
                  </p>
                  <div className="mt-4 p-4 bg-muted rounded-lg">
                    <p className="font-semibold">LawUp Consulting</p>
                    <p className="text-muted-foreground">Email: support@lawup.in</p>
                    <p className="text-muted-foreground">Phone: +91-9716968000</p>
                    <p className="text-muted-foreground">Address: Chamber: Ground B188a, Jamunapuri, Jaipur, Rajasthan - 302039</p>
                  </div>
                </section>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      <Footer />
    </div>
  )
}
