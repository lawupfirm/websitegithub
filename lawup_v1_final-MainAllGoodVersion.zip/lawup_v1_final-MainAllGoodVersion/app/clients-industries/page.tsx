import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Building, Factory, Landmark, Stethoscope, GraduationCap, Truck, Zap, Shield } from "lucide-react"

const industries = [
  {
    icon: Building,
    title: "Financial Services",
    description: "Banks, NBFCs, insurance companies, and fintech startups.",
  },
  {
    icon: Factory,
    title: "Manufacturing",
    description: "Industrial manufacturing, automotive, and heavy machinery sectors.",
  },
  {
    icon: Landmark,
    title: "Real Estate",
    description: "Developers, construction companies, and property management firms.",
  },
  {
    icon: Stethoscope,
    title: "Healthcare",
    description: "Hospitals, pharmaceutical companies, and medical device manufacturers.",
  },
  {
    icon: GraduationCap,
    title: "Education",
    description: "Educational institutions, EdTech companies, and training organizations.",
  },
  {
    icon: Truck,
    title: "Logistics & Transportation",
    description: "Shipping companies, logistics providers, and transportation services.",
  },
  {
    icon: Zap,
    title: "Energy & Utilities",
    description: "Power generation, renewable energy, and utility companies.",
  },
  {
    icon: Shield,
    title: "Government & Public Sector",
    description: "Government agencies, public enterprises, and regulatory bodies.",
  },
]

export default function ClientsIndustriesPage() {
  return (
    <div className="min-h-screen">
      <Navigation />

      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-primary/5 to-accent/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="font-playfair text-4xl lg:text-5xl font-bold text-primary mb-6">Clients & Industries</h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
              We serve diverse industries with specialized legal expertise, maintaining the highest standards of
              confidentiality and professional conduct.
            </p>
          </div>
        </div>
      </section>

      {/* Industries We Serve */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-playfair text-3xl font-bold text-primary mb-4">Industries We Serve</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Our expertise spans across multiple sectors, providing tailored legal solutions for each industry's unique
              challenges.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {industries.map((industry, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow duration-300">
                <CardHeader className="text-center">
                  <industry.icon className="h-12 w-12 text-accent mx-auto mb-4" />
                  <CardTitle className="text-lg">{industry.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground text-sm text-center">{industry.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Client Confidentiality */}
      <section className="py-20 bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="font-playfair text-3xl font-bold text-primary mb-6">Client Confidentiality & Trust</h2>
              <p className="text-muted-foreground mb-6 leading-relaxed">
                We understand that legal matters often involve sensitive information. Our firm maintains strict
                confidentiality protocols and follows all professional conduct rules as prescribed by the Bar Council of
                India.
              </p>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-accent rounded-full mt-2 flex-shrink-0"></div>
                  <p className="text-muted-foreground">
                    <strong>Attorney-Client Privilege:</strong> All communications are protected under legal privilege.
                  </p>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-accent rounded-full mt-2 flex-shrink-0"></div>
                  <p className="text-muted-foreground">
                    <strong>Conflict Checks:</strong> Rigorous conflict checking procedures before engagement.
                  </p>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-accent rounded-full mt-2 flex-shrink-0"></div>
                  <p className="text-muted-foreground">
                    <strong>Data Security:</strong> Secure systems and protocols for handling sensitive information.
                  </p>
                </div>
              </div>
            </div>
            <div className="bg-primary text-primary-foreground p-8 rounded-lg">
              <h3 className="text-2xl font-bold mb-4">Our Commitment</h3>
              <p className="opacity-90 mb-6">
                We are committed to providing exceptional legal services while maintaining the highest ethical standards
                and professional integrity.
              </p>
              <ul className="space-y-2 text-sm opacity-90">
                <li>• Transparent fee structures</li>
                <li>• Regular case updates</li>
                <li>• Ethical practice standards</li>
                <li>• Professional accountability</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-playfair text-3xl font-bold text-primary mb-6">Ready to Work Together?</h2>
          <p className="text-xl text-muted-foreground mb-8">
            Join our diverse portfolio of satisfied clients across industries. Let's discuss how we can support your
            legal needs.
          </p>
          <Button asChild size="lg" className="text-lg px-8">
            <Link href="/contact">Start the Conversation</Link>
          </Button>
        </div>
      </section>

      <Footer />
    </div>
  )
}
