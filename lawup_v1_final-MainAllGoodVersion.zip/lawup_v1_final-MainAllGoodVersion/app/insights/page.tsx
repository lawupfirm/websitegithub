import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { PageHero } from "@/components/page-hero"
import { ScrollReveal } from "@/components/scroll-reveal"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import Link from "next/link"
import Image from "next/image"
import { Calendar, Clock, ArrowRight, Search } from "lucide-react"
import { blogPosts } from "@/data/blog-posts"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Legal Insights - LawUp Consulting | Expert Analysis & Updates",
  description:
    "Stay informed with expert legal analysis, regulatory updates, and industry insights from LawUp Consulting.",
  openGraph: {
    title: "Legal Insights - LawUp Consulting",
    description: "Expert legal analysis and regulatory updates from our experienced professionals.",
  },
  alternates: {
    canonical: "https://lawup.in/insights",
  },
}

export default function InsightsPage() {
  const featuredPost = blogPosts[0]
  const otherPosts = blogPosts.slice(1)

  return (
    <div className="min-h-screen">
      <Navigation />

      <PageHero
        badge="Legal Insights"
        title="Expert Perspectives"
        subtitle="Stay informed with our expert analysis on legal developments, regulatory changes, and industry trends affecting businesses and individuals."
        size="large"
      />

      {/* Search Bar */}
      <section className="py-8 bg-secondary/30 border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-md mx-auto relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search articles..." className="pl-11 bg-background" />
          </div>
        </div>
      </section>

      {/* Featured Article */}
      {featuredPost && (
        <section className="py-16 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <ScrollReveal>
              <div className="text-center mb-12">
                <span className="inline-flex items-center gap-2 text-accent text-sm font-medium tracking-widest uppercase">
                  <span className="w-8 h-px bg-accent" />
                  Featured Article
                  <span className="w-8 h-px bg-accent" />
                </span>
              </div>
            </ScrollReveal>

            <ScrollReveal delay={100}>
              <Link href={`/insights/${featuredPost.slug}`} className="group block">
                <Card className="overflow-hidden border-0 shadow-xl hover-lift">
                  <div className="grid lg:grid-cols-2">
                    <div className="relative h-64 lg:h-auto lg:min-h-[400px]">
                      <Image
                        src={featuredPost.image || "/placeholder.svg"}
                        alt={featuredPost.title}
                        fill
                        className="object-cover transition-transform duration-700 group-hover:scale-105"
                      />
                      <div className="absolute inset-0 bg-gradient-to-r from-primary/20 via-transparent to-transparent lg:bg-gradient-to-t" />
                    </div>
                    <CardContent className="p-8 lg:p-12 flex flex-col justify-center">
                      <div className="flex flex-wrap items-center gap-3 mb-4">
                        <Badge className="bg-accent text-accent-foreground border-0">{featuredPost.category}</Badge>
                        <span className="flex items-center text-sm text-muted-foreground">
                          <Calendar className="h-4 w-4 mr-1" />
                          {featuredPost.date}
                        </span>
                        <span className="flex items-center text-sm text-muted-foreground">
                          <Clock className="h-4 w-4 mr-1" />
                          {featuredPost.readTime}
                        </span>
                      </div>
                      <h2 className="font-serif text-2xl lg:text-3xl font-bold text-primary mb-4 group-hover:text-accent transition-colors">
                        {featuredPost.title}
                      </h2>
                      <p className="text-muted-foreground leading-relaxed mb-6">{featuredPost.excerpt}</p>
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium text-primary">{featuredPost.author}</p>
                          <p className="text-sm text-muted-foreground">{featuredPost.authorTitle}</p>
                        </div>
                        <span className="inline-flex items-center text-accent font-medium group-hover:gap-3 transition-all">
                          Read Article
                          <ArrowRight className="h-4 w-4 ml-2" />
                        </span>
                      </div>
                    </CardContent>
                  </div>
                </Card>
              </Link>
            </ScrollReveal>
          </div>
        </section>
      )}

      {/* Articles Grid */}
      <section className="py-16 bg-secondary/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollReveal className="text-center mb-12">
            <h2 className="font-serif text-3xl font-bold text-primary mb-4">Latest Articles</h2>
            <p className="text-muted-foreground">Expert insights and analysis from our legal professionals</p>
          </ScrollReveal>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {otherPosts.map((post, index) => (
              <ScrollReveal key={post.slug} delay={index * 100}>
                <Link href={`/insights/${post.slug}`} className="group block h-full">
                  <Card className="h-full overflow-hidden border-0 shadow-lg hover-lift">
                    <div className="relative h-48">
                      <Image
                        src={post.image || "/placeholder.svg"}
                        alt={post.title}
                        fill
                        className="object-cover transition-transform duration-500 group-hover:scale-105"
                      />
                      <div className="absolute top-4 left-4">
                        <Badge variant="secondary" className="text-xs">
                          {post.category}
                        </Badge>
                      </div>
                    </div>
                    <CardContent className="p-6">
                      <div className="flex items-center gap-3 text-xs text-muted-foreground mb-3">
                        <span className="flex items-center">
                          <Calendar className="h-3 w-3 mr-1" />
                          {post.date}
                        </span>
                        <span className="flex items-center">
                          <Clock className="h-3 w-3 mr-1" />
                          {post.readTime}
                        </span>
                      </div>
                      <h3 className="font-serif text-lg font-semibold text-primary mb-3 group-hover:text-accent transition-colors line-clamp-2">
                        {post.title}
                      </h3>
                      <p className="text-muted-foreground text-sm leading-relaxed line-clamp-2 mb-4">{post.excerpt}</p>
                      <div className="flex items-center justify-between pt-4 border-t border-border">
                        <span className="text-sm font-medium text-primary">{post.author}</span>
                        <ArrowRight className="h-4 w-4 text-accent opacity-0 group-hover:opacity-100 transition-opacity" />
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-24 bg-primary text-primary-foreground">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <ScrollReveal>
            <span className="inline-flex items-center gap-2 text-accent text-sm font-medium tracking-widest uppercase mb-4">
              <span className="w-8 h-px bg-accent" />
              Stay Updated
              <span className="w-8 h-px bg-accent" />
            </span>
            <h2 className="font-serif text-3xl md:text-4xl font-bold mb-4">Subscribe to Our Insights</h2>
            <p className="text-primary-foreground/80 mb-8 max-w-xl mx-auto">
              Get the latest legal insights and updates delivered directly to your inbox.
            </p>
            <form className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
              <Input
                type="email"
                placeholder="Enter your email"
                className="flex-1 bg-primary-foreground/10 border-primary-foreground/20 text-primary-foreground placeholder:text-primary-foreground/50"
              />
              <Button className="bg-accent hover:bg-accent/90 text-accent-foreground px-6">Subscribe</Button>
            </form>
            <p className="text-xs text-primary-foreground/50 mt-4">We respect your privacy. Unsubscribe at any time.</p>
          </ScrollReveal>
        </div>
      </section>

      <Footer />
    </div>
  )
}
