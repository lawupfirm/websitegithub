import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"
import Image from "next/image"
import { Calendar, Clock, ArrowLeft, Share2, Linkedin, Twitter } from "lucide-react"
import { blogPosts } from "@/data/blog-posts"
import { notFound } from "next/navigation"
import { ArticleSchema } from "@/components/seo/article-schema"
import { BreadcrumbSchema } from "@/components/seo/breadcrumb-schema"
import type { Metadata } from "next"

interface BlogPostPageProps {
  params: {
    slug: string
  }
}

export async function generateStaticParams() {
  return blogPosts.map((post) => ({
    slug: post.slug,
  }))
}

export async function generateMetadata({ params }: BlogPostPageProps): Promise<Metadata> {
  const post = blogPosts.find((p) => p.slug === params.slug)

  if (!post) {
    return {
      title: "Article Not Found - LawUp Consulting",
      description: "The requested article could not be found.",
    }
  }

  return {
    title: `${post.title} - LawUp Consulting`,
    description: post.excerpt,
    keywords: [
      post.category.toLowerCase(),
      "legal advice",
      "Indian law",
      "legal analysis",
      "expert opinion",
      "legal insights",
    ],
    authors: [{ name: post.author }],
    openGraph: {
      title: post.title,
      description: post.excerpt,
      type: "article",
      publishedTime: new Date(post.date).toISOString(),
      authors: [post.author],
      images: [post.image],
    },
    twitter: {
      card: "summary_large_image",
      title: post.title,
      description: post.excerpt,
      images: [post.image],
    },
    alternates: {
      canonical: `https://lawup.in/insights/${post.slug}`,
    },
  }
}

export default function BlogPostPage({ params }: BlogPostPageProps) {
  const post = blogPosts.find((p) => p.slug === params.slug)

  if (!post) {
    notFound()
  }

  // Get related posts (same category, excluding current post)
  const relatedPosts = blogPosts.filter((p) => p.category === post.category && p.slug !== post.slug).slice(0, 3)

  return (
    <div className="min-h-screen">
      <ArticleSchema
        title={post.title}
        description={post.excerpt}
        author={post.author}
        authorTitle={post.authorTitle}
        datePublished={new Date(post.date).toISOString()}
        image={`https://lawup.in${post.image}`}
        url={`https://lawup.in/insights/${post.slug}`}
        category={post.category}
      />
      <BreadcrumbSchema
        items={[
          { name: "Home", url: "https://lawup.in" },
          { name: "Insights", url: "https://lawup.in/insights" },
          { name: post.title, url: `https://lawup.in/insights/${post.slug}` },
        ]}
      />

      <Navigation />

      {/* Article Header */}
      <article className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <Button variant="ghost" asChild className="mb-6">
              <Link href="/insights">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Insights
              </Link>
            </Button>

            <div className="flex items-center gap-4 mb-6">
              <Badge variant="secondary">{post.category}</Badge>
              <div className="flex items-center text-sm text-muted-foreground">
                <Calendar className="h-4 w-4 mr-1" />
                {post.date}
              </div>
              <div className="flex items-center text-sm text-muted-foreground">
                <Clock className="h-4 w-4 mr-1" />
                {post.readTime}
              </div>
            </div>

            <h1 className="font-playfair text-4xl lg:text-5xl font-bold text-primary mb-6 leading-tight">
              {post.title}
            </h1>

            <p className="text-xl text-muted-foreground mb-8 leading-relaxed">{post.excerpt}</p>

            <div className="flex items-center justify-between border-b pb-6 mb-8">
              <div className="flex items-center">
                <div>
                  <p className="font-medium">{post.author}</p>
                  <p className="text-sm text-muted-foreground">{post.authorTitle}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm">
                  <Share2 className="h-4 w-4 mr-2" />
                  Share
                </Button>
                <Button variant="outline" size="sm">
                  <Linkedin className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="sm">
                  <Twitter className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* Featured Image */}
          <div className="relative h-64 lg:h-96 mb-12 rounded-lg overflow-hidden">
            <Image src={post.image || "/placeholder.svg"} alt={post.title} fill className="object-cover" />
          </div>

          {/* Article Content */}
          <div className="prose prose-lg max-w-none">
            <div dangerouslySetInnerHTML={{ __html: post.content }} />
          </div>

          {/* Disclaimer */}
          <div className="mt-12 p-6 bg-muted rounded-lg">
            <h3 className="font-semibold mb-2">Legal Disclaimer</h3>
            <p className="text-sm text-muted-foreground">
              This article is for informational purposes only and does not constitute legal advice. The information
              contained herein may not be applicable to all situations and may not reflect the most current legal
              developments. Please consult with a qualified attorney for specific legal advice regarding your situation.
            </p>
          </div>
        </div>
      </article>

      {/* Related Articles */}
      {relatedPosts.length > 0 && (
        <section className="py-16 bg-card">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="font-playfair text-3xl font-bold text-primary mb-8 text-center">Related Articles</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {relatedPosts.map((relatedPost) => (
                <Card key={relatedPost.slug} className="overflow-hidden hover:shadow-lg transition-shadow duration-300">
                  <div className="relative h-48">
                    <Image
                      src={relatedPost.image || "/placeholder.svg"}
                      alt={relatedPost.title}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <CardContent className="p-6">
                    <Badge variant="outline" className="text-xs mb-2">
                      {relatedPost.category}
                    </Badge>
                    <h3 className="font-semibold mb-2 leading-tight">
                      <Link href={`/insights/${relatedPost.slug}`} className="hover:text-primary transition-colors">
                        {relatedPost.title}
                      </Link>
                    </h3>
                    <p className="text-sm text-muted-foreground mb-4">{relatedPost.excerpt.substring(0, 100)}...</p>
                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                      <span>{relatedPost.author}</span>
                      <span>{relatedPost.readTime}</span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>
      )}

      <Footer />
    </div>
  )
}
