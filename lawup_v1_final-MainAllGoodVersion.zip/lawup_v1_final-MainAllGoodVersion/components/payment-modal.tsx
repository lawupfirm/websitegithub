'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { CreditCard, Loader2, CheckCircle, AlertCircle } from 'lucide-react'
import { SERVICES } from '@/data/services'
import Script from 'next/script'

declare global {
  interface Window {
    Razorpay: any
  }
}

interface PaymentModalProps {
  isOpen: boolean
  onClose: () => void
  email: string
  name: string
  phone: string
  contactMessage?: string
  onPaymentSuccess?: (paymentData: any) => void
}

type PaymentMode = 'service' | 'custom'

export function PaymentModal({
  isOpen,
  onClose,
  email,
  name,
  phone,
  contactMessage,
  onPaymentSuccess,
}: PaymentModalProps) {
  const [paymentMode, setPaymentMode] = useState<PaymentMode>('service')
  const [selectedService, setSelectedService] = useState<string>('')
  const [customAmount, setCustomAmount] = useState<string>('')
  const [isProcessing, setIsProcessing] = useState(false)
  const [paymentStatus, setPaymentStatus] = useState<'idle' | 'processing' | 'success' | 'error'>('idle')
  const [errorMessage, setErrorMessage] = useState('')

  const getServiceFee = () => {
    if (paymentMode === 'service' && selectedService) {
      const service = SERVICES.find(s => s.name === selectedService)
      return service?.startingFee || 0
    }
    return customAmount ? parseFloat(customAmount) : 0
  }

  const handlePayment = async () => {
    try {
      const amount = getServiceFee()

      if (!amount || amount < 100) {
        setErrorMessage('Minimum amount is ₹100')
        setPaymentStatus('error')
        return
      }

      setIsProcessing(true)
      setPaymentStatus('processing')

      // Create order from backend
      const orderRes = await fetch('/api/razorpay/create-order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount,
          email,
          phone,
          name,
          service: paymentMode === 'service' ? selectedService : `Custom - ₹${amount}`,
          orderId: `ORDER_${Date.now()}`,
        }),
      })

      if (!orderRes.ok) {
        const errorText = await orderRes.text()
        console.error("[v0] Order API error:", orderRes.status, errorText)
        try {
          const errorData = JSON.parse(errorText)
          throw new Error(errorData.error || 'Failed to create order')
        } catch {
          throw new Error(`Failed to create order: ${orderRes.status}`)
        }
      }

      const orderData = await orderRes.json()

      // Initialize Razorpay
      const options = {
        key: orderData.key,
        amount: orderData.amount,
        currency: orderData.currency,
        order_id: orderData.orderId,
        name: 'LawUp Consulting',
        description: paymentMode === 'service' ? selectedService : `Custom Payment - ₹${amount}`,
        prefill: {
          name,
          email,
          contact: phone,
        },
        handler: async (response: any) => {
          try {
            // Verify payment
            const verifyRes = await fetch('/api/razorpay/verify-payment', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                razorpay_order_id: response.razorpay_order_id,
                razorpay_payment_id: response.razorpay_payment_id,
                razorpay_signature: response.razorpay_signature,
              }),
            })

            const verifyData = await verifyRes.json()

            if (!verifyRes.ok) {
              throw new Error('Payment verification failed')
            }

            // Send receipt email
            await fetch('/api/send-payment-receipt', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                email,
                name,
                amount,
                service: paymentMode === 'service' ? selectedService : `Custom - ₹${amount}`,
                payment_id: response.razorpay_payment_id,
                order_id: response.razorpay_order_id,
                contact_message: contactMessage,
              }),
            })

            setPaymentStatus('success')
            if (onPaymentSuccess) {
              onPaymentSuccess({
                payment_id: response.razorpay_payment_id,
                order_id: response.razorpay_order_id,
                amount,
              })
            }

            setTimeout(() => {
              onClose()
              setPaymentStatus('idle')
            }, 2000)
          } catch (err) {
            setErrorMessage('Payment verification failed')
            setPaymentStatus('error')
          }
        },
        modal: {
          ondismiss: () => {
            setPaymentStatus('idle')
          },
        },
      }

      const razorpay = new window.Razorpay(options)
      razorpay.open()
    } catch (err: any) {
      setErrorMessage(err.message || 'Payment failed')
      setPaymentStatus('error')
    } finally {
      setIsProcessing(false)
    }
  }

  const amount = getServiceFee()

  return (
    <>
      <Script
        src="https://checkout.razorpay.com/v1/checkout.js"
        strategy="lazyOnload"
      />

      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CreditCard className="h-5 w-5 text-accent" />
              Pay Consultation Fee
            </DialogTitle>
            <DialogDescription>
              Choose a service or enter a custom amount
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6">
            {/* Payment Mode Selection */}
            <div className="space-y-3">
              <Label>Payment Method</Label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => {
                    setPaymentMode('service')
                    setSelectedService('')
                    setCustomAmount('')
                  }}
                  className={`p-3 rounded-lg border-2 transition-all ${
                    paymentMode === 'service'
                      ? 'border-accent bg-accent/10'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="font-semibold text-sm">Service Wise</div>
                  <div className="text-xs text-muted-foreground">Choose from list</div>
                </button>
                <button
                  onClick={() => {
                    setPaymentMode('custom')
                    setSelectedService('')
                  }}
                  className={`p-3 rounded-lg border-2 transition-all ${
                    paymentMode === 'custom'
                      ? 'border-accent bg-accent/10'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="font-semibold text-sm">Custom Amount</div>
                  <div className="text-xs text-muted-foreground">Enter manually</div>
                </button>
              </div>
            </div>

            {/* Service Selection */}
            {paymentMode === 'service' && (
              <div className="space-y-3">
                <Label>Select Service</Label>
                <div className="max-h-64 overflow-y-auto space-y-2">
                  {SERVICES.map((service) => (
                    <button
                      key={service.id}
                      onClick={() => setSelectedService(service.name)}
                      className={`w-full p-3 rounded-lg border-2 text-left transition-all ${
                        selectedService === service.name
                          ? 'border-accent bg-accent/10'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <div className="font-semibold text-sm">{service.name}</div>
                          <div className="text-xs text-muted-foreground">{service.category}</div>
                        </div>
                        <div className="font-bold text-accent">₹{service.startingFee}</div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Custom Amount */}
            {paymentMode === 'custom' && (
              <div className="space-y-3">
                <Label htmlFor="amount">Enter Amount (₹)</Label>
                <div className="flex items-center gap-2">
                  <span className="text-xl font-bold">₹</span>
                  <Input
                    id="amount"
                    type="number"
                    min="100"
                    step="100"
                    placeholder="Minimum ₹100"
                    value={customAmount}
                    onChange={(e) => setCustomAmount(e.target.value)}
                    className="text-lg"
                  />
                </div>
                <p className="text-xs text-muted-foreground">Minimum amount is ₹100</p>
              </div>
            )}

            {/* Amount Summary */}
            {amount > 0 && (
              <div className="bg-secondary/50 p-4 rounded-lg">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Total Amount</span>
                  <span className="text-2xl font-bold text-accent">₹{amount.toLocaleString('en-IN')}</span>
                </div>
              </div>
            )}

            {/* Status Messages */}
            {paymentStatus === 'success' && (
              <div className="bg-green-50 border border-green-200 p-4 rounded-lg flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-green-900">Payment Successful!</p>
                  <p className="text-sm text-green-800">Receipt sent to your email. We will get in touch soon.</p>
                </div>
              </div>
            )}

            {paymentStatus === 'error' && (
              <div className="bg-red-50 border border-red-200 p-4 rounded-lg flex items-start gap-3">
                <AlertCircle className="h-5 w-5 text-red-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-red-900">Payment Failed</p>
                  <p className="text-sm text-red-800">{errorMessage}</p>
                </div>
              </div>
            )}

            {/* Buttons */}
            <div className="flex gap-3 pt-4">
              <Button
                variant="outline"
                onClick={onClose}
                disabled={isProcessing}
                className="flex-1 bg-transparent"
              >
                Cancel
              </Button>
              <Button
                onClick={handlePayment}
                disabled={isProcessing || !amount || amount < 100 || paymentStatus === 'success'}
                className="flex-1 bg-accent hover:bg-accent/90"
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>
                    <CreditCard className="mr-2 h-4 w-4" />
                    Pay ₹{amount.toLocaleString('en-IN')}
                  </>
                )}
              </Button>
            </div>

            {/* Info */}
            <p className="text-xs text-muted-foreground text-center">
              💳 Secure payment via Razorpay | GST applicable as per regulations
            </p>
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}
