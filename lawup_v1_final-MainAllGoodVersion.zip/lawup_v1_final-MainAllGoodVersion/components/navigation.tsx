"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Menu, X, ChevronDown, ArrowRight } from "lucide-react"
import { cn } from "@/lib/utils"
import Image from "next/image"

export function Navigation() {
  const [isOpen, setIsOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null)

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        setIsOpen(false)
      }
    }
    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [])

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden"
    } else {
      document.body.style.overflow = ""
    }
    return () => {
      document.body.style.overflow = ""
    }
  }, [isOpen])

  const navItems = [
    { href: "/", label: "Home" },
    { href: "/about", label: "About" },
    {
      href: "/practice-areas",
      label: "Practice Areas",
      submenu: [
        { href: "/practice-areas#litigation", label: "Litigation" },
        { href: "/practice-areas#corporate", label: "Corporate Law" },
        { href: "/practice-areas#compliance", label: "Compliance" },
        { href: "/practice-areas#banking", label: "Banking & Finance" },
        { href: "/practice-areas#labour", label: "Labour Law" },
        { href: "/practice-areas#cyber", label: "Cyber Law" },
        { href: "/practice-areas#intellectual-property", label: "Intellectual Property" },
      ],
    },
    { href: "/team", label: "Team" },
    { href: "/insights", label: "Insights" },
    { href: "/legal-guide", label: "Legal Guide" },
    { href: "/contact", label: "Contact" },
  ]

  return (
    <nav
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-500",
        scrolled
          ? "bg-background/95 backdrop-blur-lg border-b border-border shadow-sm py-2"
          : "bg-transparent py-3 sm:py-4",
      )}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 safe-area-padding">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 sm:gap-3 group">
            <div className="relative w-11 h-11 sm:w-13 sm:h-13 flex-shrink-0 rounded-full overflow-hidden border-2 border-accent/20 hover:border-accent transition-colors bg-primary/5">
              <Image
                src="/images/lawup-logo.jpg"
                alt="LawUp Consulting Logo"
                fill
                className="object-cover"
                priority
              />
            </div>
            <div className="flex flex-col">
              <span
                className={cn(
                  "font-serif text-lg sm:text-xl lg:text-2xl font-bold tracking-tight transition-colors duration-300",
                  scrolled ? "text-primary" : "text-white",
                )}
              >
                LawUp
              </span>
              <span
                className={cn(
                  "text-[8px] sm:text-[9px] uppercase tracking-[0.2em] -mt-0.5 transition-colors duration-300",
                  scrolled ? "text-muted-foreground" : "text-white/70",
                )}
              >
                Consulting
              </span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-1">
            {navItems.map((item) => (
              <div
                key={item.href}
                className="relative"
                onMouseEnter={() => item.submenu && setActiveDropdown(item.label)}
                onMouseLeave={() => setActiveDropdown(null)}
              >
                <Link
                  href={item.href}
                  className={cn(
                    "flex items-center gap-1 px-4 py-2 text-sm font-medium transition-colors duration-300 underline-animation",
                    scrolled ? "text-foreground hover:text-accent" : "text-white/90 hover:text-white",
                  )}
                >
                  {item.label}
                  {item.submenu && (
                    <ChevronDown
                      className={cn(
                        "h-3.5 w-3.5 transition-transform duration-300",
                        activeDropdown === item.label && "rotate-180",
                      )}
                    />
                  )}
                </Link>

                {/* Dropdown */}
                {item.submenu && activeDropdown === item.label && (
                  <div className="absolute top-full left-0 pt-2 fade-up">
                    <div className="bg-background/95 backdrop-blur-lg border border-border rounded-lg shadow-xl p-2 min-w-[220px]">
                      {item.submenu.map((subItem) => (
                        <Link
                          key={subItem.href}
                          href={subItem.href}
                          className="flex items-center justify-between px-4 py-2.5 text-sm text-foreground hover:text-accent hover:bg-muted/50 rounded-md transition-colors group"
                        >
                          {subItem.label}
                          <ArrowRight className="h-3.5 w-3.5 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all" />
                        </Link>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* CTA Button - Different styling when not scrolled */}
          <div className="hidden lg:block">
            <Button
              asChild
              className={cn(
                "font-medium px-6 transition-all duration-300",
                scrolled
                  ? "bg-accent hover:bg-accent/90 text-accent-foreground hover:shadow-lg hover:shadow-accent/20"
                  : "bg-white text-primary hover:bg-white/90",
              )}
            >
              <Link href="/contact" className="flex items-center gap-2">
                Get Consultation
                <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>
          </div>

          {/* Mobile menu button - Larger touch target */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className={cn(
              "lg:hidden p-2 -mr-2 transition-colors duration-300 min-w-[44px] min-h-[44px] flex items-center justify-center",
              scrolled ? "text-foreground" : "text-white",
            )}
            aria-label="Toggle menu"
          >
            {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Navigation - Full screen overlay on mobile */}
        <div
          className={cn(
            "lg:hidden absolute left-0 right-0 top-full bg-background/98 backdrop-blur-lg transition-all duration-300 overflow-y-auto z-[100] max-h-[calc(100vh-70px)]",
            isOpen ? "opacity-100 visible" : "opacity-0 invisible pointer-events-none h-0",
          )}
        >
          <div className="px-4 py-6 space-y-2">
            {navItems.map((item, index) => (
              <div key={item.href}>
                <Link
                  href={item.href}
                  className="flex items-center justify-between px-4 py-4 text-lg font-medium text-foreground hover:text-accent hover:bg-muted/50 rounded-lg transition-colors"
                  onClick={() => setIsOpen(false)}
                  style={{ animationDelay: `${index * 0.05}s` }}
                >
                  {item.label}
                  {item.submenu && <ChevronDown className="h-5 w-5" />}
                </Link>
                {item.submenu && (
                  <div className="ml-4 mt-1 space-y-1">
                    {item.submenu.map((subItem) => (
                      <Link
                        key={subItem.href}
                        href={subItem.href}
                        className="flex items-center px-4 py-3 text-base text-muted-foreground hover:text-accent hover:bg-muted/30 rounded-lg transition-colors"
                        onClick={() => setIsOpen(false)}
                      >
                        <span className="w-2 h-2 bg-accent/50 rounded-full mr-3" />
                        {subItem.label}
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            ))}
            <div className="pt-6 px-4">
              <Button asChild className="w-full bg-accent hover:bg-accent/90 text-accent-foreground py-6 text-base">
                <Link href="/contact" onClick={() => setIsOpen(false)}>
                  Get Consultation
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </nav>
  )
}
