"use client"

import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { ScrollReveal } from "@/components/scroll-reveal"
import { AnimatedCounter } from "@/components/animated-counter"
import { ArrowRight, Award, Users, Scale, Globe } from "lucide-react"

export function AboutPreview() {
  return (
    <section className="py-16 sm:py-24 lg:py-32 bg-background overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-8 sm:gap-12 lg:gap-20 items-center">
          {/* Image Side - Better mobile layout */}
          <ScrollReveal direction="left" className="relative order-2 lg:order-1">
            <div className="relative aspect-[4/3] sm:aspect-[4/5] rounded-xl sm:rounded-2xl overflow-hidden">
              <Image
                src="/images/photo-6093927697144201690-y.jpeg"
                alt="Indian Lady Justice statue representing clear sight and transparent justice"
                fill
                className="object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-primary/60 via-transparent to-transparent" />
            </div>

            {/* Floating Stats Card - Repositioned for mobile */}
            <div className="absolute -bottom-4 right-4 sm:-bottom-6 sm:-right-6 lg:-right-12 bg-accent text-accent-foreground p-4 sm:p-6 rounded-lg sm:rounded-xl shadow-2xl">
              <div className="text-2xl sm:text-4xl font-serif font-bold mb-0.5 sm:mb-1">
                <AnimatedCounter end={5000} suffix="+" />
              </div>
              <div className="text-[10px] sm:text-sm uppercase tracking-wider opacity-90">Matters Handled</div>
            </div>
          </ScrollReveal>

          {/* Content Side */}
          <div className="order-1 lg:order-2">
            <ScrollReveal>
              <span className="inline-flex items-center gap-2 text-accent text-xs sm:text-sm font-medium tracking-widest uppercase mb-3 sm:mb-4">
                <span className="w-6 sm:w-8 h-px bg-accent" />
                About LawUp
              </span>
            </ScrollReveal>

            <ScrollReveal delay={100}>
              <h2 className="font-serif text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-primary mb-4 sm:mb-6 leading-tight">
                Justice in Clear Sight
              </h2>
            </ScrollReveal>

            <ScrollReveal delay={200}>
              <p className="text-base sm:text-lg text-muted-foreground mb-4 sm:mb-6 leading-relaxed">
                LawUp Consulting stands as a beacon of legal excellence in India, founded on the principles of
                unwavering integrity, strategic precision, and client-centric solutions.
              </p>
            </ScrollReveal>

            <ScrollReveal delay={300}>
              <p className="text-sm sm:text-base text-muted-foreground mb-6 sm:mb-8 leading-relaxed">
                Led by Advocate Ravi Kumar Sharma, our team brings together seasoned legal professionals who deliver
                sophisticated counsel across corporate, litigation, and regulatory matters. We pride ourselves on
                demystifying complex legal challenges and providing clear, actionable strategies.
              </p>
            </ScrollReveal>

            {/* Features - Better grid for mobile */}
            <ScrollReveal delay={400}>
              <div className="grid grid-cols-2 gap-3 sm:gap-4 mb-6 sm:mb-8">
                {[
                  { icon: Award, text: "5+ Years Excellence" },
                  { icon: Users, text: "Expert Legal Team" },
                  { icon: Scale, text: "Client-First Approach" },
                  { icon: Globe, text: "Pan-India Presence" },
                ].map((item, index) => (
                  <div key={index} className="flex items-center gap-2 sm:gap-3">
                    <div className="p-1.5 sm:p-2 bg-accent/10 rounded-lg flex-shrink-0">
                      <item.icon className="h-3.5 w-3.5 sm:h-4 sm:w-4 text-accent" />
                    </div>
                    <span className="text-xs sm:text-sm font-medium text-primary">{item.text}</span>
                  </div>
                ))}
              </div>
            </ScrollReveal>

            <ScrollReveal delay={500}>
              <Button
                asChild
                size="lg"
                className="bg-primary hover:bg-primary/90 text-primary-foreground px-6 sm:px-8 w-full sm:w-auto"
              >
                <Link href="/about" className="flex items-center justify-center gap-2">
                  Learn More About Us
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
            </ScrollReveal>
          </div>
        </div>
      </div>
    </section>
  )
}
