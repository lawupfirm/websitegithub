import { ScrollReveal } from "@/components/scroll-reveal"
import { Clock, Globe, Shield, Award, Users, Headphones } from "lucide-react"

const features = [
  {
    icon: Clock,
    title: "24/7 Availability",
    description: "Round-the-clock legal support whenever you need us, including weekends and holidays",
  },
  {
    icon: Globe,
    title: "Pan-India Practice",
    description: "Licensed to practice across all courts and tribunals throughout India",
  },
  {
    icon: Shield,
    title: "100% Confidential",
    description: "Your legal matters are protected with strict attorney-client privilege and data security",
  },
  {
    icon: Award,
    title: "Proven Excellence",
    description: "5+ years of delivering successful outcomes across diverse practice areas",
  },
  {
    icon: Users,
    title: "Expert Team",
    description: "Highly qualified lawyers with specialized expertise and extensive courtroom experience",
  },
  {
    icon: Headphones,
    title: "Dedicated Support",
    description: "Personal attention and responsive communication throughout your legal journey",
  },
]

export function FeaturesSection() {
  return (
    <section className="py-16 sm:py-24 lg:py-32 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <ScrollReveal>
          <div className="text-center mb-12 sm:mb-16">
            <span className="inline-flex items-center gap-2 text-accent text-xs sm:text-sm font-medium tracking-widest uppercase mb-3 sm:mb-4">
              <span className="w-6 sm:w-8 h-px bg-accent" />
              Why Choose Us
              <span className="w-6 sm:w-8 h-px bg-accent" />
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-primary mb-3 sm:mb-4">
              The LawUp Advantage
            </h2>
            <p className="text-base sm:text-lg text-muted-foreground max-w-2xl mx-auto px-4">
              Combining legal expertise with modern technology to deliver exceptional client service
            </p>
          </div>
        </ScrollReveal>

        {/* Features Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {features.map((feature, index) => (
            <ScrollReveal key={index} delay={index * 100}>
              <div className="group p-6 sm:p-8 rounded-2xl bg-card border border-border hover:border-accent/50 hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
                <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-xl bg-accent/10 flex items-center justify-center mb-4 sm:mb-6 group-hover:bg-accent/20 transition-colors">
                  <feature.icon className="w-6 h-6 sm:w-7 sm:h-7 text-accent" />
                </div>
                <h3 className="font-serif text-lg sm:text-xl font-bold text-primary mb-2 sm:mb-3">{feature.title}</h3>
                <p className="text-sm sm:text-base text-muted-foreground leading-relaxed">{feature.description}</p>
              </div>
            </ScrollReveal>
          ))}
        </div>
      </div>
    </section>
  )
}
