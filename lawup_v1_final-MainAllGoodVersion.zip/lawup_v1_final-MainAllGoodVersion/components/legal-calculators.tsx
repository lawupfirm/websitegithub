"use client"

import { useState } from "react"
import { Calculator, Scale, TrendingUp, FileText, AlertCircle, Gavel, Users, Shield } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

type CalculatorType =
  | "court-fee"
  | "arbitration"
  | "section-138"
  | "appeal"
  | "limitation"
  | "interest"
  | "stamp-duty"
  | null

const formatAmountInWords = (amount: number): string => {
  if (amount >= 10000000) {
    const crore = (amount / 10000000).toFixed(2)
    return `${crore} Crore`
  } else if (amount >= 100000) {
    const lakh = (amount / 100000).toFixed(2)
    return `${lakh} Lakh`
  }
  return "" // Don't show words for amounts less than 1 Lakh
}

const formatAmountWithWords = (amount: number): string => {
  const numeric = `₹${amount.toLocaleString("en-IN")}`
  const words = formatAmountInWords(amount)
  if (words) {
    return `${numeric} (${words})`
  }
  return numeric
}

const RAJASTHAN_COURT_FEE_SLABS = [
  {
    min: 0,
    max: 300000,
    percentage: 7.5,
    fixedOnPrevious: 0,
    description: "Up to ₹3,00,000 @ 7.5%",
  },
  {
    min: 300001,
    max: Number.POSITIVE_INFINITY,
    percentage: 2,
    fixedOnPrevious: 22500, // 7.5% of 3 lakh
    description: "Above ₹3,00,000 @ 2% on excess",
  },
]

const LIMITATION_PERIODS = {
  "money-suit": { period: 3, unit: "years", description: "Money suits (debts, loans)" },
  "breach-contract": { period: 3, unit: "years", description: "Breach of contract" },
  "tort-damages": { period: 3, unit: "years", description: "Tort damages" },
  "property-suit": { period: 12, unit: "years", description: "Property suits" },
  "specific-performance": { period: 3, unit: "years", description: "Specific performance" },
  "cheque-bounce": { period: 3, unit: "years", description: "Cheque bounce (from notice)" },
  "consumer-complaint": { period: 2, unit: "years", description: "Consumer complaints" },
  "recovery-suit": { period: 3, unit: "years", description: "Recovery of money" },
}

const RAJASTHAN_STAMP_DUTY = {
  "sale-deed-male": {
    rate: 6,
    additionalCharges: { registration: 1, labourCess: 20 }, // 20% of stamp duty
    description: "Sale Deed (Male/Urban)",
  },
  "sale-deed-female": {
    rate: 5,
    additionalCharges: { registration: 1, labourCess: 20 },
    description: "Sale Deed (Female/Urban)",
  },
  "sale-deed-rural-male": {
    rate: 5,
    additionalCharges: { registration: 1, labourCess: 20 },
    description: "Sale Deed (Male/Rural)",
  },
  "sale-deed-rural-female": {
    rate: 4,
    additionalCharges: { registration: 1, labourCess: 20 },
    description: "Sale Deed (Female/Rural)",
  },
  "gift-deed": {
    rate: 6,
    additionalCharges: { registration: 2.5 },
    description: "Gift Deed (to father/brother/sister/husband/son)",
  },
  "gift-deed-female": {
    rate: 6,
    additionalCharges: { registration: 0 },
    description: "Gift Deed (to wife/daughter/daughter-in-law/parents 60+)",
  },
  "lease-1year": {
    rate: 4,
    isOnRent: true,
    description: "Lease < 1 year (on annual rent)",
  },
  "lease-1-5year": {
    rate: 8,
    isOnRent: true,
    description: "Lease 1-5 years (on average annual rent)",
  },
  "lease-5-10year": {
    rate: 3,
    isOnRent: true,
    description: "Lease 5-10 years (on average annual rent)",
  },
  "lease-30plus": {
    rate: 6,
    additionalCharges: { registration: 6 },
    description: "Lease > 30 years",
  },
  "partition-deed": {
    rate: 2,
    additionalCharges: { registration: 1 },
    description: "Partition Deed",
  },
  "mortgage-deed": {
    rate: 0.5,
    additionalCharges: { registration: 1 },
    description: "Mortgage Deed",
  },
  "power-attorney": {
    fixed: 100,
    additionalCharges: { registration: 50 },
    description: "Power of Attorney (Fixed)",
  },
  "agreement-to-sell": {
    rate: 0.5,
    minimum: 100,
    additionalCharges: { registration: 1 },
    description: "Agreement to Sell (0.5% or ₹100, whichever higher)",
  },
}

export function LegalCalculators() {
  const [activeTab, setActiveTab] = useState<string>("basic")
  const [activeCalculator, setActiveCalculator] = useState<CalculatorType>(null)

  // Court Fee Calculator State
  const [claimAmount, setClaimAmount] = useState("") // Renamed to suitValue in updates
  const [courtFeeState, setCourtFeeState] = useState("rajasthan")
  const [courtFeeResult, setCourtFeeResult] = useState<{
    totalFee: number
    breakdown: Array<{ slab: string; amount: number }>
  } | null>(null) // Adjusted type

  // Limitation Calculator State
  const [caseType, setCaseType] = useState("")
  const [causeOfActionDate, setCauseOfActionDate] = useState("")
  const [limitationResult, setLimitationResult] = useState<{ lastDate: string; daysRemaining: number } | null>(null)

  // Interest Calculator State
  const [principal, setPrincipal] = useState("")
  const [interestRate, setInterestRate] = useState("")
  const [timePeriod, setTimePeriod] = useState("")
  const [interestResult, setInterestResult] = useState<{ interest: number; total: number } | null>(null)

  // Stamp Duty Calculator State
  const [propertyValue, setPropertyValue] = useState("")
  const [documentType, setDocumentType] = useState("")
  const [stampDutyState, setStampDutyState] = useState("rajasthan")
  const [stampDutyResult, setStampDutyResult] = useState<{
    stampDuty: number
    registration: number
    labourCess: number
    total: number
  } | null>(null)

  // Arbitration Calculator State
  const [arbitrationAmount, setArbitrationAmount] = useState("") // Renamed to disputeAmount in updates
  const [arbitrationType, setArbitrationType] = useState("mcia")
  const [numArbitrators, setNumArbitrators] = useState("sole") // Updated values in updates
  const [arbitrationResult, setArbitrationResult] = useState<{
    filingFee: number
    adminFee: number
    arbitratorFee: number
    totalFee: number // Renamed in updates
    professionalFeeRange: string // Added in updates
  } | null>(null)

  // Section 138 Calculator State
  const [chequeAmount, setChequeAmount] = useState("")
  const [section138State, setSection138State] = useState("rajasthan")
  const [section138Result, setSection138Result] = useState<{ courtFee: number; professionalFeeRange: string } | null>(
    null,
  ) // Added professionalFeeRange

  // Appeal Calculator State
  const [appealType, setAppealType] = useState("first-appeal") // Updated values in updates
  const [decreeFee, setDecreeFee] = useState("") // Renamed to decreeValue in updates
  const [appealState, setAppealState] = useState("rajasthan")
  const [appealFeeResult, setAppealFeeResult] = useState<{ appealFee: number; professionalFeeRange: string } | null>(
    null,
  ) // Renamed and added professionalFeeRange

  // Renamed claimAmount to suitValue for clarity
  const suitValue = claimAmount
  const disputeAmount = arbitrationAmount
  const decreeValue = decreeFee

  const calculateCourtFee = () => {
    const amount = Number.parseFloat(suitValue) // Changed from claimAmount
    if (isNaN(amount) || amount <= 0) return

    let totalFee = 0 // Renamed from fee
    const breakdown: Array<{ slab: string; amount: number }> = [] // New breakdown structure

    for (const slab of RAJASTHAN_COURT_FEE_SLABS) {
      if (amount > slab.min) {
        const amountInSlab = Math.min(amount, slab.max) - slab.min + 1
        const feeInSlab = (amountInSlab * slab.percentage) / 100
        totalFee = slab.fixedOnPrevious + feeInSlab
        breakdown.push({
          slab: slab.description,
          amount: feeInSlab,
        })
        if (amount <= slab.max) break
      }
    }

    setCourtFeeResult({ totalFee: Math.ceil(totalFee), breakdown }) // Updated state name and structure
  }

  const calculateLimitation = () => {
    if (!caseType || !causeOfActionDate) return

    const startDate = new Date(causeOfActionDate)
    const limitation = LIMITATION_PERIODS[caseType as keyof typeof LIMITATION_PERIODS]

    const lastDate = new Date(startDate)
    lastDate.setFullYear(lastDate.getFullYear() + limitation.period)

    const today = new Date()
    const daysRemaining = Math.ceil((lastDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24))

    setLimitationResult({
      lastDate: lastDate.toLocaleDateString("en-IN"),
      daysRemaining,
    })
  }

  const calculateInterest = () => {
    const p = Number.parseFloat(principal)
    const r = Number.parseFloat(interestRate)
    const t = Number.parseFloat(timePeriod)

    if (isNaN(p) || isNaN(r) || isNaN(t)) return

    const interest = (p * r * t) / 100
    const total = p + interest

    setInterestResult({ interest, total })
  }

  const calculateStampDuty = () => {
    const value = Number.parseFloat(propertyValue)
    if (isNaN(value) || !documentType) return

    const duty = RAJASTHAN_STAMP_DUTY[documentType as keyof typeof RAJASTHAN_STAMP_DUTY]
    if (!duty) return

    let stampDuty = 0
    let registration = 0
    let labourCess = 0
    let total = 0

    if ("fixed" in duty) {
      // Fixed amount documents like Power of Attorney
      stampDuty = duty.fixed
      registration = duty.additionalCharges?.registration || 0
      total = stampDuty + registration
    } else {
      // Percentage-based calculations
      const baseRate = duty.rate

      // Calculate stamp duty
      if (duty.minimum && (value * baseRate) / 100 < duty.minimum) {
        stampDuty = duty.minimum
      } else {
        stampDuty = (value * baseRate) / 100
      }

      // Calculate additional charges
      if (duty.additionalCharges) {
        if (duty.additionalCharges.registration) {
          registration = (value * duty.additionalCharges.registration) / 100
        }
        if (duty.additionalCharges.labourCess) {
          // Labour cess is 20% of stamp duty
          labourCess = (stampDuty * duty.additionalCharges.labourCess) / 100
        }
      }

      total = stampDuty + registration + labourCess
    }

    setStampDutyResult({
      stampDuty: Math.ceil(stampDuty),
      registration: Math.ceil(registration),
      labourCess: Math.ceil(labourCess),
      total: Math.ceil(total),
    })
  }

  const calculateSection138 = () => {
    const amount = Number.parseFloat(chequeAmount)
    if (isNaN(amount) || amount <= 0) return

    let courtFee = 0
    let professionalFeeRange = ""

    // Section 138 NI Act court fees are typically much lower than civil suit fees
    // Based on Criminal Procedure Code and state-specific rules
    if (section138State === "rajasthan") {
      // Rajasthan: Criminal complaint fees are nominal
      if (amount <= 100000) {
        courtFee = 200 // Minimum fee
      } else if (amount <= 500000) {
        courtFee = 500
      } else if (amount <= 1000000) {
        courtFee = 1000
      } else {
        courtFee = 2000
      }
      professionalFeeRange = "₹10,000 - ₹50,000"
    } else if (section138State === "delhi") {
      // Delhi has slightly higher fees but still criminal in nature
      if (amount <= 100000) {
        courtFee = 500
      } else if (amount <= 500000) {
        courtFee = 1000
      } else if (amount <= 1000000) {
        courtFee = 2000
      } else {
        courtFee = 5000
      }
      professionalFeeRange = "₹15,000 - ₹75,000"
    } else {
      // Maharashtra
      if (amount <= 100000) {
        courtFee = 300
      } else if (amount <= 500000) {
        courtFee = 750
      } else if (amount <= 1000000) {
        courtFee = 1500
      } else {
        courtFee = 3000
      }
      professionalFeeRange = "₹12,000 - ₹60,000"
    }

    setSection138Result({ courtFee: Math.ceil(courtFee), professionalFeeRange })
  }

  // Renamed calculateAppeal to calculateAppealFee, updated logic and state names
  const calculateAppealFee = () => {
    const amount = Number.parseFloat(decreeValue) // Changed from decreeFee
    if (isNaN(amount) || amount <= 0) return

    let appealFee = 0
    let professionalFeeRange = ""

    // Appeal fees are typically 50% of original court fee for first appeal
    if (appealState === "rajasthan") {
      if (amount <= 300000) {
        appealFee = (amount * 7.5) / 100 / 2 // 50% of original court fee
      } else {
        appealFee = (22500 + ((amount - 300000) * 2) / 100) / 2
      }
      professionalFeeRange =
        appealType === "first-appeal" // Updated enum values
          ? "₹20,000 - ₹1,00,000"
          : appealType === "second-appeal" // Updated enum values
            ? "₹50,000 - ₹2,50,000"
            : "₹5,000 - ₹25,000"
    } else if (appealState === "delhi") {
      appealFee = (amount * 3) / 100 // Approximate 3% for appeals
      professionalFeeRange =
        appealType === "first-appeal" // Updated enum values
          ? "₹25,000 - ₹1,50,000"
          : appealType === "second-appeal" // Updated enum values
            ? "₹75,000 - ₹3,00,000"
            : "₹7,500 - ₹35,000"
    } else {
      appealFee = (amount * 3.5) / 100
      professionalFeeRange =
        appealType === "first-appeal" // Updated enum values
          ? "₹22,000 - ₹1,25,000"
          : appealType === "second-appeal" // Updated enum values
            ? "₹60,000 - ₹2,75,000"
            : "₹6,000 - ₹30,000"
    }

    // Second appeal is typically lower
    if (appealType === "second-appeal") {
      // Updated enum value
      appealFee = appealFee * 0.6
    }
    // Miscellaneous appeal has fixed lower fees
    if (appealType === "misc-appeal") {
      // Updated enum value
      appealFee = Math.min(appealFee, 5000)
    }

    setAppealFeeResult({ appealFee: Math.ceil(appealFee), professionalFeeRange })
  }

  const calculateArbitrationFee = () => {
    const amount = Number.parseFloat(disputeAmount) // Changed from arbitrationAmount
    if (isNaN(amount) || amount <= 0) return

    // MCIA Schedule 2025
    const filingFee = 50000
    let adminFee = 0
    let arbitratorFee = 0
    let professionalFeeRange = ""

    // MCIA Administration Fee Structure
    if (amount <= 1000000) {
      adminFee = 110000
      arbitratorFee = numArbitrators === "sole" ? 112500 : 270000 // Updated numArbitrators values
      professionalFeeRange = "₹50,000 - ₹2,00,000"
    } else if (amount <= 5000000) {
      adminFee = 110000 + ((amount - 1000000) * 10) / 100
      arbitratorFee = numArbitrators === "sole" ? 225000 : 540000 // Updated numArbitrators values
      professionalFeeRange = "₹1,00,000 - ₹5,00,000"
    } else if (amount <= 10000000) {
      adminFee = 510000 + ((amount - 5000000) * 8) / 100
      arbitratorFee = numArbitrators === "sole" ? 450000 : 1080000 // Updated numArbitrators values
      professionalFeeRange = "₹2,00,000 - ₹10,00,000"
    } else if (amount <= 50000000) {
      adminFee = 910000 + ((amount - 10000000) * 6) / 100
      arbitratorFee = numArbitrators === "sole" ? 900000 : 2160000 // Updated numArbitrators values
      professionalFeeRange = "₹5,00,000 - ₹25,00,000"
    } else {
      adminFee = Math.min(3310000 + ((amount - 50000000) * 4) / 100, 5000000)
      arbitratorFee = numArbitrators === "sole" ? 1800000 : 4320000 // Updated numArbitrators values
      professionalFeeRange = "₹10,00,000 - ₹50,00,000+"
    }

    const totalFee = filingFee + adminFee + arbitratorFee

    setArbitrationResult({
      // Updated state name
      filingFee,
      adminFee: Math.ceil(adminFee),
      arbitratorFee: Math.ceil(arbitratorFee),
      totalFee: Math.ceil(totalFee),
      professionalFeeRange,
    })
  }

  return (
    <div className="space-y-8">
      <Alert className="bg-amber-50 border-amber-200">
        <AlertCircle className="h-4 w-4 text-amber-600" />
        <AlertDescription className="text-amber-800">
          <strong>Important Disclaimer:</strong> These calculators provide approximate estimates based on available
          information for 2024-2025. Actual fees and rates may vary.{" "}
          <strong>Always verify with official sources.</strong>
        </AlertDescription>
      </Alert>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2 lg:grid-cols-3">
          <TabsTrigger value="basic">Basic Calculators</TabsTrigger>
          <TabsTrigger value="specialized">Specialized Calculators</TabsTrigger>
          <TabsTrigger value="appeals">Appeals & ADR</TabsTrigger>
        </TabsList>

        <TabsContent value="basic" className="space-y-6 mt-6">
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Button
              variant={activeCalculator === "court-fee" ? "default" : "outline"}
              onClick={() => setActiveCalculator("court-fee")}
              className="h-auto py-4 flex-col items-start gap-2"
            >
              <Scale className="h-6 w-6" />
              <div className="text-left">
                <div className="font-semibold">Court Fee</div>
                <div className="text-xs opacity-80">Calculate filing fees</div>
              </div>
            </Button>

            <Button
              variant={activeCalculator === "limitation" ? "default" : "outline"}
              onClick={() => setActiveCalculator("limitation")}
              className="h-auto py-4 flex-col items-start gap-2"
            >
              <FileText className="h-6 w-6" />
              <div className="text-left">
                <div className="font-semibold">Limitation Period</div>
                <div className="text-xs opacity-80">Check time limits</div>
              </div>
            </Button>

            <Button
              variant={activeCalculator === "interest" ? "default" : "outline"}
              onClick={() => setActiveCalculator("interest")}
              className="h-auto py-4 flex-col items-start gap-2"
            >
              <TrendingUp className="h-6 w-6" />
              <div className="text-left">
                <div className="font-semibold">Interest</div>
                <div className="text-xs opacity-80">Calculate interest</div>
              </div>
            </Button>

            <Button
              variant={activeCalculator === "stamp-duty" ? "default" : "outline"}
              onClick={() => setActiveCalculator("stamp-duty")}
              className="h-auto py-4 flex-col items-start gap-2"
            >
              <Calculator className="h-6 w-6" />
              <div className="text-left">
                <div className="font-semibold">Stamp Duty</div>
                <div className="text-xs opacity-80">Calculate duty</div>
              </div>
            </Button>
          </div>

          {activeCalculator === "court-fee" && (
            <Card>
              <CardHeader>
                <CardTitle>Court Fee Calculator (Rajasthan)</CardTitle>
                <CardDescription>
                  Calculate ad valorem court fees for filing civil suits based on claim amount (as per Rajasthan Court
                  Fees Act, 1961)
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="state">State</Label>
                  <Select value={courtFeeState} onValueChange={setCourtFeeState}>
                    <SelectTrigger id="state">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="rajasthan">Rajasthan *</SelectItem>
                      <SelectItem value="delhi">Delhi (Coming Soon)</SelectItem>
                      <SelectItem value="maharashtra">Maharashtra (Coming Soon)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="claim-amount">Suit/Claim Valuation (₹)</Label> {/* Changed label */}
                  <Input
                    id="claim-amount"
                    type="number"
                    placeholder="Enter claim/suit valuation"
                    value={suitValue} // Used renamed state variable
                    onChange={(e) => setClaimAmount(e.target.value)} // Still update original state for consistency
                  />
                  <p className="text-xs text-muted-foreground">
                    Enter the total value of the suit/claim as per market value or relief sought
                  </p>
                </div>

                <Button onClick={calculateCourtFee} className="w-full">
                  <Calculator className="mr-2 h-4 w-4" />
                  Calculate Court Fee
                </Button>

                {courtFeeResult !== null && (
                  // Updated court fee result display
                  <Alert className="bg-blue-50 border-blue-200">
                    <Gavel className="h-4 w-4 text-blue-600" />
                    <AlertDescription>
                      <div className="space-y-3">
                        <div>
                          <div className="font-semibold text-blue-800">Total Court Fee</div>
                          <div className="text-3xl font-bold text-blue-900">
                            {formatAmountWithWords(courtFeeResult.totalFee)}
                          </div>
                        </div>
                        <div className="text-xs space-y-1 text-blue-700">
                          <div className="font-semibold">Breakdown:</div>
                          {courtFeeResult.breakdown.map((item, idx) => (
                            <div key={idx} className="flex justify-between">
                              <span>{item.slab}</span>
                              <span className="font-mono">₹{Math.ceil(item.amount).toLocaleString("en-IN")}</span>
                            </div>
                          ))}
                        </div>
                        <div className="pt-2 border-t border-blue-200">
                          <div className="text-xs text-blue-700">
                            <span className="font-semibold">Professional Fee Range:</span> ₹10,000 - ₹1,00,000
                            <br />
                            <span className="text-[10px] italic">
                              (Varies by case complexity, advocate experience, and court level)
                            </span>
                          </div>
                        </div>
                      </div>
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>
          )}

          {activeCalculator === "limitation" && (
            <Card>
              <CardHeader>
                <CardTitle>Limitation Period Calculator</CardTitle>
                <CardDescription>Calculate the last date to file a case based on Limitation Act, 1963</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="case-type">Type of Case</Label>
                  <Select value={caseType} onValueChange={setCaseType}>
                    <SelectTrigger id="case-type">
                      <SelectValue placeholder="Select case type" />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(LIMITATION_PERIODS).map(([key, value]) => (
                        <SelectItem key={key} value={key}>
                          {value.description} ({value.period} {value.unit})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="cause-date">Cause of Action Date</Label>
                  <Input
                    id="cause-date"
                    type="date"
                    value={causeOfActionDate}
                    onChange={(e) => setCauseOfActionDate(e.target.value)}
                  />
                </div>

                <Button onClick={calculateLimitation} className="w-full">
                  Calculate Limitation
                </Button>

                {limitationResult && (
                  <Alert
                    className={
                      limitationResult.daysRemaining > 0 ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200"
                    }
                  >
                    <FileText
                      className={`h-4 w-4 ${limitationResult.daysRemaining > 0 ? "text-green-600" : "text-red-600"}`}
                    />
                    <AlertDescription>
                      <div
                        className={`font-semibold mb-1 ${limitationResult.daysRemaining > 0 ? "text-green-800" : "text-red-800"}`}
                      >
                        Last Date to File: {limitationResult.lastDate}
                      </div>
                      <div
                        className={`text-2xl font-bold ${limitationResult.daysRemaining > 0 ? "text-green-900" : "text-red-900"}`}
                      >
                        {limitationResult.daysRemaining > 0
                          ? `${limitationResult.daysRemaining} days remaining`
                          : "Time Barred"}
                      </div>
                      <div
                        className={`text-xs mt-2 ${limitationResult.daysRemaining > 0 ? "text-green-700" : "text-red-700"}`}
                      >
                        * As per Limitation Act, 1963. Consult for condonation of delay if applicable.
                      </div>
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>
          )}

          {activeCalculator === "interest" && (
            <Card>
              <CardHeader>
                <CardTitle>Simple Interest Calculator</CardTitle>
                <CardDescription>Calculate interest on principal amount</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="principal">Principal Amount (₹)</Label>
                  <Input
                    id="principal"
                    type="number"
                    placeholder="Enter principal amount"
                    value={principal}
                    onChange={(e) => setPrincipal(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="rate">Interest Rate (% per annum)</Label>
                  <Input
                    id="rate"
                    type="number"
                    step="0.01"
                    placeholder="Enter interest rate"
                    value={interestRate}
                    onChange={(e) => setInterestRate(e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground">
                    Common rates: 9% (Court decrees), 18% (Section 138 NI Act)
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="time">Time Period (years)</Label>
                  <Input
                    id="time"
                    type="number"
                    step="0.1"
                    placeholder="Enter time period"
                    value={timePeriod}
                    onChange={(e) => setTimePeriod(e.target.value)}
                  />
                </div>

                <Button onClick={calculateInterest} className="w-full">
                  <Calculator className="mr-2 h-4 w-4" />
                  Calculate Interest
                </Button>

                {interestResult !== null && (
                  <Alert className="bg-green-50 border-green-200">
                    <TrendingUp className="h-4 w-4 text-green-600" />
                    <AlertDescription>
                      <div className="space-y-2">
                        <div className="font-semibold text-green-800">Interest Calculation Result</div>
                        <div className="space-y-1">
                          <div className="text-sm">
                            Principal: <strong>{formatAmountWithWords(Number.parseFloat(principal))}</strong>
                          </div>
                          <div className="text-sm">
                            Interest ({interestRate}% for {timePeriod} years):{" "}
                            <strong>{formatAmountWithWords(interestResult.interest)}</strong>
                          </div>
                          <div className="text-xl font-bold text-green-900 pt-2 border-t border-green-200">
                            Total Amount: {formatAmountWithWords(interestResult.total)}
                          </div>
                        </div>
                      </div>
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>
          )}

          {activeCalculator === "stamp-duty" && (
            <Card>
              <CardHeader>
                <CardTitle>Stamp Duty Calculator (Rajasthan)</CardTitle>
                <CardDescription>Calculate stamp duty for property and document registration</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="duty-state">State</Label>
                  <Select value={stampDutyState} onValueChange={setStampDutyState}>
                    <SelectTrigger id="duty-state">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="rajasthan">Rajasthan *</SelectItem>
                      <SelectItem value="delhi">Delhi (Coming Soon)</SelectItem>
                      <SelectItem value="maharashtra">Maharashtra (Coming Soon)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="doc-type">Document Type</Label>
                  <Select value={documentType} onValueChange={setDocumentType}>
                    <SelectTrigger id="doc-type">
                      <SelectValue placeholder="Select document type" />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(RAJASTHAN_STAMP_DUTY).map(([key, value]) => (
                        <SelectItem key={key} value={key}>
                          {value.description}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="property-value">Property/Document Value (₹)</Label>
                  <Input
                    id="property-value"
                    type="number"
                    placeholder="Enter property or document value"
                    value={propertyValue}
                    onChange={(e) => setPropertyValue(e.target.value)}
                    disabled={documentType === "power-attorney"}
                  />
                </div>

                <Button onClick={calculateStampDuty} className="w-full">
                  <Calculator className="mr-2 h-4 w-4" />
                  Calculate Stamp Duty
                </Button>

                {stampDutyResult !== null && (
                  <div className="space-y-3">
                    <Alert className="bg-green-50 border-green-200">
                      <Calculator className="h-4 w-4 text-green-600" />
                      <AlertDescription>
                        <div className="space-y-2">
                          <div className="font-semibold text-green-800">Stamp Duty Breakdown</div>
                          <div className="space-y-1 text-sm">
                            <div className="flex justify-between">
                              <span>Stamp Duty:</span>
                              <strong>{formatAmountWithWords(stampDutyResult.stampDuty)}</strong>
                            </div>
                            {stampDutyResult.registration > 0 && (
                              <div className="flex justify-between">
                                <span>Registration Fee:</span>
                                <strong>{formatAmountWithWords(stampDutyResult.registration)}</strong>
                              </div>
                            )}
                            {stampDutyResult.labourCess > 0 && (
                              <div className="flex justify-between">
                                <span>Labour Cess (20% of stamp duty):</span>
                                <strong>{formatAmountWithWords(stampDutyResult.labourCess)}</strong>
                              </div>
                            )}
                          </div>
                          <div className="text-2xl font-bold text-green-900 pt-2 border-t border-green-200">
                            Total: {formatAmountWithWords(stampDutyResult.total)}
                          </div>
                        </div>
                      </AlertDescription>
                    </Alert>

                    <Alert className="bg-amber-50 border-amber-200">
                      <AlertCircle className="h-4 w-4 text-amber-600" />
                      <AlertDescription className="text-xs text-amber-800">
                        <strong>*Please verify:</strong> This is an approximate calculation based on general slab
                        structure. Actual court fees depend on the specific nature of suit, relief sought, and current
                        schedules under Rajasthan Court Fees Act, 1961. Additional fees may apply for appeals,
                        revisions, or special applications. Consult court office or legal counsel for exact fees before
                        filing.
                      </AlertDescription>
                    </Alert>

                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-xs text-blue-800">
                      <strong>Note:</strong> Fixed fees apply for specific applications (e.g., Misc. Application: ₹10,
                      Execution Petition: ₹10, Marriage Act cases: ₹25). This calculator is for ad valorem civil suits.
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="specialized" className="space-y-6 mt-6">
          <div className="grid gap-6 w-full pb-8">
            <Card className="cursor-pointer hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start gap-3">
                  <Shield className="h-6 w-6 text-primary mt-1" />
                  <div>
                    <CardTitle className="text-lg">Section 138 NI Act</CardTitle>
                    <CardDescription>Cheque bounce case court fees</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="s138-state">State</Label>
                  <Select value={section138State} onValueChange={setSection138State}>
                    <SelectTrigger id="s138-state">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="rajasthan">Rajasthan</SelectItem>
                      <SelectItem value="delhi">Delhi *</SelectItem>
                      <SelectItem value="maharashtra">Maharashtra</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="cheque-amount">Dishonored Cheque Amount (₹)</Label>
                  <Input
                    id="cheque-amount"
                    type="number"
                    placeholder="Enter cheque amount"
                    value={chequeAmount}
                    onChange={(e) => setChequeAmount(e.target.value)}
                  />
                </div>

                <Button onClick={calculateSection138} className="w-full">
                  <Calculator className="mr-2 h-4 w-4" />
                  Calculate Section 138 Court Fee
                </Button>

                {section138Result !== null && (
                  <Alert className="bg-green-50 border-green-200">
                    <Gavel className="h-4 w-4 text-green-600" />
                    <AlertDescription>
                      <div className="space-y-2">
                        <div className="font-semibold text-green-800">Estimated Court Fee (Section 138 NI Act)</div>
                        <div className="text-3xl font-bold text-green-900">
                          {formatAmountWithWords(section138Result.courtFee)}
                        </div>
                        <div className="text-xs text-green-700">
                          For cheque amount: {formatAmountWithWords(Number.parseFloat(chequeAmount))}
                        </div>
                        <div className="pt-2 border-t border-green-200">
                          <div className="text-xs text-green-700">
                            <span className="font-semibold">Professional Fee Range:</span>{" "}
                            {section138Result.professionalFeeRange}
                            <br />
                            <span className="text-[10px] italic">(For complete case handling including drafting)</span>
                          </div>
                        </div>
                      </div>
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="appeals" className="space-y-6 mt-6">
          <div className="grid sm:grid-cols-2 gap-4">
            <Card className="cursor-pointer hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start gap-3">
                  <Gavel className="h-6 w-6 text-primary mt-1" />
                  <div>
                    <CardTitle className="text-lg">Appeal Fee Calculator</CardTitle>
                    <CardDescription>First/Second/Miscellaneous Appeals</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="appeal-type">Appeal Type</Label>
                  <Select value={appealType} onValueChange={setAppealType}>
                    <SelectTrigger id="appeal-type">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="first-appeal">First Appeal (RFA)</SelectItem>
                      <SelectItem value="second-appeal">Second Appeal (RSA)</SelectItem>
                      <SelectItem value="misc-appeal">Miscellaneous Appeal</SelectItem>
                      <SelectItem value="review-petition">Review Petition</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="decree-fee">Original Decree Value (₹)</Label> {/* Changed label */}
                  <Input
                    id="decree-fee"
                    type="number"
                    placeholder="Enter original decree/order value"
                    value={decreeValue} // Used renamed state variable
                    onChange={(e) => setDecreeFee(e.target.value)} // Still update original state for consistency
                  />
                  <p className="text-xs text-muted-foreground">Enter the value as per the decree sheet or order</p>
                </div>

                <Button onClick={calculateAppealFee} className="w-full">
                  {" "}
                  {/* Changed function call */}
                  <Calculator className="mr-2 h-4 w-4" />
                  Calculate Appeal Fee
                </Button>

                {appealFeeResult !== null && (
                  <Alert className="bg-purple-50 border-purple-200">
                    <Scale className="h-4 w-4 text-purple-600" />
                    <AlertDescription>
                      <div className="space-y-2">
                        <div className="font-semibold text-purple-800">Estimated Appeal Court Fee</div>
                        <div className="text-3xl font-bold text-purple-900">
                          {formatAmountWithWords(appealFeeResult.appealFee)}
                        </div>
                        <div className="text-xs text-purple-700">
                          For decree/order value: {formatAmountWithWords(Number.parseFloat(decreeValue))}
                        </div>
                        <div className="pt-2 border-t border-purple-200">
                          <div className="text-xs text-purple-700">
                            <span className="font-semibold">Professional Fee Range:</span>{" "}
                            {appealFeeResult.professionalFeeRange}
                            <br />
                            <span className="text-[10px] italic">
                              (Includes drafting grounds of appeal & arguments)
                            </span>
                          </div>
                        </div>
                      </div>
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>

            <Card className="cursor-pointer hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start gap-3">
                  <Users className="h-6 w-6 text-primary mt-1" />
                  <div>
                    <CardTitle className="text-lg">Arbitration Fee Calculator</CardTitle>
                    <CardDescription>MCIA/DIAC institutional arbitration</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="arb-type">Institution</Label>
                  <Select value={arbitrationType} onValueChange={setArbitrationType}>
                    <SelectTrigger id="arb-type">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="mcia">MCIA (Mumbai Centre)</SelectItem>
                      <SelectItem value="diac">DIAC (Delhi Centre)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="arb-amount">Sum in Dispute (₹)</Label>
                  <Input
                    id="arb-amount"
                    type="number"
                    placeholder="Enter dispute amount"
                    value={disputeAmount} // Used renamed state variable
                    onChange={(e) => setArbitrationAmount(e.target.value)} // Still update original state for consistency
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="num-arbitrators">Number of Arbitrators</Label>
                  <Select value={numArbitrators} onValueChange={setNumArbitrators}>
                    <SelectTrigger id="num-arbitrators">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="sole">Sole Arbitrator</SelectItem> {/* Updated values */}
                      <SelectItem value="three">Panel of Three</SelectItem> {/* Updated values */}
                    </SelectContent>
                  </Select>
                </div>

                <Button onClick={calculateArbitrationFee} className="w-full">
                  {" "}
                  {/* Changed function call */}
                  <Calculator className="mr-2 h-4 w-4" />
                  Calculate Arbitration Fees
                </Button>

                {arbitrationResult !== null && (
                  <Alert className="bg-amber-50 border-amber-200">
                    <Scale className="h-4 w-4 text-amber-600" />
                    <AlertDescription>
                      <div className="space-y-3">
                        <div>
                          <div className="font-semibold text-amber-800">Total Estimated Arbitration Cost</div>
                          <div className="text-3xl font-bold text-amber-900">
                            {formatAmountWithWords(arbitrationResult.totalFee)}
                          </div>
                        </div>
                        <div className="text-xs space-y-1 text-amber-700">
                          <div className="font-semibold">Breakdown:</div>
                          <div className="flex justify-between">
                            <span>Filing Fee</span>
                            <span className="font-mono">₹{arbitrationResult.filingFee.toLocaleString("en-IN")}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Administration Fee</span>
                            <span className="font-mono">₹{arbitrationResult.adminFee.toLocaleString("en-IN")}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Arbitrator Fee ({numArbitrators === "sole" ? "Sole" : "3 Arbitrators"})</span>{" "}
                            {/* Updated condition */}
                            <span className="font-mono">
                              ₹{arbitrationResult.arbitratorFee.toLocaleString("en-IN")}
                            </span>
                          </div>
                        </div>
                        <div className="pt-2 border-t border-amber-200">
                          <div className="text-xs text-amber-700">
                            <span className="font-semibold">Professional Fee Range:</span>{" "}
                            {arbitrationResult.professionalFeeRange}
                            <br />
                            <span className="text-[10px] italic">
                              (Legal representation fees separate from institutional costs)
                            </span>
                          </div>
                        </div>
                      </div>
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
