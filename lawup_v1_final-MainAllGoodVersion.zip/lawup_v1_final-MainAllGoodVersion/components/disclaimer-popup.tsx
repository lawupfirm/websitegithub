"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { X, Phone } from "lucide-react"

export function DisclaimerPopup() {
  const [showDisclaimer, setShowDisclaimer] = useState(false)
  const [showContactPopup, setShowContactPopup] = useState(false)

  useEffect(() => {
    const hasAgreed = sessionStorage.getItem("lawup-disclaimer-agreed")
    if (!hasAgreed) {
      setShowDisclaimer(true)
    }
  }, [])

  const handleAgree = () => {
    sessionStorage.setItem("lawup-disclaimer-agreed", "true")
    setShowDisclaimer(false)
    setTimeout(() => {
      const hasSeenContactPopup = sessionStorage.getItem("lawup-contact-popup-seen")
      if (!hasSeenContactPopup) {
        setShowContactPopup(true)
      }
    }, 500)
  }

  const handleCloseContactPopup = () => {
    sessionStorage.setItem("lawup-contact-popup-seen", "true")
    setShowContactPopup(false)
  }

  return (
    <>
      {/* Disclaimer Popup */}
      {showDisclaimer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />

          <Card className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl">
            <CardContent className="p-8">
              <h2 className="text-2xl font-bold text-primary mb-6 text-center">Important Legal Disclaimer</h2>

              <div className="space-y-4 text-sm leading-relaxed text-muted-foreground mb-8">
                <p>
                  As per the rules of the Bar Council of India, LawUp & its associates & affiliates (the 'Firm') is
                  prohibited from soliciting work or advertising. By clicking on the 'I Agree' button below and
                  accessing this website (www.lawup.in), the User acknowledges the following:
                </p>

                <ul className="space-y-3 list-disc pl-6">
                  <li>
                    The User is seeking information relating to LawUp & its associates & affiliates of his/her/its own
                    accord and that there has been no form of solicitation, advertisement or inducement by LawUp & its
                    associates & affiliates or any of its members;
                  </li>
                  <li>This website does not seek to create or invite any lawyer–client relationship;</li>
                  <li>No material/information provided on this website should be construed as legal advice;</li>
                  <li>
                    LawUp & its associates & affiliates shall not be liable for consequences arising out of any action
                    taken by the User relying on material/information provided on this website; and
                  </li>
                  <li>
                    In cases where the User has any legal issues, he/she/it must in all cases seek independent legal
                    advice.
                  </li>
                </ul>
              </div>

              <div className="text-center">
                <Button
                  onClick={handleAgree}
                  className="px-8 py-3 text-lg font-semibold bg-primary hover:bg-primary/90"
                >
                  I Agree
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Contact Now Popup - appears after disclaimer */}
      {showContactPopup && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={handleCloseContactPopup} />

          <Card className="relative w-full max-w-md shadow-2xl animate-in fade-in zoom-in duration-300">
            <CardContent className="p-8">
              <button
                onClick={handleCloseContactPopup}
                className="absolute top-4 right-4 p-2 rounded-full hover:bg-secondary transition-colors"
                aria-label="Close"
              >
                <X className="h-5 w-5 text-muted-foreground" />
              </button>

              <div className="text-center">
                <div className="inline-flex p-4 bg-accent/10 rounded-full mb-4 animate-pulse-glow">
                  <Phone className="h-12 w-12 text-accent animate-ring" />
                </div>

                <h3 className="text-2xl font-bold text-primary mb-2">Need Legal Assistance?</h3>
                <p className="text-muted-foreground mb-6">Connect with our expert legal team right away</p>

                <a
                  href="tel:+919716968000"
                  className="inline-flex items-center gap-3 px-8 py-4 bg-accent hover:bg-accent/90 text-accent-foreground rounded-full font-bold text-xl transition-all hover:scale-105 animate-pulse shadow-lg shadow-accent/50"
                >
                  <Phone className="h-6 w-6" />
                  <span className="animate-flashing">+91 97169 68000</span>
                </a>

                <p className="text-xs text-muted-foreground mt-6">Available 24/7 for urgent legal matters</p>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </>
  )
}
