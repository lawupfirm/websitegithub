"use client"

import { ScrollReveal } from "@/components/scroll-reveal"
import { Star, Quote } from "lucide-react"
import { useState } from "react"

const testimonials = [
  {
    name: "Rajesh Sharma",
    role: "Business Owner",
    company: "Mumbai",
    content:
      "LawUp Consulting provided exceptional legal guidance for our corporate restructuring. Their expertise and professionalism exceeded our expectations. Highly recommended!",
    rating: 5,
  },
  {
    name: "Priya Patel",
    role: "Real Estate Developer",
    company: "Ahmedabad",
    content:
      "Outstanding RERA compliance support. The team's attention to detail and proactive approach saved us from potential legal issues. True professionals!",
    rating: 5,
  },
  {
    name: "Amit Verma",
    role: "Tech Entrepreneur",
    company: "Bangalore",
    content:
      "From IP protection to contract negotiations, LawUp has been our trusted legal partner. Their strategic advice has been invaluable for our startup's growth.",
    rating: 5,
  },
  {
    name: "Meera Iyer",
    role: "Family Client",
    company: "Chennai",
    content:
      "Compassionate and effective representation during a difficult family matter. The team was always responsive and kept me informed throughout the process.",
    rating: 5,
  },
  {
    name: "Vikram Singh",
    role: "Manufacturing Executive",
    company: "Delhi",
    content:
      "Excellent labour law advisory services. LawUp helped us navigate complex employment regulations and maintain compliance across multiple facilities.",
    rating: 5,
  },
  {
    name: "Anita Desai",
    role: "Property Owner",
    company: "Pune",
    content:
      "Successfully resolved a long-standing property dispute with their expert litigation support. Professional, knowledgeable, and results-oriented.",
    rating: 5,
  },
]

export function TestimonialsSection() {
  const [activeIndex, setActiveIndex] = useState(0)

  return (
    <section className="py-16 sm:py-24 lg:py-32 bg-primary text-primary-foreground overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <ScrollReveal>
          <div className="text-center mb-12 sm:mb-16">
            <span className="inline-flex items-center gap-2 text-accent text-xs sm:text-sm font-medium tracking-widest uppercase mb-3 sm:mb-4">
              <span className="w-6 sm:w-8 h-px bg-accent" />
              Client Testimonials
              <span className="w-6 sm:w-8 h-px bg-accent" />
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold mb-3 sm:mb-4">What Our Clients Say</h2>
            <p className="text-base sm:text-lg text-primary-foreground/80 max-w-2xl mx-auto px-4">
              Real experiences from clients who trusted us with their legal matters
            </p>
          </div>
        </ScrollReveal>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {testimonials.map((testimonial, index) => (
            <ScrollReveal key={index} delay={index * 100}>
              <div className="bg-primary-foreground/5 backdrop-blur-sm p-6 sm:p-8 rounded-2xl border border-primary-foreground/10 hover:border-accent/50 transition-all duration-300 hover:-translate-y-1">
                {/* Quote Icon */}
                <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-accent/20 flex items-center justify-center mb-4 sm:mb-6">
                  <Quote className="w-5 h-5 sm:w-6 sm:h-6 text-accent" />
                </div>

                {/* Rating */}
                <div className="flex gap-1 mb-4">
                  {Array.from({ length: testimonial.rating }).map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-accent text-accent" />
                  ))}
                </div>

                {/* Content */}
                <p className="text-sm sm:text-base text-primary-foreground/90 mb-6 leading-relaxed">
                  "{testimonial.content}"
                </p>

                {/* Author */}
                <div className="pt-4 border-t border-primary-foreground/10">
                  <div className="font-semibold text-primary-foreground text-sm sm:text-base">{testimonial.name}</div>
                  <div className="text-xs sm:text-sm text-primary-foreground/60">
                    {testimonial.role} • {testimonial.company}
                  </div>
                </div>
              </div>
            </ScrollReveal>
          ))}
        </div>
      </div>
    </section>
  )
}
