import Link from "next/link"
import Image from "next/image"
import { MapPin, Phone, Mail, Linkedin, Scale, ArrowRight } from "lucide-react"

export function Footer() {
  const currentYear = new Date().getFullYear()

  const footerLinks = {
    practice: [
      { label: "Litigation", href: "/practice-areas#litigation" },
      { label: "Corporate Law", href: "/practice-areas#corporate" },
      { label: "Banking & Finance", href: "/practice-areas#banking" },
      { label: "Cyber Law", href: "/practice-areas#cyber" },
      { label: "Labour Law", href: "/practice-areas#labour" },
      { label: "Real Estate & RERA", href: "/practice-areas#real-estate" },
      { label: "Consumer Rights", href: "/practice-areas#consumer-rights" },
      { label: "Family Law", href: "/practice-areas#family-law" },
      { label: "Intellectual Property", href: "/practice-areas#intellectual-property" }, // Added Intellectual Property to footer practice areas
    ],
    company: [
      { label: "About Us", href: "/about" },
      { label: "Our Team", href: "/team" },
      { label: "Insights", href: "/insights" },
      { label: "Legal Guide", href: "/legal-guide" },
      { label: "Careers", href: "/careers" },
      { label: "Contact", href: "/contact" },
    ],
    legal: [
      { label: "Privacy Policy", href: "/privacy" },
      { label: "Terms of Service", href: "/terms" },
      { label: "Disclaimer", href: "/disclaimer" },
    ],
  }

  return (
    <footer className="bg-primary text-primary-foreground">
      {/* Main Footer - Adjusted padding and grid for mobile */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 lg:py-20">
        <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-12 gap-8 lg:gap-12">
          {/* Brand Column - Full width on mobile */}
          <div className="col-span-2 sm:col-span-2 lg:col-span-4">
            <Link href="/" className="flex items-center gap-3 mb-4 sm:mb-6">
              <div className="relative w-14 h-14 sm:w-16 sm:h-16 flex-shrink-0 rounded-full overflow-hidden border-2 border-accent/30 hover:border-accent transition-colors bg-primary/5">
                <Image
                  src="/images/lawup-logo.jpg"
                  alt="LawUp Consulting Logo"
                  fill
                  className="object-cover"
                />
              </div>
              <div>
                <span className="font-serif text-xl sm:text-2xl font-bold">LawUp</span>
                <div className="text-[10px] uppercase tracking-[0.2em] text-primary-foreground/60">Consulting</div>
              </div>
            </Link>

            <p className="text-primary-foreground/70 text-sm leading-relaxed mb-4 sm:mb-6 max-w-sm">
              Premier legal services delivering strategic counsel with unwavering commitment to integrity and client
              success across India.
            </p>

            {/* Contact Info */}
            <div className="space-y-2 sm:space-y-3">
              <a
                href="tel:+919716968000"
                className="flex items-center gap-3 text-sm text-primary-foreground/70 hover:text-accent transition-colors"
              >
                <Phone className="h-4 w-4 text-accent flex-shrink-0" />
                +91-9716968000
              </a>
              <a
                href="mailto:support@lawup.in"
                className="flex items-center gap-3 text-sm text-primary-foreground/70 hover:text-accent transition-colors"
              >
                <Mail className="h-4 w-4 text-accent flex-shrink-0" />
                support@lawup.in
              </a>
              <div className="flex items-start gap-3 text-sm text-primary-foreground/70">
                <MapPin className="h-4 w-4 text-accent flex-shrink-0 mt-0.5" />
                <span className="text-xs sm:text-sm">
                  Chamber: Ground B188a, Jamunapuri, Jaipur, Rajasthan - 302039
                </span>
              </div>
              <a
                href="https://razorpay.me/@lawup"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-4 py-2 mt-4 bg-accent hover:bg-accent/90 text-accent-foreground rounded-lg transition-colors text-sm font-medium"
              >
                <span>💳 Pay Now</span>
              </a>
            </div>
          </div>

          {/* Practice Areas - Better column distribution */}
          <div className="col-span-1 lg:col-span-2 lg:col-start-6">
            <h4 className="font-serif text-base sm:text-lg font-semibold mb-4 sm:mb-6">Practice Areas</h4>
            <ul className="space-y-2 sm:space-y-3">
              {footerLinks.practice.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-xs sm:text-sm text-primary-foreground/70 hover:text-accent transition-colors inline-flex items-center group"
                  >
                    {link.label}
                    <ArrowRight className="h-3 w-3 ml-1 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all" />
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div className="col-span-1 lg:col-span-2">
            <h4 className="font-serif text-base sm:text-lg font-semibold mb-4 sm:mb-6">Company</h4>
            <ul className="space-y-2 sm:space-y-3">
              {footerLinks.company.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-xs sm:text-sm text-primary-foreground/70 hover:text-accent transition-colors inline-flex items-center group"
                  >
                    {link.label}
                    <ArrowRight className="h-3 w-3 ml-1 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all" />
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal & Social - Full width on small mobile */}
          <div className="col-span-2 sm:col-span-1 lg:col-span-2">
            <h4 className="font-serif text-base sm:text-lg font-semibold mb-4 sm:mb-6">Legal</h4>
            <ul className="space-y-2 sm:space-y-3 mb-6 sm:mb-8">
              {footerLinks.legal.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-xs sm:text-sm text-primary-foreground/70 hover:text-accent transition-colors inline-flex items-center group"
                  >
                    {link.label}
                    <ArrowRight className="h-3 w-3 ml-1 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all" />
                  </Link>
                </li>
              ))}
            </ul>

            {/* Social */}
            <div>
              <h4 className="text-sm font-medium mb-3">Connect</h4>
              <a
                href="https://linkedin.com/company/lawupconsulting"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center w-10 h-10 bg-primary-foreground/10 hover:bg-accent rounded-lg transition-colors group"
              >
                <Linkedin className="h-4 w-4 group-hover:text-accent-foreground transition-colors" />
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar - Stack on mobile */}
      <div className="border-t border-primary-foreground/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-6">
          <div className="flex flex-col lg:flex-row items-center justify-between gap-4">
            {/* BCI Disclaimer */}
            <p className="text-[10px] sm:text-xs text-primary-foreground/50 text-center lg:text-left max-w-3xl leading-relaxed">
              <strong>Bar Council of India Disclaimer:</strong> This website is for informational purposes only and does
              not solicit or advertise work. The contents do not constitute legal advice.
            </p>

            {/* Copyright - Stack on mobile */}
            <div className="flex flex-col sm:flex-row items-center gap-3 sm:gap-4">
              <div className="flex items-center gap-2 px-3 py-1.5 bg-accent/20 rounded-full">
                <Scale className="h-3 w-3 text-accent" />
                <span className="text-[10px] sm:text-xs font-medium text-accent">Powered by RKS</span>
              </div>
              <p className="text-[10px] sm:text-xs text-primary-foreground/50">
                © {currentYear} LawUp. All rights reserved.
              </p>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
