"use client"

import { ScrollReveal } from "@/components/scroll-reveal"
import { Plus, Minus } from "lucide-react"
import { useState } from "react"

const faqs = [
  {
    question: "What areas of law does LawUp Consulting specialize in?",
    answer:
      "We practice across 10+ major areas including Corporate Law, Real Estate & RERA, Litigation, Intellectual Property, Labour & Employment, Banking & Finance, Taxation, Insurance, Technology & Cyber Law, and Governance & Compliance. Our team has specialized expertise in each practice area.",
  },
  {
    question: "How do I schedule a consultation?",
    answer:
      "You can schedule a consultation by calling us at +91 9716968000, emailing support@lawup.in, or filling out our online contact form. We offer in-person, phone, and video consultations to suit your convenience.",
  },
  {
    question: "What are your consultation fees?",
    answer:
      "Our fees vary depending on the complexity and nature of your legal matter. We offer transparent pricing and will provide a clear fee structure during your initial consultation. We also provide flexible payment options for ongoing matters.",
  },
  {
    question: "Do you handle cases across India?",
    answer:
      "Yes, we are licensed to practice before all courts and tribunals across India. We have successfully represented clients in matters across multiple states and jurisdictions, including the Supreme Court of India.",
  },
  {
    question: "How long does it take to resolve a legal matter?",
    answer:
      "The timeline varies significantly based on the nature of your case, complexity, and jurisdiction. During consultation, we'll provide a realistic timeline estimate. We always strive for the most efficient resolution while ensuring your interests are protected.",
  },
  {
    question: "Is my information kept confidential?",
    answer:
      "Absolutely. Attorney-client privilege and confidentiality are fundamental to our practice. All information you share with us is strictly confidential and protected by law. We maintain robust data security measures to safeguard your information.",
  },
  {
    question: "Can you help with urgent legal matters?",
    answer:
      "Yes, we provide 24/7 support for urgent legal matters. For emergencies, call our helpline at +91 9716968000. We have experience handling urgent matters including bail applications, injunctions, and emergency hearings.",
  },
  {
    question: "Do you offer services in languages other than English?",
    answer:
      "Yes, our team is proficient in multiple Indian languages including Hindi, and we can arrange for language support in other regional languages as needed. Legal documentation is typically prepared in English and Hindi.",
  },
  {
    question: "What documents should I bring for the initial consultation?",
    answer:
      "Bring any relevant documents related to your legal matter such as contracts, notices, correspondence, court papers, or property documents. Even if documents are incomplete, we can guide you on what additional information we'll need.",
  },
  {
    question: "How do I track the progress of my case?",
    answer:
      "We provide regular updates on your matter's progress through your preferred communication channel. You'll have a dedicated point of contact who will keep you informed about all developments, court dates, and required actions.",
  },
]

export function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(null)

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index)
  }

  return (
    <section className="py-16 sm:py-24 lg:py-32 bg-secondary/30">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <ScrollReveal>
          <div className="text-center mb-12 sm:mb-16">
            <span className="inline-flex items-center gap-2 text-accent text-xs sm:text-sm font-medium tracking-widest uppercase mb-3 sm:mb-4">
              <span className="w-6 sm:w-8 h-px bg-accent" />
              Got Questions?
              <span className="w-6 sm:w-8 h-px bg-accent" />
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-primary mb-3 sm:mb-4">
              Frequently Asked Questions
            </h2>
            <p className="text-base sm:text-lg text-muted-foreground max-w-2xl mx-auto px-4">
              Find answers to common questions about our legal services and process
            </p>
          </div>
        </ScrollReveal>

        {/* FAQ Accordion */}
        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <ScrollReveal key={index} delay={index * 50}>
              <div className="bg-card border border-border rounded-xl overflow-hidden transition-all duration-300 hover:border-accent/50">
                <button
                  onClick={() => toggleFAQ(index)}
                  className="w-full flex items-center justify-between gap-4 p-5 sm:p-6 text-left hover:bg-secondary/50 transition-colors"
                  aria-expanded={openIndex === index}
                >
                  <span className="font-semibold text-sm sm:text-base text-primary pr-4">{faq.question}</span>
                  <div
                    className={`flex-shrink-0 w-8 h-8 rounded-full bg-accent/10 flex items-center justify-center transition-transform ${
                      openIndex === index ? "rotate-180" : ""
                    }`}
                  >
                    {openIndex === index ? (
                      <Minus className="w-4 h-4 text-accent" />
                    ) : (
                      <Plus className="w-4 h-4 text-accent" />
                    )}
                  </div>
                </button>

                <div
                  className={`transition-all duration-300 ease-in-out ${
                    openIndex === index ? "max-h-96 opacity-100" : "max-h-0 opacity-0"
                  } overflow-hidden`}
                >
                  <div className="px-5 sm:px-6 pb-5 sm:pb-6">
                    <p className="text-sm sm:text-base text-muted-foreground leading-relaxed">{faq.answer}</p>
                  </div>
                </div>
              </div>
            </ScrollReveal>
          ))}
        </div>

        {/* Contact CTA */}
        <ScrollReveal>
          <div className="mt-12 sm:mt-16 text-center p-6 sm:p-8 bg-card border border-border rounded-2xl">
            <p className="text-sm sm:text-base text-muted-foreground mb-4">Still have questions? We're here to help!</p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <a
                href="tel:+919716968000"
                className="inline-flex items-center justify-center px-6 py-3 bg-accent hover:bg-accent/90 text-accent-foreground rounded-lg font-medium transition-colors text-sm sm:text-base"
              >
                Call +91 9716968000
              </a>
              <a
                href="mailto:support@lawup.in"
                className="inline-flex items-center justify-center px-6 py-3 border border-border hover:bg-secondary/50 text-foreground rounded-lg font-medium transition-colors text-sm sm:text-base"
              >
                Email Us
              </a>
            </div>
          </div>
        </ScrollReveal>
      </div>
    </section>
  )
}
