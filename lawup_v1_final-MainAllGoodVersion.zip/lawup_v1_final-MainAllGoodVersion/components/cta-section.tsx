"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ScrollReveal } from "@/components/scroll-reveal"
import { ArrowRight, Phone, Mail, MapPin } from "lucide-react"

export function CTASection() {
  return (
    <section className="py-16 sm:py-24 lg:py-32 bg-secondary/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 sm:gap-12 lg:gap-20 items-start lg:items-center">
          {/* Content */}
          <ScrollReveal>
            <span className="inline-flex items-center gap-2 text-accent text-xs sm:text-sm font-medium tracking-widest uppercase mb-3 sm:mb-4">
              <span className="w-6 sm:w-8 h-px bg-accent" />
              Get In Touch
            </span>
            <h2 className="font-serif text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-primary mb-4 sm:mb-6 leading-tight">
              Ready to Discuss Your Legal Needs?
            </h2>
            <p className="text-sm sm:text-base lg:text-lg text-muted-foreground mb-6 sm:mb-8 leading-relaxed line-clamp-3 sm:line-clamp-none">
              Connect with our expert legal team for a confidential consultation. We provide strategic counsel tailored
              to your specific requirements.
            </p>

            <div className="flex flex-col xs:flex-row gap-3 sm:gap-4">
              <Button
                asChild
                size="lg"
                className="bg-accent hover:bg-accent/90 text-accent-foreground px-6 sm:px-8 w-full xs:w-auto"
              >
                <Link href="/contact" className="flex items-center justify-center gap-2 text-sm sm:text-base">
                  Schedule Consultation
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="border-primary/30 text-primary hover:bg-primary/5 px-6 sm:px-8 bg-transparent w-full xs:w-auto"
              >
                <a href="tel:+919716968000" className="flex items-center justify-center text-sm sm:text-base">
                  Call Now
                </a>
              </Button>
            </div>
          </ScrollReveal>

          {/* Contact Cards */}
          <ScrollReveal direction="right">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-3 sm:gap-4">
              {[
                {
                  icon: Phone,
                  title: "Phone",
                  value: "+91-9716968000",
                  href: "tel:+919716968000",
                },
                {
                  icon: Mail,
                  title: "Email",
                  value: "support@lawup.in",
                  href: "mailto:support@lawup.in",
                },
                {
                  icon: MapPin,
                  title: "Office",
                  value: "Chamber: Ground B188a, Jamunapuri, Jaipur, Rajasthan - 302039",
                  href: "/contact",
                },
              ].map((item, index) => (
                <Link
                  key={index}
                  href={item.href}
                  className="group flex items-start sm:items-center gap-3 sm:gap-4 p-3 sm:p-6 bg-background border border-border rounded-lg sm:rounded-xl hover-lift transition-all duration-300"
                >
                  <div className="p-2 sm:p-3 bg-accent/10 rounded-lg group-hover:bg-accent/20 transition-colors flex-shrink-0 mt-0.5 sm:mt-0">
                    <item.icon className="h-4 w-4 sm:h-6 sm:w-6 text-accent" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="text-xs sm:text-sm text-muted-foreground mb-0.5 sm:mb-1">{item.title}</div>
                    <div className="font-medium text-xs sm:text-base text-primary group-hover:text-accent transition-colors break-words sm:truncate lg:whitespace-normal">
                      {item.value}
                    </div>
                  </div>
                  <ArrowRight className="h-4 w-4 sm:h-5 sm:w-5 text-muted-foreground flex-shrink-0 opacity-0 group-hover:opacity-100 group-hover:translate-x-1 transition-all hidden sm:block mt-0.5 sm:mt-0" />
                </Link>
              ))}
            </div>
          </ScrollReveal>
        </div>
      </div>
    </section>
  )
}
