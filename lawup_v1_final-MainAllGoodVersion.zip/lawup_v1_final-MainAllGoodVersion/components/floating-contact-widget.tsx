"use client"

import { Phone, MessageCircle, CreditCard } from "lucide-react"

export function FloatingContactWidget() {
  return (
    <>
      {/* Pay Fee Widget - Fixed right side at top of floating buttons */}
      <a
        href="https://razorpay.me/@lawup"
        target="_blank"
        rel="noopener noreferrer"
        className="fixed right-4 bottom-44 z-50 group flex items-center gap-3 px-4 py-3 bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white rounded-lg shadow-[0_0_20px_rgba(147,51,234,0.5)] hover:shadow-[0_0_30px_rgba(147,51,234,0.7)] transition-all duration-300 hover:scale-105 animate-pulse-glow"
        aria-label="Pay fee"
      >
        <CreditCard className="h-6 w-6 group-hover:scale-110 transition-transform" />
        <span className="hidden sm:block font-medium text-sm whitespace-nowrap">Pay Fee</span>
        {/* Ping indicator */}
        <span className="absolute -top-1 -right-1 flex h-3 w-3">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
          <span className="relative inline-flex rounded-full h-3 w-3 bg-white"></span>
        </span>
      </a>

      {/* WhatsApp Widget - Fixed right side, rectangle with glow */}
      <a
        href="https://wa.me/919716968000"
        target="_blank"
        rel="noopener noreferrer"
        className="fixed right-4 bottom-32 z-50 group flex items-center gap-3 px-4 py-3 bg-[#25D366] hover:bg-[#20BA5A] text-white rounded-lg shadow-[0_0_20px_rgba(37,211,102,0.5)] hover:shadow-[0_0_30px_rgba(37,211,102,0.7)] transition-all duration-300 hover:scale-105 animate-float"
        aria-label="Chat on WhatsApp"
      >
        <MessageCircle className="h-6 w-6 group-hover:scale-110 transition-transform" />
        <span className="hidden sm:block font-medium text-sm whitespace-nowrap">WhatsApp</span>
        {/* Ping indicator */}
        <span className="absolute -top-1 -right-1 flex h-3 w-3">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
          <span className="relative inline-flex rounded-full h-3 w-3 bg-white"></span>
        </span>
      </a>

      {/* Call Widget - Fixed right side, rectangle with glow and ringing animation */}
      <a
        href="tel:+919716968000"
        className="fixed right-4 bottom-20 z-50 group flex items-center gap-3 px-4 py-3 bg-accent hover:bg-accent/90 text-accent-foreground rounded-lg shadow-[0_0_20px_rgba(201,162,39,0.5)] hover:shadow-[0_0_30px_rgba(201,162,39,0.7)] transition-all duration-300 hover:scale-105 animate-pulse-glow"
        aria-label="Call us"
      >
        <Phone className="h-6 w-6 animate-ring group-hover:scale-110 transition-transform" />
        <span className="hidden sm:block font-medium text-sm whitespace-nowrap">Call Now</span>
        {/* Ping indicator */}
        <span className="absolute -top-1 -right-1 flex h-3 w-3">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-accent-foreground opacity-75"></span>
          <span className="relative inline-flex rounded-full h-3 w-3 bg-accent-foreground"></span>
        </span>
      </a>
    </>
  )
}
