"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ScrollReveal } from "@/components/scroll-reveal"
import { ArrowRight, Building2, Shield, Users, Landmark, Gavel, Globe, CheckCircle } from "lucide-react"
import { cn } from "@/lib/utils"

const practiceAreas = [
  {
    icon: Gavel,
    title: "Litigation & Disputes",
    description: "Expert representation in civil, criminal, and commercial disputes across all courts and tribunals.",
    href: "/practice-areas#litigation",
    caseTypes: [
      "Civil Suits & Recovery",
      "Criminal Defense",
      "Commercial Arbitration",
      "Consumer Disputes",
      "Writ Petitions",
      "Appellate Matters",
    ],
  },
  {
    icon: Building2,
    title: "Corporate & Commercial",
    description: "Comprehensive corporate advisory, M&A, and business structuring solutions.",
    href: "/practice-areas#corporate",
    caseTypes: [
      "Mergers & Acquisitions",
      "Joint Ventures",
      "Private Equity Deals",
      "Corporate Restructuring",
      "Shareholder Disputes",
      "Due Diligence",
    ],
  },
  {
    icon: Shield,
    title: "Regulatory Compliance",
    description: "Navigating complex regulatory landscapes with precision and expertise.",
    href: "/practice-areas#compliance",
    caseTypes: [
      "SEBI Compliance",
      "RBI Regulations",
      "FEMA Matters",
      "Environmental Clearances",
      "Industry Licensing",
      "Regulatory Audits",
    ],
  },
  {
    icon: Landmark,
    title: "Banking & Finance",
    description: "Full-spectrum financial law advisory and debt recovery services.",
    href: "/practice-areas#banking",
    caseTypes: [
      "Loan Documentation",
      "SARFAESI Proceedings",
      "DRT Matters",
      "Insolvency Cases",
      "NBFC Compliance",
      "Project Finance",
    ],
  },
  {
    icon: Users,
    title: "Employment & Labour",
    description: "Strategic labour law counsel for employers and workforce management.",
    href: "/practice-areas#labour",
    caseTypes: [
      "Labour Court Matters",
      "Industrial Disputes",
      "Wage & Bonus Claims",
      "POSH Compliance",
      "Termination Cases",
      "Union Negotiations",
    ],
  },
  {
    icon: Globe,
    title: "Cyber & Technology",
    description: "Digital era legal solutions for cyber security and tech compliance.",
    href: "/practice-areas#cyber",
    caseTypes: [
      "Data Privacy (DPDP)",
      "Cyber Crime Defense",
      "IT Act Matters",
      "E-commerce Disputes",
      "SaaS Agreements",
      "IP & Tech Licensing",
    ],
  },
]

function FlipCard({ area, index }: { area: (typeof practiceAreas)[0]; index: number }) {
  const [isFlipped, setIsFlipped] = useState(false)

  const handleClick = () => {
    // Only toggle on touch devices
    if (window.matchMedia("(hover: none)").matches) {
      setIsFlipped(!isFlipped)
    }
  }

  return (
    <div className="flip-card" onClick={handleClick}>
      <div className={cn("flip-card-inner", isFlipped && "flipped")}>
        {/* Front of card */}
        <div className="flip-card-front bg-background border border-border shadow-sm">
          <div className="h-full p-5 sm:p-6 flex flex-col">
            <div className="p-2.5 sm:p-3 bg-accent/10 rounded-lg w-fit mb-3 sm:mb-4">
              <area.icon className="h-5 w-5 sm:h-6 sm:w-6 text-accent" />
            </div>
            <h3 className="font-serif text-lg sm:text-xl font-semibold text-primary mb-2 sm:mb-3">{area.title}</h3>
            <p className="text-muted-foreground text-sm leading-relaxed flex-grow">{area.description}</p>
            <div className="mt-3 sm:mt-4 pt-3 sm:pt-4 border-t border-border">
              <span className="inline-flex items-center text-xs sm:text-sm font-medium text-accent">
                <span className="hidden sm:inline">Hover to see case types</span>
                <span className="sm:hidden">Tap to see case types</span>
                <ArrowRight className="h-3.5 w-3.5 sm:h-4 sm:w-4 ml-1" />
              </span>
            </div>
          </div>
        </div>

        {/* Back of card */}
        <div className="flip-card-back bg-primary shadow-lg">
          <div className="h-full p-4 sm:p-5 flex flex-col">
            <div className="flex items-center gap-2 mb-2 sm:mb-3">
              <div className="p-1.5 sm:p-2 bg-accent/20 rounded-lg">
                <area.icon className="h-4 w-4 sm:h-5 sm:w-5 text-accent" />
              </div>
              <h3 className="font-serif text-sm sm:text-base font-semibold text-primary-foreground leading-tight">
                {area.title}
              </h3>
            </div>

            <p className="text-[10px] sm:text-xs text-primary-foreground/60 uppercase tracking-wider mb-2 sm:mb-3">
              Key Case Types
            </p>

            <div className="grid grid-cols-1 gap-1 sm:gap-1.5 flex-grow overflow-y-auto">
              {area.caseTypes.map((caseType, i) => (
                <div key={i} className="flex items-center gap-1.5 sm:gap-2">
                  <CheckCircle className="h-3 w-3 sm:h-3.5 sm:w-3.5 text-accent flex-shrink-0" />
                  <span className="text-[11px] sm:text-xs text-primary-foreground/90 leading-tight">{caseType}</span>
                </div>
              ))}
            </div>

            <Link
              href={area.href}
              onClick={(e) => e.stopPropagation()}
              className="mt-3 sm:mt-4 w-full flex items-center justify-center gap-2 bg-accent hover:bg-accent/90 text-accent-foreground text-xs sm:text-sm font-medium py-2 sm:py-2.5 px-3 sm:px-4 rounded-md transition-colors"
            >
              Explore
              <ArrowRight className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}

export function PracticeAreasPreview() {
  return (
    <section className="py-16 sm:py-24 lg:py-32 bg-secondary/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <ScrollReveal className="text-center mb-10 sm:mb-16">
          <span className="inline-flex items-center gap-2 text-accent text-xs sm:text-sm font-medium tracking-widest uppercase mb-3 sm:mb-4">
            <span className="w-6 sm:w-8 h-px bg-accent" />
            Our Expertise
            <span className="w-6 sm:w-8 h-px bg-accent" />
          </span>
          <h2 className="font-serif text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-primary mb-4 sm:mb-6">
            Practice Areas
          </h2>
          <p className="text-base sm:text-lg text-muted-foreground max-w-2xl mx-auto px-4 sm:px-0">
            Delivering comprehensive legal solutions across diverse practice areas with unmatched expertise and
            dedication.
          </p>
        </ScrollReveal>

        {/* Practice Areas Grid - Single column on small mobile */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 lg:gap-8">
          {practiceAreas.map((area, index) => (
            <ScrollReveal key={index} delay={index * 100}>
              <FlipCard area={area} index={index} />
            </ScrollReveal>
          ))}
        </div>

        {/* CTA */}
        <ScrollReveal className="text-center mt-10 sm:mt-12">
          <Button
            asChild
            size="lg"
            className="bg-primary hover:bg-primary/90 text-primary-foreground px-6 sm:px-8 w-full sm:w-auto"
          >
            <Link href="/practice-areas" className="flex items-center justify-center gap-2">
              View All Practice Areas
              <ArrowRight className="h-4 w-4" />
            </Link>
          </Button>
        </ScrollReveal>
      </div>
    </section>
  )
}
