"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { ScrollReveal } from "@/components/scroll-reveal"
import { Button } from "@/components/ui/button"
import { ArrowRight, Calendar } from "lucide-react"
import { blogPosts } from "@/data/blog-posts"

function getRandomPosts() {
  const posts2025 = blogPosts.filter((post) => post.date.includes("2025"))
  const shuffled = [...posts2025].sort(() => Math.random() - 0.5)
  return shuffled.slice(0, 3)
}

export function InsightsPreview() {
  const [randomPosts, setRandomPosts] = useState(getRandomPosts())

  useEffect(() => {
    setRandomPosts(getRandomPosts())
  }, [])

  return (
    <section className="py-16 sm:py-24 lg:py-32 bg-primary text-primary-foreground">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header - Better mobile layout */}
        <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between mb-10 sm:mb-16">
          <ScrollReveal>
            <span className="inline-flex items-center gap-2 text-accent text-xs sm:text-sm font-medium tracking-widest uppercase mb-3 sm:mb-4">
              <span className="w-6 sm:w-8 h-px bg-accent" />
              Legal Insights
            </span>
            <h2 className="font-serif text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold mb-3 sm:mb-4">
              Latest Perspectives
            </h2>
            <p className="text-sm sm:text-base text-primary-foreground/70 max-w-xl">
              Stay informed with our expert analysis on landmark Supreme Court judgments and evolving legal landscapes.
            </p>
          </ScrollReveal>

          <ScrollReveal delay={200} className="mt-4 sm:mt-6 lg:mt-0">
            <Button
              asChild
              variant="outline"
              className="border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10 bg-transparent w-full sm:w-auto"
            >
              <Link href="/insights" className="flex items-center justify-center gap-2">
                View All Insights
                <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>
          </ScrollReveal>
        </div>

        {/* Insights Grid - Single column on mobile */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {randomPosts.map((post, index) => (
            <ScrollReveal key={post.slug} delay={index * 100}>
              <Link href={`/insights/${post.slug}`} className="group block">
                <article className="h-full">
                  {/* Image */}
                  <div className="relative aspect-[16/10] sm:aspect-[3/2] rounded-lg sm:rounded-xl overflow-hidden mb-4 sm:mb-6">
                    <Image
                      src={post.image || "/placeholder.svg"}
                      alt={post.title}
                      fill
                      className="object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-primary/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>

                  {/* Content */}
                  <div className="space-y-2 sm:space-y-3">
                    <div className="flex items-center gap-3 sm:gap-4 text-xs sm:text-sm">
                      <span className="text-accent font-medium">{post.category}</span>
                      <span className="flex items-center gap-1 text-primary-foreground/50">
                        <Calendar className="h-3 w-3 sm:h-3.5 sm:w-3.5" />
                        {post.date}
                      </span>
                    </div>
                    <h3 className="font-serif text-lg sm:text-xl font-semibold group-hover:text-accent transition-colors leading-tight line-clamp-2">
                      {post.title}
                    </h3>
                    <p className="text-primary-foreground/60 text-xs sm:text-sm line-clamp-2">{post.excerpt}</p>
                    <span className="inline-flex items-center text-xs sm:text-sm font-medium text-accent opacity-0 group-hover:opacity-100 transition-opacity">
                      Read Article
                      <ArrowRight className="h-3.5 w-3.5 sm:h-4 sm:w-4 ml-1 group-hover:translate-x-1 transition-transform" />
                    </span>
                  </div>
                </article>
              </Link>
            </ScrollReveal>
          ))}
        </div>
      </div>
    </section>
  )
}
