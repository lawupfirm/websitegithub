"use client"

import { ScrollReveal } from "@/components/scroll-reveal"
import { FileText, UserCheck, Calendar, MessageSquare, CheckCircle2 } from "lucide-react"

const steps = [
  {
    icon: FileText,
    title: "Share Your Legal Needs",
    description: "Tell us about your legal matter through our secure consultation form or call us directly",
    number: "01",
  },
  {
    icon: UserCheck,
    title: "Get Matched with Expert",
    description: "We connect you with the most qualified lawyer for your specific legal requirement",
    number: "02",
  },
  {
    icon: Calendar,
    title: "Schedule Consultation",
    description: "Book a convenient time for your consultation - in-person, phone, or video call",
    number: "03",
  },
  {
    icon: MessageSquare,
    title: "Receive Expert Guidance",
    description: "Get personalized legal advice and strategic solutions tailored to your situation",
    number: "04",
  },
  {
    icon: CheckCircle2,
    title: "Achieve Resolution",
    description: "We work with you through every step until your legal matter is successfully resolved",
    number: "05",
  },
]

export function HowItWorksSection() {
  return (
    <section className="py-16 sm:py-24 lg:py-32 bg-secondary/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <ScrollReveal>
          <div className="text-center mb-12 sm:mb-16">
            <span className="inline-flex items-center gap-2 text-accent text-xs sm:text-sm font-medium tracking-widest uppercase mb-3 sm:mb-4">
              <span className="w-6 sm:w-8 h-px bg-accent" />
              Simple Process
              <span className="w-6 sm:w-8 h-px bg-accent" />
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-primary mb-3 sm:mb-4">
              How LawUp Works
            </h2>
            <p className="text-base sm:text-lg text-muted-foreground max-w-2xl mx-auto px-4">
              Get expert legal assistance in five simple steps - transparent, efficient, and client-focused
            </p>
          </div>
        </ScrollReveal>

        {/* Steps */}
        <div className="space-y-6 sm:space-y-8 lg:space-y-12">
          {steps.map((step, index) => (
            <ScrollReveal key={index} delay={index * 100}>
              <div
                className={`flex flex-col ${index % 2 === 0 ? "lg:flex-row" : "lg:flex-row-reverse"} gap-6 sm:gap-8 lg:gap-12 items-center`}
              >
                {/* Icon & Number */}
                <div className="relative flex-shrink-0">
                  <div className="w-20 h-20 sm:w-24 sm:h-24 lg:w-32 lg:h-32 rounded-full bg-gradient-to-br from-accent to-accent/70 flex items-center justify-center shadow-lg hover:scale-105 transition-transform">
                    <step.icon className="w-10 h-10 sm:w-12 sm:h-12 lg:w-16 lg:h-16 text-accent-foreground" />
                  </div>
                  <div className="absolute -bottom-2 -right-2 w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-serif font-bold text-base sm:text-lg shadow-md">
                    {step.number}
                  </div>
                </div>

                {/* Content */}
                <div className={`flex-1 text-center ${index % 2 === 0 ? "lg:text-left" : "lg:text-right"}`}>
                  <h3 className="font-serif text-xl sm:text-2xl lg:text-3xl font-bold text-primary mb-2 sm:mb-3">
                    {step.title}
                  </h3>
                  <p className="text-sm sm:text-base text-muted-foreground leading-relaxed max-w-xl mx-auto lg:mx-0">
                    {step.description}
                  </p>
                </div>

                {/* Connector Line - Desktop only */}
                {index < steps.length - 1 && (
                  <div className="hidden lg:block absolute left-1/2 translate-y-32 w-px h-20 bg-border" />
                )}
              </div>
            </ScrollReveal>
          ))}
        </div>
      </div>
    </section>
  )
}
