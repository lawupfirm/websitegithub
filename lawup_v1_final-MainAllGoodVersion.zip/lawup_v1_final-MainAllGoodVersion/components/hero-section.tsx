"use client"

import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { ArrowRight, ChevronDown } from "lucide-react"

export function HeroSection() {
  const scrollToContent = () => {
    window.scrollTo({ top: window.innerHeight, behavior: "smooth" })
  }

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-primary">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0">
        <Image
          src="/modern-law-office-interior-dark-elegant-with-legal.jpg"
          alt="Premium law office"
          fill
          className="object-cover opacity-30"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-b from-primary/80 via-primary/70 to-primary" />
        <div className="absolute inset-0 bg-gradient-to-r from-primary via-transparent to-primary/50" />
      </div>

      {/* Content - Adjusted padding and spacing for mobile */}
      <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 sm:py-32 lg:py-40">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-20 items-center">
          {/* Text Content */}
          <div className="text-center lg:text-left">
            {/* Tagline */}
            <div className="overflow-hidden mb-4 sm:mb-6">
              <div className="hero-text-reveal">
                <span className="inline-flex items-center gap-2 text-accent text-xs sm:text-sm font-medium tracking-widest uppercase">
                  <span className="w-6 sm:w-8 h-px bg-accent" />
                  India's Premier Legal Counsel
                </span>
              </div>
            </div>

            {/* Headline - Responsive font sizes */}
            <div className="overflow-hidden mb-2 sm:mb-4">
              <h1 className="font-serif text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-bold text-primary-foreground hero-text-reveal-delay-1 leading-[1.1]">
                Strategic Legal
              </h1>
            </div>
            <div className="overflow-hidden mb-6 sm:mb-8">
              <h1 className="font-serif text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-bold hero-text-reveal-delay-2 leading-[1.1]">
                <span className="text-gold-gradient">Excellence</span>
              </h1>
            </div>

            {/* Decorative line */}
            <div className="flex justify-center lg:justify-start mb-6 sm:mb-8">
              <div className="w-16 sm:w-20 h-0.5 bg-accent line-reveal" />
            </div>

            {/* Description - Smaller text and reduced width on mobile */}
            <p className="text-base sm:text-lg lg:text-xl text-primary-foreground/80 max-w-lg mx-auto lg:mx-0 mb-8 sm:mb-10 fade-up fade-up-delay-3 leading-relaxed px-2 sm:px-0">
              Delivering sophisticated legal solutions across India with unwavering commitment to integrity, precision,
              and client success.
            </p>

            {/* CTAs - Full width on mobile */}
            <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center lg:justify-start fade-up fade-up-delay-4">
              <Button
                asChild
                size="lg"
                className="bg-accent hover:bg-accent/90 text-accent-foreground font-medium px-6 sm:px-8 py-5 sm:py-6 text-sm sm:text-base group w-full sm:w-auto"
              >
                <Link href="/practice-areas" className="flex items-center justify-center gap-2">
                  Explore Our Expertise
                  <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
                </Link>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10 px-6 sm:px-8 py-5 sm:py-6 text-sm sm:text-base bg-transparent w-full sm:w-auto"
              >
                <Link href="/contact">Schedule Consultation</Link>
              </Button>
            </div>
          </div>

          {/* Stats Grid - Show on mobile too with smaller sizing */}
          <div className="grid grid-cols-2 gap-3 sm:gap-6 mt-8 lg:mt-0 fade-up fade-up-delay-5">
            {[
              { value: "5000+", label: "Matters Handled" },
              { value: "5+", label: "Years Excellence" },
              { value: "Pan-India", label: "Representation" },
              { value: "24/7", label: "Client Support" },
            ].map((stat, index) => (
              <div key={index} className="glass p-4 sm:p-6 rounded-xl text-center hover-lift">
                <div className="text-xl sm:text-2xl lg:text-3xl font-serif font-bold text-accent mb-1 sm:mb-2">
                  {stat.value}
                </div>
                <div className="text-[10px] sm:text-xs lg:text-sm text-primary-foreground/70 uppercase tracking-wider">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Scroll Indicator - Hidden on very small screens */}
      <button
        onClick={scrollToContent}
        className="absolute bottom-6 sm:bottom-8 left-1/2 -translate-x-1/2 text-primary-foreground/60 hover:text-accent transition-colors cursor-pointer hidden sm:flex flex-col items-center gap-2"
        aria-label="Scroll down"
      >
        <span className="text-xs uppercase tracking-widest">Scroll</span>
        <ChevronDown className="h-5 w-5 scroll-indicator" />
      </button>
    </section>
  )
}
