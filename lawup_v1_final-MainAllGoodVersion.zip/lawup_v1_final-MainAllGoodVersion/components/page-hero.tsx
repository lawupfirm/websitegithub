"use client"

import { cn } from "@/lib/utils"

interface PageHeroProps {
  title: string
  subtitle?: string
  badge?: string
  className?: string
  size?: "default" | "large"
}

export function PageHero({ title, subtitle, badge, className, size = "default" }: PageHeroProps) {
  return (
    <section
      className={cn(
        "relative bg-primary text-primary-foreground overflow-hidden",
        size === "large" ? "pt-40 pb-24" : "pt-32 pb-16",
        className,
      )}
    >
      {/* Background Pattern */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-br from-primary via-primary to-primary/90" />
        <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-accent/5 to-transparent" />
        <div className="absolute bottom-0 left-0 w-1/3 h-1/2 bg-gradient-to-t from-accent/5 to-transparent" />
        {/* Subtle grid pattern */}
        <div
          className="absolute inset-0 opacity-[0.02]"
          style={{
            backgroundImage: `linear-gradient(rgba(255,255,255,.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.1) 1px, transparent 1px)`,
            backgroundSize: "50px 50px",
          }}
        />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl">
          {badge && (
            <div className="hero-text-reveal mb-6">
              <span className="inline-flex items-center gap-2 text-accent text-sm font-medium tracking-widest uppercase">
                <span className="w-8 h-px bg-accent" />
                {badge}
              </span>
            </div>
          )}
          <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-bold hero-text-reveal-delay-1 mb-6">
            {title}
          </h1>
          {subtitle && (
            <p className="text-lg sm:text-xl text-primary-foreground/80 leading-relaxed hero-text-reveal-delay-2">
              {subtitle}
            </p>
          )}
          <div className="w-20 h-0.5 bg-accent line-reveal mt-8" />
        </div>
      </div>
    </section>
  )
}
