"use client"

import { cn } from "@/lib/utils"

const clients = [
  "Fortune 500 Companies",
  "Government Bodies",
  "Startups & SMEs",
  "MNCs",
  "Financial Institutions",
  "Healthcare Sector",
  "Real Estate Firms",
  "Technology Companies",
  "Manufacturing",
  "Retail Chains",
]

export function ClientMarquee({ className }: { className?: string }) {
  return (
    <div className={cn("overflow-hidden relative", className)}>
      {/* Gradient masks - Smaller gradient on mobile */}
      <div className="absolute left-0 top-0 bottom-0 w-16 sm:w-32 bg-gradient-to-r from-background to-transparent z-10" />
      <div className="absolute right-0 top-0 bottom-0 w-16 sm:w-32 bg-gradient-to-l from-background to-transparent z-10" />

      <div className="flex animate-marquee">
        {[...clients, ...clients].map((client, index) => (
          <div key={index} className="flex-shrink-0 px-6 sm:px-12 py-3 sm:py-4">
            <span className="text-sm sm:text-lg font-medium text-muted-foreground/60 hover:text-accent transition-colors whitespace-nowrap">
              {client}
            </span>
          </div>
        ))}
      </div>
    </div>
  )
}
