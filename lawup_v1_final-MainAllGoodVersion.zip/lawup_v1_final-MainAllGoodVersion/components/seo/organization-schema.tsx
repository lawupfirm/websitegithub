export function OrganizationSchema() {
  const organizationSchema = {
    "@context": "https://schema.org",
    "@type": "LegalService",
    name: "LawUp Consulting",
    alternateName: "LawUp Consulting",
    description:
      "Full-service Indian law firm providing expert legal services across corporate law, litigation, real estate, employment law, and regulatory compliance.",
    url: "https://lawup.in",
    logo: "https://lawup.in/images/lady-justice.png",
    image: "https://lawup.in/images/lady-justice.png",
    telephone: "+91-141-XXX-XXXX",
    email: "contact@lawup.in",
    address: {
      "@type": "PostalAddress",
      streetAddress: "123 Legal District, Civil Lines",
      addressLocality: "Jaipur",
      addressRegion: "Rajasthan",
      postalCode: "302006",
      addressCountry: "IN",
    },
    geo: {
      "@type": "GeoCoordinates",
      latitude: "26.9124",
      longitude: "75.7873",
    },
    openingHours: ["Mo-Fr 09:00-18:00", "Sa 10:00-14:00"],
    priceRange: "$$",
    areaServed: {
      "@type": "Country",
      name: "India",
    },
    serviceArea: {
      "@type": "Country",
      name: "India",
    },
    hasOfferCatalog: {
      "@type": "OfferCatalog",
      name: "Legal Services",
      itemListElement: [
        {
          "@type": "Offer",
          itemOffered: {
            "@type": "Service",
            name: "Corporate Law",
            description: "Comprehensive corporate legal services including compliance, governance, and transactions.",
          },
        },
        {
          "@type": "Offer",
          itemOffered: {
            "@type": "Service",
            name: "Litigation",
            description: "Expert representation in civil, commercial, and constitutional matters across all courts.",
          },
        },
        {
          "@type": "Offer",
          itemOffered: {
            "@type": "Service",
            name: "Real Estate & RERA",
            description: "Real estate transactions, RERA compliance, and property dispute resolution.",
          },
        },
        {
          "@type": "Offer",
          itemOffered: {
            "@type": "Service",
            name: "Employment Law",
            description: "Labour law compliance, employment contracts, and workplace dispute resolution.",
          },
        },
        {
          "@type": "Offer",
          itemOffered: {
            "@type": "Service",
            name: "Intellectual Property",
            description: "IP protection, trademark registration, patent filing, and enforcement.",
          },
        },
      ],
    },
    founder: [
      {
        "@type": "Person",
        name: "Adv. Rajesh Kumar",
        jobTitle: "Founding Partner",
        worksFor: {
          "@type": "LegalService",
          name: "LawUp Consulting",
        },
      },
      {
        "@type": "Person",
        name: "Adv. Priya Sharma",
        jobTitle: "Founding Partner",
        worksFor: {
          "@type": "LegalService",
          name: "LawUp Consulting",
        },
      },
    ],
    slogan: "Justice in Clear Sight",
    knowsAbout: [
      "Corporate Law",
      "Litigation",
      "Real Estate Law",
      "RERA Compliance",
      "Employment Law",
      "Intellectual Property Rights",
      "Banking and Finance Law",
      "Taxation Law",
      "Technology and Cyber Law",
      "Regulatory Compliance",
    ],
    memberOf: {
      "@type": "Organization",
      name: "Bar Council of India",
    },
  }

  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationSchema) }} />
}
