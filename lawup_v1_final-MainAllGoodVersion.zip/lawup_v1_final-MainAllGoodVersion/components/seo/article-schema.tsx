interface ArticleSchemaProps {
  title: string
  description: string
  author: string
  authorTitle: string
  datePublished: string
  dateModified?: string
  image: string
  url: string
  category: string
}

export function ArticleSchema({
  title,
  description,
  author,
  authorTitle,
  datePublished,
  dateModified,
  image,
  url,
  category,
}: ArticleSchemaProps) {
  const articleSchema = {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: title,
    description: description,
    image: image,
    url: url,
    datePublished: datePublished,
    dateModified: dateModified || datePublished,
    author: {
      "@type": "Person",
      name: author,
      jobTitle: authorTitle,
      worksFor: {
        "@type": "LegalService",
        name: "LawUp Consulting",
      },
    },
    publisher: {
      "@type": "LegalService",
      name: "LawUp Consulting",
      logo: {
        "@type": "ImageObject",
        url: "https://lawup.in/images/lady-justice.png",
      },
    },
    mainEntityOfPage: {
      "@type": "WebPage",
      "@id": url,
    },
    articleSection: category,
    keywords: ["legal advice", "Indian law", category.toLowerCase(), "legal compliance", "business law"],
    about: {
      "@type": "Thing",
      name: category,
    },
  }

  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(articleSchema) }} />
}
