import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { CreditCard, ArrowRight } from "lucide-react"
import { serviceFees } from "@/data/services"

export function FeeStructureSection() {
  // Group fees by category
  const groupedFees = serviceFees.reduce(
    (acc, fee) => {
      if (!acc[fee.category]) {
        acc[fee.category] = []
      }
      acc[fee.category].push(fee)
      return acc
    },
    {} as Record<string, typeof serviceFees>
  )

  return (
    <section className="py-12 md:py-16 bg-secondary/50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Our Fee Structure</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Transparent, BCI-compliant pricing for all legal services. Each fee is based on the complexity and nature
            of the legal matter.
          </p>
        </div>

        <div className="space-y-8">
          {Object.entries(groupedFees).map(([category, fees]) => (
            <div key={category} className="space-y-4">
              <h3 className="text-2xl font-semibold text-foreground">{category}</h3>
              <div className="grid md:grid-cols-2 gap-4">
                {fees.map((fee) => (
                  <Card key={fee.id} className="border-l-4 border-l-accent hover:shadow-lg transition-shadow">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-lg text-foreground">{fee.name}</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <p className="text-sm text-muted-foreground">{fee.description}</p>
                      <div className="flex items-baseline gap-2 py-2 border-t">
                        <span className="text-sm text-muted-foreground">Starting from:</span>
                        <span className="text-2xl font-bold text-accent">₹{fee.minFee.toLocaleString()}</span>
                        {fee.maxFee && (
                          <>
                            <span className="text-sm text-muted-foreground">to</span>
                            <span className="text-2xl font-bold text-accent">₹{fee.maxFee.toLocaleString()}</span>
                          </>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 p-6 bg-primary/10 rounded-lg border border-primary/20">
          <h3 className="text-lg font-semibold text-foreground mb-2">Need Custom Services?</h3>
          <p className="text-muted-foreground mb-6">
            For specialized legal matters, we provide customized fee structures based on the complexity and scope of
            work required. Our team will provide a detailed quote after understanding your specific requirements.
          </p>
          <Link href="/contact">
            <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
              <CreditCard className="mr-2 h-4 w-4" />
              Request a Consultation & Quote
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  )
}
