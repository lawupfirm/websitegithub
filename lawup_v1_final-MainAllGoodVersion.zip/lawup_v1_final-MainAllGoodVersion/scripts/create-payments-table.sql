-- Create payments table to track all transactions
CREATE TABLE IF NOT EXISTS payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  razorpay_order_id VARCHAR NOT NULL UNIQUE,
  razorpay_payment_id VARCHAR,
  razorpay_signature VARCHAR,
  user_email VARCHAR NOT NULL,
  user_name VARCHAR NOT NULL,
  user_phone VARCHAR,
  service_id VARCHAR,
  service_name VARCHAR,
  amount DECIMAL(10, 2) NOT NULL,
  currency VARCHAR DEFAULT 'INR',
  status VARCHAR NOT NULL DEFAULT 'pending', -- pending, captured, failed
  notes JSONB,
  payment_date TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create index for faster queries
CREATE INDEX idx_payments_email ON payments(user_email);
CREATE INDEX idx_payments_razorpay_order_id ON payments(razorpay_order_id);
CREATE INDEX idx_payments_status ON payments(status);
